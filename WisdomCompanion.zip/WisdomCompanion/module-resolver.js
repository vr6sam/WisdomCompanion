// This is a custom module resolver to fix the ESM resolution issue with @jridgewell/resolve-uri
// It hooks into Node.js module resolution system and reroutes specific problematic imports

import { createRequire } from 'module';
import { fileURLToPath, pathToFileURL } from 'url';
import path from 'path';

const require = createRequire(import.meta.url);

// This hook will run before Node tries to load any ESM module
export async function resolve(specifier, context, nextResolve) {
  // Fix for the specific problematic module
  if (specifier === '@jridgewell/resolve-uri/dist/resolve-uri.mjs' || 
      specifier.endsWith('/resolve-uri.mjs')) {
    
    // Redirect to the UMD version instead
    try {
      const umdPath = path.resolve('./node_modules/@jridgewell/resolve-uri/dist/resolve-uri.umd.js');
      return {
        url: pathToFileURL(umdPath).href,
        format: 'module',
        shortCircuit: true
      };
    } catch (err) {
      console.error('Error redirecting module:', err);
    }
  }

  // For all other modules, continue with normal resolution
  return nextResolve(specifier, context);
}

// This hook handles the actual loading of modules
export async function load(url, context, nextLoad) {
  // Check if we're loading our patched module
  if (url.includes('resolve-uri.umd.js')) {
    try {
      const filePath = fileURLToPath(url);
      const code = require('fs').readFileSync(filePath, 'utf8');
      
      // Convert UMD to ESM format
      const esmCode = `
        const module = { exports: {} };
        const exports = module.exports;
        ${code}
        export default module.exports;
        export const resolve = module.exports.resolve;
      `;
      
      return {
        format: 'module',
        source: esmCode,
        shortCircuit: true
      };
    } catch (err) {
      console.error('Error loading module:', err);
    }
  }
  
  // For all other modules, continue with normal loading
  return nextLoad(url, context);
}