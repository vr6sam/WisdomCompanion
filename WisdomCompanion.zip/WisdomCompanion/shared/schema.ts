import { pgTable, text, serial, integer, boolean, timestamp, jsonb, real } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

// Users table
export const users = pgTable("users", {
  id: serial("id").primaryKey(),
  username: text("username").notNull().unique(),
  password: text("password").notNull(),
});

export const insertUserSchema = createInsertSchema(users).pick({
  username: true,
  password: true,
});

// Messages table to store conversation history
export const messages = pgTable("messages", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull(), // reference to users table
  content: text("content").notNull(),
  role: text("role").notNull(), // "user" or "assistant"
  timestamp: timestamp("timestamp").defaultNow().notNull(),
  emotion: text("emotion"), // detected emotion during the message
});

export const insertMessageSchema = createInsertSchema(messages).pick({
  userId: true,
  content: true,
  role: true,
  emotion: true,
});

// Reminders table
export const reminders = pgTable("reminders", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull(),
  title: text("title").notNull(),
  description: text("description"),
  dueDate: timestamp("due_date").notNull(),
  completed: boolean("completed").default(false).notNull(),
});

export const insertReminderSchema = createInsertSchema(reminders).pick({
  userId: true,
  title: true,
  description: true,
  dueDate: true,
  completed: true,
});

// Emergency contacts table
export const emergencyContacts = pgTable("emergency_contacts", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull(),
  name: text("name").notNull(),
  relationship: text("relationship").notNull(),
  phoneNumber: text("phone_number").notNull(),
  email: text("email"),
  isDefault: boolean("is_default").default(false).notNull(),
});

export const insertEmergencyContactSchema = createInsertSchema(emergencyContacts).pick({
  userId: true,
  name: true,
  relationship: true,
  phoneNumber: true,
  email: true,
  isDefault: true,
});

// Types
export type User = typeof users.$inferSelect;
export type InsertUser = z.infer<typeof insertUserSchema>;

export type Message = typeof messages.$inferSelect;
export type InsertMessage = z.infer<typeof insertMessageSchema>;

export type Reminder = typeof reminders.$inferSelect;
export type InsertReminder = z.infer<typeof insertReminderSchema>;

// Emotion tracking table - for storing detected emotions with intensity and context
export const emotionRecords = pgTable("emotion_records", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull(),
  emotion: text("emotion").notNull(), // primary emotion (happy, sad, angry, etc.)
  intensity: real("intensity").notNull(), // 0.0 to 1.0 scale of intensity
  timestamp: timestamp("timestamp").defaultNow().notNull(),
  context: text("context"), // what was happening when the emotion was detected
  sourceType: text("source_type").notNull(), // "message", "camera", "voice", etc.
  sourceId: integer("source_id"), // id of the source (e.g., message id)
  secondaryEmotions: jsonb("secondary_emotions"), // array of other emotions with intensities
  environmentFactors: jsonb("environment_factors"), // relevant environmental factors
});

export const insertEmotionRecordSchema = createInsertSchema(emotionRecords).pick({
  userId: true,
  emotion: true,
  intensity: true,
  context: true,
  sourceType: true,
  sourceId: true,
  secondaryEmotions: true,
  environmentFactors: true,
});

// Thoughts table - for storing AI analysis of user's thoughts and patterns
export const thoughtRecords = pgTable("thought_records", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull(),
  content: text("content").notNull(), // the thought content
  timestamp: timestamp("timestamp").defaultNow().notNull(),
  category: text("category").notNull(), // categorization (belief, concern, goal, etc.)
  valence: text("valence").notNull(), // positive, negative, neutral
  relatedEmotions: jsonb("related_emotions"), // emotions connected to this thought
  sourceType: text("source_type").notNull(), // where this thought was detected (message, etc.)
  sourceId: integer("source_id"), // id of the source
  confidence: real("confidence").default(0.8).notNull(), // how confident is the AI in this analysis
  patternId: integer("pattern_id"), // reference to a detected pattern id
});

export const insertThoughtRecordSchema = createInsertSchema(thoughtRecords).pick({
  userId: true,
  content: true,
  category: true,
  valence: true,
  relatedEmotions: true,
  sourceType: true,
  sourceId: true,
  confidence: true,
  patternId: true,
});

// Thought patterns - recurring thought patterns detected over time
export const thoughtPatterns = pgTable("thought_patterns", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull(),
  name: text("name").notNull(), // name of the pattern
  description: text("description").notNull(), // description of the pattern
  patternType: text("pattern_type").notNull(), // cognitive bias, limiting belief, etc.
  firstDetected: timestamp("first_detected").defaultNow().notNull(),
  lastDetected: timestamp("last_detected").defaultNow().notNull(),
  frequency: integer("frequency").default(1).notNull(), // how many times detected
  impactRating: real("impact_rating"), // AI-estimated impact on user's wellbeing
  examples: jsonb("examples"), // array of example thought contents
  remedyStrategies: jsonb("remedy_strategies"), // potential strategies to address
});

export const insertThoughtPatternSchema = createInsertSchema(thoughtPatterns).pick({
  userId: true,
  name: true,
  description: true,
  patternType: true,
  firstDetected: true,
  lastDetected: true,
  frequency: true,
  impactRating: true,
  examples: true,
  remedyStrategies: true,
});

export type EmergencyContact = typeof emergencyContacts.$inferSelect;
export type InsertEmergencyContact = z.infer<typeof insertEmergencyContactSchema>;

export type EmotionRecord = typeof emotionRecords.$inferSelect;
export type InsertEmotionRecord = z.infer<typeof insertEmotionRecordSchema>;

export type ThoughtRecord = typeof thoughtRecords.$inferSelect;
export type InsertThoughtRecord = z.infer<typeof insertThoughtRecordSchema>;

export type ThoughtPattern = typeof thoughtPatterns.$inferSelect;
export type InsertThoughtPattern = z.infer<typeof insertThoughtPatternSchema>;

// API schemas
export const chatRequestSchema = z.object({
  message: z.string().min(1),
  userId: z.number(),
  emotion: z.string().optional(),
});

export const chatResponseSchema = z.object({
  id: z.number(),
  content: z.string(),
  role: z.string(),
  timestamp: z.string(),
});

export const environmentDataSchema = z.object({
  image: z.string().optional(),
  audio: z.string().optional(),
});

export type ChatRequest = z.infer<typeof chatRequestSchema>;
export type ChatResponse = z.infer<typeof chatResponseSchema>;
export type EnvironmentData = z.infer<typeof environmentDataSchema>;
