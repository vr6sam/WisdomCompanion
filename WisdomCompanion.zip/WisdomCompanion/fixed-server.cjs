// A fixed CommonJS version of the server to bypass ESM resolution issues
const express = require('express');
const { createServer } = require('http');
const path = require('path');
const fs = require('fs');

// Create Express app
const app = express();
const server = createServer(app);
const port = process.env.PORT || 3000;

// Basic route to check if server is running
app.get('/api/health', (req, res) => {
  res.json({ status: 'ok', message: 'Server is running' });
});

// Serve static files from client/dist
if (fs.existsSync(path.join(__dirname, 'client/dist'))) {
  app.use(express.static(path.join(__dirname, 'client/dist')));
  
  // Handle client-side routing
  app.get('*', (req, res) => {
    res.sendFile(path.join(__dirname, 'client/dist/index.html'));
  });
} else {
  app.get('/', (req, res) => {
    res.send('Client not built yet. Please run `npm run build` first.');
  });
}

// Start server
server.listen(port, '0.0.0.0', () => {
  console.log(`Server running on port ${port}`);
});

// Handle errors
process.on('uncaughtException', (err) => {
  console.error('Uncaught exception:', err);
});

process.on('unhandledRejection', (reason, promise) => {
  console.error('Unhandled rejection at:', promise, 'reason:', reason);
});