import { Request, Response } from 'express';
import fetch, { RequestInit } from 'node-fetch';

/**
 * Helper function to make internal API requests from the backend
 * This is used for server-to-server communication
 */
export async function apiRequest(url: string, options: RequestInit = {}, originalReq?: Request) {
  // Get base URL from original request if available
  const baseUrl = originalReq ? 
    `${originalReq.protocol}://${originalReq.get('host')}` : 
    'http://localhost:5000';
  
  // Ensure URL starts with forward slash
  const formattedUrl = url.startsWith('/') ? url : `/${url}`;
  
  // Full URL
  const fullUrl = `${baseUrl}${formattedUrl}`;
  
  // Default headers
  const headers = {
    'Content-Type': 'application/json',
    ...options.headers
  };
  
  // Make request
  return fetch(fullUrl, {
    ...options,
    headers
  });
}

/**
 * Type guard function to check if an object is a Response
 */
export function isResponse(obj: any): obj is Response {
  return obj && typeof obj.status === 'function' && typeof obj.json === 'function';
}

/**
 * Safe JSON parser
 */
export function safeJsonParse(data: string): any {
  try {
    return JSON.parse(data);
  } catch (error) {
    console.error('Error parsing JSON:', error);
    return null;
  }
}

/**
 * Format date for display
 */
export function formatDate(date: Date): string {
  return date.toLocaleString('en-US', {
    weekday: 'short',
    month: 'short',
    day: 'numeric',
    year: 'numeric',
    hour: 'numeric',
    minute: '2-digit',
    hour12: true
  });
}

/**
 * Logger utility with timestamp
 */
export function log(message: string, data?: any): void {
  const timestamp = new Date().toISOString();
  console.log(`[${timestamp}] ${message}`);
  if (data) {
    console.log(data);
  }
}

/**
 * Analyze text emotion based on keywords and patterns
 * Returns the primary emotion and its intensity
 */
export function analyzeTextEmotion(text: string): { primaryEmotion: string, intensity: number } {
  if (!text || text.trim().length === 0) {
    return { primaryEmotion: 'neutral', intensity: 0 };
  }
  
  // Normalize text for analysis
  const normalizedText = text.toLowerCase().trim();
  
  // Define emotion keywords with their weights
  const emotionKeywords = {
    happy: [
      { word: 'happy', weight: 0.7 },
      { word: 'joy', weight: 0.7 },
      { word: 'delighted', weight: 0.8 },
      { word: 'glad', weight: 0.6 },
      { word: 'excellent', weight: 0.6 },
      { word: 'thrilled', weight: 0.8 },
      { word: 'excited', weight: 0.7 },
      { word: 'wonderful', weight: 0.7 },
      { word: 'pleased', weight: 0.5 },
      { word: 'great', weight: 0.5 },
      { word: '😊', weight: 0.8 },
      { word: '😄', weight: 0.8 },
      { word: '🙂', weight: 0.6 },
      { word: 'love', weight: 0.6 },
      { word: 'thank', weight: 0.5 }
    ],
    sad: [
      { word: 'sad', weight: 0.7 },
      { word: 'unhappy', weight: 0.6 },
      { word: 'depressed', weight: 0.8 },
      { word: 'miserable', weight: 0.8 },
      { word: 'disappointing', weight: 0.5 },
      { word: 'disappointed', weight: 0.6 },
      { word: 'upset', weight: 0.6 },
      { word: 'unfortunate', weight: 0.5 },
      { word: 'sorry', weight: 0.4 },
      { word: 'miss', weight: 0.5 },
      { word: 'lost', weight: 0.5 },
      { word: '😢', weight: 0.8 },
      { word: '😥', weight: 0.7 },
      { word: '😔', weight: 0.7 }
    ],
    angry: [
      { word: 'angry', weight: 0.8 },
      { word: 'furious', weight: 0.9 },
      { word: 'mad', weight: 0.7 },
      { word: 'annoyed', weight: 0.6 },
      { word: 'frustrated', weight: 0.6 },
      { word: 'irritated', weight: 0.6 },
      { word: 'hate', weight: 0.7 },
      { word: 'terrible', weight: 0.5 },
      { word: 'awful', weight: 0.5 },
      { word: '😠', weight: 0.8 },
      { word: '😡', weight: 0.9 },
      { word: '🤬', weight: 0.9 }
    ],
    afraid: [
      { word: 'afraid', weight: 0.7 },
      { word: 'scared', weight: 0.7 },
      { word: 'frightened', weight: 0.8 },
      { word: 'terrified', weight: 0.9 },
      { word: 'anxious', weight: 0.6 },
      { word: 'worried', weight: 0.6 },
      { word: 'nervous', weight: 0.6 },
      { word: 'fear', weight: 0.7 },
      { word: 'panic', weight: 0.7 },
      { word: '😨', weight: 0.8 },
      { word: '😰', weight: 0.8 },
      { word: '😱', weight: 0.9 }
    ],
    disgusted: [
      { word: 'disgusted', weight: 0.8 },
      { word: 'gross', weight: 0.7 },
      { word: 'revolting', weight: 0.8 },
      { word: 'sick', weight: 0.5 },
      { word: 'nauseated', weight: 0.7 },
      { word: 'yuck', weight: 0.7 },
      { word: 'ew', weight: 0.6 },
      { word: '🤢', weight: 0.8 },
      { word: '🤮', weight: 0.9 }
    ],
    surprised: [
      { word: 'surprised', weight: 0.7 },
      { word: 'shocked', weight: 0.8 },
      { word: 'amazed', weight: 0.7 },
      { word: 'astonished', weight: 0.8 },
      { word: 'wow', weight: 0.6 },
      { word: 'unexpected', weight: 0.5 },
      { word: 'incredible', weight: 0.5 },
      { word: 'unbelievable', weight: 0.6 },
      { word: '😮', weight: 0.7 },
      { word: '😯', weight: 0.7 },
      { word: '😲', weight: 0.8 }
    ],
    neutral: [
      { word: 'okay', weight: 0.5 },
      { word: 'fine', weight: 0.5 },
      { word: 'normal', weight: 0.5 },
      { word: 'average', weight: 0.5 }
    ]
  };
  
  // Calculate emotion scores
  const scores: Record<string, { score: number, count: number }> = {
    happy: { score: 0, count: 0 },
    sad: { score: 0, count: 0 },
    angry: { score: 0, count: 0 },
    afraid: { score: 0, count: 0 },
    disgusted: { score: 0, count: 0 },
    surprised: { score: 0, count: 0 },
    neutral: { score: 0, count: 0 }
  };
  
  // Check for each emotion's keywords
  Object.entries(emotionKeywords).forEach(([emotion, keywords]) => {
    keywords.forEach(({ word, weight }) => {
      if (normalizedText.includes(word)) {
        scores[emotion].score += weight;
        scores[emotion].count += 1;
      }
    });
  });
  
  // Detect negation patterns
  const negations = ['not', 'don\'t', 'doesn\'t', 'didn\'t', 'isn\'t', 'aren\'t', 'wasn\'t', 'weren\'t', 'no'];
  negations.forEach(negation => {
    // Check if text contains negation + positive emotion word
    if (normalizedText.includes(negation)) {
      // Find the closest emotion word to the negation
      const negationIndex = normalizedText.indexOf(negation);
      
      // Check if happy keywords are negated
      emotionKeywords.happy.forEach(({ word, weight }) => {
        if (normalizedText.includes(word)) {
          const wordIndex = normalizedText.indexOf(word);
          // If negation is close to the emotion word (within 5 words)
          if (Math.abs(negationIndex - wordIndex) < 20) {
            // Reduce happy score and add to sad score
            scores.happy.score -= weight;
            scores.sad.score += weight * 0.7;
          }
        }
      });
    }
  });
  
  // Find the emotion with highest score
  let highestScore = 0;
  let primaryEmotion = 'neutral';
  
  Object.entries(scores).forEach(([emotion, { score }]) => {
    if (score > highestScore) {
      highestScore = score;
      primaryEmotion = emotion;
    }
  });
  
  // Calculate intensity (normalize to 0-1 scale)
  let intensity = Math.min(1, highestScore / 2);
  
  // If no emotion was detected, default to neutral with low intensity
  if (highestScore === 0) {
    primaryEmotion = 'neutral';
    intensity = 0.1;
  }
  
  // Enhance intensity based on punctuation and capitalization
  const exclamationCount = (text.match(/!/g) || []).length;
  const capitalsRatio = text.split('').filter(c => c >= 'A' && c <= 'Z').length / text.length;
  
  intensity += Math.min(0.3, exclamationCount * 0.1); // Add up to 0.3 for exclamations
  intensity += Math.min(0.2, capitalsRatio * 0.5); // Add up to 0.2 for ALL CAPS
  intensity = Math.min(1, intensity); // Cap at 1.0
  
  return { primaryEmotion, intensity };
}

/**
 * Extract possible reminder information from text
 */
export function extractReminder(text: string): {
  title: string;
  dateTime?: Date;
  priority: 'low' | 'medium' | 'high';
} | null {
  // Simple reminder extraction logic
  // In a real system this would be much more sophisticated
  const reminderKeywords = ['remind', 'remember', 'don\'t forget', 'appointment', 'schedule', 'meet'];
  const timeKeywords = ['today', 'tomorrow', 'next week', 'monday', 'tuesday', 'wednesday', 'thursday', 'friday', 'saturday', 'sunday'];
  const priorityKeywords = {
    high: ['urgent', 'important', 'critical', 'asap', 'emergency'],
    medium: ['soon', 'needed'],
    low: ['sometime', 'eventually', 'when you can']
  };
  
  // Check if this might be a reminder
  const isReminder = reminderKeywords.some(keyword => 
    text.toLowerCase().includes(keyword)
  );
  
  if (!isReminder) return null;
  
  // Attempt to extract a date (this is very basic)
  let dateTime: Date | undefined = undefined;
  timeKeywords.forEach(timeKeyword => {
    if (text.toLowerCase().includes(timeKeyword)) {
      const now = new Date();
      
      if (timeKeyword === 'today') {
        dateTime = now;
      } else if (timeKeyword === 'tomorrow') {
        dateTime = new Date(now);
        dateTime.setDate(dateTime.getDate() + 1);
      } else if (timeKeyword === 'next week') {
        dateTime = new Date(now);
        dateTime.setDate(dateTime.getDate() + 7);
      } else {
        // Handle days of the week (very simplified)
        const daysOfWeek = ['sunday', 'monday', 'tuesday', 'wednesday', 'thursday', 'friday', 'saturday'];
        const targetDay = daysOfWeek.indexOf(timeKeyword);
        if (targetDay >= 0) {
          dateTime = new Date(now);
          const currentDay = now.getDay();
          const daysToAdd = (targetDay + 7 - currentDay) % 7;
          dateTime.setDate(dateTime.getDate() + daysToAdd);
        }
      }
    }
  });
  
  // Extract priority
  let priority: 'low' | 'medium' | 'high' = 'medium';
  
  if (priorityKeywords.high.some(keyword => text.toLowerCase().includes(keyword))) {
    priority = 'high';
  } else if (priorityKeywords.low.some(keyword => text.toLowerCase().includes(keyword))) {
    priority = 'low';
  }
  
  // Extract title (very basic - would need NLP for better results)
  let title = text;
  reminderKeywords.forEach(keyword => {
    // Extract text after the keyword
    const index = text.toLowerCase().indexOf(keyword);
    if (index >= 0) {
      title = text.substring(index + keyword.length).trim();
      // Remove "to" or "me to" at the beginning
      title = title.replace(/^(to|me to)\s+/, '');
    }
  });
  
  // Truncate title if too long
  if (title.length > 100) {
    title = title.substring(0, 97) + '...';
  }
  
  return { title, dateTime, priority };
}