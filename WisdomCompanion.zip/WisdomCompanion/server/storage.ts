import { 
  users, type User, type InsertUser,
  messages, type Message, type InsertMessage,
  reminders, type Reminder, type InsertReminder,
  emergencyContacts, type EmergencyContact, type InsertEmergencyContact,
  emotionRecords, type EmotionRecord, type InsertEmotionRecord,
  thoughtRecords, type ThoughtRecord, type InsertThoughtRecord,
  thoughtPatterns, type ThoughtPattern, type InsertThoughtPattern
} from "@shared/schema";

export interface IStorage {
  // User operations
  getUser(id: number): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  
  // Message operations
  createMessage(message: InsertMessage): Promise<Message>;
  getMessagesByUserId(userId: number, limit?: number): Promise<Message[]>;
  getMessageByIdAndUserId(id: number, userId: number): Promise<Message | undefined>;
  
  // Reminder operations
  createReminder(reminder: InsertReminder): Promise<Reminder>;
  getReminders(userId: number): Promise<Reminder[]>;
  getReminderById(id: number): Promise<Reminder | undefined>;
  updateReminder(id: number, reminder: Partial<InsertReminder>): Promise<Reminder | undefined>;
  deleteReminder(id: number): Promise<boolean>;
  getUpcomingReminders(userId: number, hours: number): Promise<Reminder[]>;
  
  // Emergency contact operations
  createEmergencyContact(contact: InsertEmergencyContact): Promise<EmergencyContact>;
  getEmergencyContacts(userId: number): Promise<EmergencyContact[]>;
  getEmergencyContactById(id: number): Promise<EmergencyContact | undefined>;
  updateEmergencyContact(id: number, contact: Partial<InsertEmergencyContact>): Promise<EmergencyContact | undefined>;
  deleteEmergencyContact(id: number): Promise<boolean>;
  getDefaultEmergencyContact(userId: number): Promise<EmergencyContact | undefined>;
  
  // Emotion tracking operations
  createEmotionRecord(emotion: InsertEmotionRecord): Promise<EmotionRecord>;
  getEmotionRecords(userId: number, limit?: number): Promise<EmotionRecord[]>;
  getEmotionRecordById(id: number): Promise<EmotionRecord | undefined>;
  getEmotionRecordsByTimeRange(userId: number, startTime: Date, endTime: Date): Promise<EmotionRecord[]>;
  getEmotionRecordsByEmotion(userId: number, emotion: string): Promise<EmotionRecord[]>;
  deleteEmotionRecord(id: number): Promise<boolean>;
  
  // Thought record operations
  createThoughtRecord(thought: InsertThoughtRecord): Promise<ThoughtRecord>;
  getThoughtRecords(userId: number, limit?: number): Promise<ThoughtRecord[]>;
  getThoughtRecordById(id: number): Promise<ThoughtRecord | undefined>;
  getThoughtRecordsByCategory(userId: number, category: string): Promise<ThoughtRecord[]>;
  getThoughtRecordsByValence(userId: number, valence: string): Promise<ThoughtRecord[]>;
  updateThoughtRecord(id: number, thought: Partial<InsertThoughtRecord>): Promise<ThoughtRecord | undefined>;
  deleteThoughtRecord(id: number): Promise<boolean>;
  
  // Thought pattern operations
  createThoughtPattern(pattern: InsertThoughtPattern): Promise<ThoughtPattern>;
  getThoughtPatterns(userId: number): Promise<ThoughtPattern[]>;
  getThoughtPatternById(id: number): Promise<ThoughtPattern | undefined>;
  getThoughtPatternsByType(userId: number, patternType: string): Promise<ThoughtPattern[]>;
  updateThoughtPattern(id: number, pattern: Partial<InsertThoughtPattern>): Promise<ThoughtPattern | undefined>;
  deleteThoughtPattern(id: number): Promise<boolean>;
}

export class MemStorage implements IStorage {
  private users: Map<number, User>;
  private messages: Map<number, Message>;
  private reminders: Map<number, Reminder>;
  private emergencyContacts: Map<number, EmergencyContact>;
  private emotionRecords: Map<number, EmotionRecord>;
  private thoughtRecords: Map<number, ThoughtRecord>;
  private thoughtPatterns: Map<number, ThoughtPattern>;
  private userId: number;
  private messageId: number;
  private reminderId: number;
  private emergencyContactId: number;
  private emotionRecordId: number;
  private thoughtRecordId: number;
  private thoughtPatternId: number;
  
  constructor() {
    this.users = new Map();
    this.messages = new Map();
    this.reminders = new Map();
    this.emergencyContacts = new Map();
    this.emotionRecords = new Map();
    this.thoughtRecords = new Map();
    this.thoughtPatterns = new Map();
    this.userId = 1;
    this.messageId = 1;
    this.reminderId = 1;
    this.emergencyContactId = 1;
    this.emotionRecordId = 1;
    this.thoughtRecordId = 1;
    this.thoughtPatternId = 1;
    
    // Create a default user
    this.createUser({
      username: "demo",
      password: "password"
    });
  }
  
  // User operations
  async getUser(id: number): Promise<User | undefined> {
    return this.users.get(id);
  }
  
  async getUserByUsername(username: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(
      (user) => user.username === username
    );
  }
  
  async createUser(insertUser: InsertUser): Promise<User> {
    const id = this.userId++;
    const user = { ...insertUser, id };
    this.users.set(id, user);
    return user;
  }
  
  // Message operations
  async createMessage(insertMessage: InsertMessage): Promise<Message> {
    const id = this.messageId++;
    const timestamp = new Date();
    const message: Message = {
      ...insertMessage,
      id,
      timestamp
    };
    this.messages.set(id, message);
    return message;
  }
  
  async getMessagesByUserId(userId: number, limit: number = 50): Promise<Message[]> {
    const userMessages = Array.from(this.messages.values())
      .filter(message => message.userId === userId)
      .sort((a, b) => a.timestamp.getTime() - b.timestamp.getTime());
    
    return limit ? userMessages.slice(-limit) : userMessages;
  }
  
  async getMessageByIdAndUserId(id: number, userId: number): Promise<Message | undefined> {
    const message = this.messages.get(id);
    if (message && message.userId === userId) {
      return message;
    }
    return undefined;
  }
  
  // Reminder operations
  async createReminder(insertReminder: InsertReminder): Promise<Reminder> {
    const id = this.reminderId++;
    const reminder: Reminder = { ...insertReminder, id };
    this.reminders.set(id, reminder);
    return reminder;
  }
  
  async getReminders(userId: number): Promise<Reminder[]> {
    return Array.from(this.reminders.values())
      .filter(reminder => reminder.userId === userId)
      .sort((a, b) => a.dueDate.getTime() - b.dueDate.getTime());
  }
  
  async getReminderById(id: number): Promise<Reminder | undefined> {
    return this.reminders.get(id);
  }
  
  async updateReminder(id: number, reminderUpdate: Partial<InsertReminder>): Promise<Reminder | undefined> {
    const existingReminder = this.reminders.get(id);
    if (!existingReminder) {
      return undefined;
    }
    
    const updatedReminder = { ...existingReminder, ...reminderUpdate };
    this.reminders.set(id, updatedReminder);
    return updatedReminder;
  }
  
  async deleteReminder(id: number): Promise<boolean> {
    return this.reminders.delete(id);
  }
  
  async getUpcomingReminders(userId: number, hours: number): Promise<Reminder[]> {
    const now = new Date();
    const futureTime = new Date(now.getTime() + hours * 60 * 60 * 1000);
    
    return Array.from(this.reminders.values())
      .filter(reminder => 
        reminder.userId === userId && 
        !reminder.completed &&
        reminder.dueDate > now && 
        reminder.dueDate <= futureTime
      )
      .sort((a, b) => a.dueDate.getTime() - b.dueDate.getTime());
  }

  // Emergency contact operations
  async createEmergencyContact(contact: InsertEmergencyContact): Promise<EmergencyContact> {
    const id = this.emergencyContactId++;
    
    // If this is set as default, unset any other defaults for this user
    if (contact.isDefault) {
      const userContacts = Array.from(this.emergencyContacts.values())
        .filter(ec => ec.userId === contact.userId);
      
      for (const existingContact of userContacts) {
        if (existingContact.isDefault) {
          const updated = { ...existingContact, isDefault: false };
          this.emergencyContacts.set(existingContact.id, updated);
        }
      }
    }
    
    const emergencyContact: EmergencyContact = { ...contact, id };
    this.emergencyContacts.set(id, emergencyContact);
    return emergencyContact;
  }
  
  async getEmergencyContacts(userId: number): Promise<EmergencyContact[]> {
    return Array.from(this.emergencyContacts.values())
      .filter(contact => contact.userId === userId);
  }
  
  async getEmergencyContactById(id: number): Promise<EmergencyContact | undefined> {
    return this.emergencyContacts.get(id);
  }
  
  async updateEmergencyContact(id: number, contactUpdate: Partial<InsertEmergencyContact>): Promise<EmergencyContact | undefined> {
    const existingContact = this.emergencyContacts.get(id);
    if (!existingContact) {
      return undefined;
    }
    
    // If setting this contact as default, unset any other defaults
    if (contactUpdate.isDefault && !existingContact.isDefault) {
      const userContacts = Array.from(this.emergencyContacts.values())
        .filter(ec => ec.userId === existingContact.userId && ec.id !== id);
      
      for (const contact of userContacts) {
        if (contact.isDefault) {
          const updated = { ...contact, isDefault: false };
          this.emergencyContacts.set(contact.id, updated);
        }
      }
    }
    
    const updatedContact = { ...existingContact, ...contactUpdate };
    this.emergencyContacts.set(id, updatedContact);
    return updatedContact;
  }
  
  async deleteEmergencyContact(id: number): Promise<boolean> {
    return this.emergencyContacts.delete(id);
  }
  
  async getDefaultEmergencyContact(userId: number): Promise<EmergencyContact | undefined> {
    return Array.from(this.emergencyContacts.values())
      .find(contact => contact.userId === userId && contact.isDefault);
  }

  // Emotion tracking operations
  async createEmotionRecord(emotion: InsertEmotionRecord): Promise<EmotionRecord> {
    const id = this.emotionRecordId++;
    const timestamp = new Date();
    const emotionRecord: EmotionRecord = {
      ...emotion,
      id,
      timestamp
    };
    this.emotionRecords.set(id, emotionRecord);
    return emotionRecord;
  }
  
  async getEmotionRecords(userId: number, limit: number = 50): Promise<EmotionRecord[]> {
    const records = Array.from(this.emotionRecords.values())
      .filter(record => record.userId === userId)
      .sort((a, b) => b.timestamp.getTime() - a.timestamp.getTime()); // Newest first
    
    return limit ? records.slice(0, limit) : records;
  }
  
  async getEmotionRecordById(id: number): Promise<EmotionRecord | undefined> {
    return this.emotionRecords.get(id);
  }
  
  async getEmotionRecordsByTimeRange(userId: number, startTime: Date, endTime: Date): Promise<EmotionRecord[]> {
    return Array.from(this.emotionRecords.values())
      .filter(record => 
        record.userId === userId && 
        record.timestamp >= startTime && 
        record.timestamp <= endTime
      )
      .sort((a, b) => a.timestamp.getTime() - b.timestamp.getTime());
  }
  
  async getEmotionRecordsByEmotion(userId: number, emotion: string): Promise<EmotionRecord[]> {
    return Array.from(this.emotionRecords.values())
      .filter(record => 
        record.userId === userId && 
        record.emotion.toLowerCase() === emotion.toLowerCase()
      )
      .sort((a, b) => b.timestamp.getTime() - a.timestamp.getTime()); // Newest first
  }
  
  async deleteEmotionRecord(id: number): Promise<boolean> {
    return this.emotionRecords.delete(id);
  }
  
  // Thought record operations
  async createThoughtRecord(thought: InsertThoughtRecord): Promise<ThoughtRecord> {
    const id = this.thoughtRecordId++;
    const timestamp = new Date();
    const thoughtRecord: ThoughtRecord = {
      ...thought,
      id,
      timestamp
    };
    this.thoughtRecords.set(id, thoughtRecord);
    return thoughtRecord;
  }
  
  async getThoughtRecords(userId: number, limit: number = 50): Promise<ThoughtRecord[]> {
    const records = Array.from(this.thoughtRecords.values())
      .filter(record => record.userId === userId)
      .sort((a, b) => b.timestamp.getTime() - a.timestamp.getTime()); // Newest first
    
    return limit ? records.slice(0, limit) : records;
  }
  
  async getThoughtRecordById(id: number): Promise<ThoughtRecord | undefined> {
    return this.thoughtRecords.get(id);
  }
  
  async getThoughtRecordsByCategory(userId: number, category: string): Promise<ThoughtRecord[]> {
    return Array.from(this.thoughtRecords.values())
      .filter(record => 
        record.userId === userId && 
        record.category.toLowerCase() === category.toLowerCase()
      )
      .sort((a, b) => b.timestamp.getTime() - a.timestamp.getTime()); // Newest first
  }
  
  async getThoughtRecordsByValence(userId: number, valence: string): Promise<ThoughtRecord[]> {
    return Array.from(this.thoughtRecords.values())
      .filter(record => 
        record.userId === userId && 
        record.valence.toLowerCase() === valence.toLowerCase()
      )
      .sort((a, b) => b.timestamp.getTime() - a.timestamp.getTime()); // Newest first
  }
  
  async updateThoughtRecord(id: number, thoughtUpdate: Partial<InsertThoughtRecord>): Promise<ThoughtRecord | undefined> {
    const existingThought = this.thoughtRecords.get(id);
    if (!existingThought) {
      return undefined;
    }
    
    const updatedThought = { ...existingThought, ...thoughtUpdate };
    this.thoughtRecords.set(id, updatedThought);
    return updatedThought;
  }
  
  async deleteThoughtRecord(id: number): Promise<boolean> {
    return this.thoughtRecords.delete(id);
  }
  
  // Thought pattern operations
  async createThoughtPattern(pattern: InsertThoughtPattern): Promise<ThoughtPattern> {
    const id = this.thoughtPatternId++;
    const firstDetected = new Date();
    const lastDetected = new Date();
    const thoughtPattern: ThoughtPattern = {
      ...pattern,
      id,
      firstDetected,
      lastDetected,
      frequency: pattern.frequency || 1
    };
    this.thoughtPatterns.set(id, thoughtPattern);
    return thoughtPattern;
  }
  
  async getThoughtPatterns(userId: number): Promise<ThoughtPattern[]> {
    return Array.from(this.thoughtPatterns.values())
      .filter(pattern => pattern.userId === userId)
      .sort((a, b) => b.frequency - a.frequency); // Most frequent first
  }
  
  async getThoughtPatternById(id: number): Promise<ThoughtPattern | undefined> {
    return this.thoughtPatterns.get(id);
  }
  
  async getThoughtPatternsByType(userId: number, patternType: string): Promise<ThoughtPattern[]> {
    return Array.from(this.thoughtPatterns.values())
      .filter(pattern => 
        pattern.userId === userId && 
        pattern.patternType.toLowerCase() === patternType.toLowerCase()
      )
      .sort((a, b) => b.frequency - a.frequency); // Most frequent first
  }
  
  async updateThoughtPattern(id: number, patternUpdate: Partial<InsertThoughtPattern>): Promise<ThoughtPattern | undefined> {
    const existingPattern = this.thoughtPatterns.get(id);
    if (!existingPattern) {
      return undefined;
    }
    
    // If this is a frequency update, increment instead of replacing
    if (patternUpdate.frequency && typeof patternUpdate.frequency === 'number') {
      patternUpdate.frequency = existingPattern.frequency + patternUpdate.frequency;
      patternUpdate.lastDetected = new Date();
    }
    
    const updatedPattern = { ...existingPattern, ...patternUpdate };
    this.thoughtPatterns.set(id, updatedPattern);
    return updatedPattern;
  }
  
  async deleteThoughtPattern(id: number): Promise<boolean> {
    return this.thoughtPatterns.delete(id);
  }
}

export const storage = new MemStorage();
