import type { Express, Request, Response, NextFunction } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { 
  chatRequestSchema, 
  insertMessageSchema, 
  insertReminderSchema,
  insertEmergencyContactSchema
} from "@shared/schema";
import { apiRequest } from './utils';
import { generateChatResponse, analyzeEnvironment } from "./services/openai";
import { checkForEmergency, contactEmergencyContacts } from "./services/emergency";
import { integratedAssistant } from "./services/integrated-assistant";
import { multiAI } from "./services/multi-ai";
import { 
  detectFacialEmotion, 
  detectVoiceEmotion, 
  detectTextEmotion, 
  detectMultimodalEmotion 
} from "./routes/emotion-detection";
import { getAIStatus } from "./routes/ai-status";
import visionRouter from "./routes/vision";
import searchRouter from "./routes/search";
import userHistoryRouter from "./routes/user-history";
import openaiRouter from "./routes/openai";
import anthropicRouter from "./routes/anthropic";

export async function registerRoutes(app: Express): Promise<Server> {
  const httpServer = createServer(app);
  
  // Explicitly serve the models directory
  app.use('/models', (req: Request, res: Response, next: NextFunction) => {
    console.log(`Serving model file: ${req.path}`);
    next();
  });
  
  // Register vision API routes
  app.use('/api/vision', visionRouter);
  
  // Register search API routes
  app.use('/api/search', searchRouter);
  
  // Register user history API routes
  app.use('/api/user-history', userHistoryRouter);
  
  // Register OpenAI API routes
  app.use('/api/openai', openaiRouter);
  
  // Register Anthropic API routes
  app.use('/api/anthropic', anthropicRouter);
  
  // Register emotion detection endpoints
  app.post('/api/emotions/facial', detectFacialEmotion);
  app.post('/api/emotions/voice', detectVoiceEmotion);
  app.post('/api/emotions/text', detectTextEmotion);
  app.post('/api/emotions/multimodal', detectMultimodalEmotion);
  
  // Register AI provider status endpoint
  app.get('/api/ai-status', getAIStatus);
  
  // Register API for reloading API keys
  app.post('/api/reload-keys', async (req: Request, res: Response) => {
    try {
      const { openai_api_key, anthropic_api_key } = req.body;
      
      // Set as environment variables
      if (openai_api_key) {
        process.env.OPENAI_API_KEY = openai_api_key;
      }
      
      if (anthropic_api_key) {
        process.env.ANTHROPIC_API_KEY = anthropic_api_key;
      }
      
      return res.json({
        success: true,
        message: 'API keys reloaded successfully'
      });
    } catch (error) {
      console.error('Error reloading API keys:', error);
      
      return res.status(500).json({
        success: false,
        message: 'Error reloading API keys'
      });
    }
  });

  // API routes
  // User route - get current user (demo purposes)
  app.get("/api/user", async (req, res) => {
    const user = await storage.getUser(1); // Default user ID is 1
    if (!user) {
      return res.status(404).json({ error: "User not found" });
    }
    
    return res.json({ id: user.id, username: user.username });
  });

  // Message routes
  app.get("/api/messages", async (req, res) => {
    const userId = 1; // For demo, using default user
    const messages = await storage.getMessagesByUserId(userId);
    return res.json(messages);
  });

  // User context routes
  app.post("/api/user-context", async (req, res) => {
    try {
      const userId = req.body.userId || 1;
      const { webHistory, appUsage, interests } = req.body;
      
      // In a real app, we would store this data in the database
      // For demo purposes, we'll just return confirmation
      return res.json({ 
        success: true, 
        message: "User context data received",
        userId
      });
    } catch (error) {
      console.error("Error saving user context:", error);
      return res.status(400).json({ error: error.message });
    }
  });
  
  app.get("/api/user-context/:userId", async (req, res) => {
    try {
      const userId = parseInt(req.params.userId) || 1;
      
      // In a real app, we would fetch this from the database
      // For demo purposes, we'll return mock data
      const mockUserContext = {
        webHistory: ["productivity apps", "meditation guides", "healthy recipes"],
        appUsage: { 
          "productivity": 3.5, // hours per week
          "social": 2.1,
          "entertainment": 4.2
        },
        interests: ["health", "productivity", "mindfulness"]
      };
      
      return res.json(mockUserContext);
    } catch (error) {
      console.error("Error retrieving user context:", error);
      return res.status(400).json({ error: error.message });
    }
  });

  // Web search route
  app.post("/api/web-search", async (req, res) => {
    try {
      const { query } = req.body;
      
      if (!query || typeof query !== 'string') {
        return res.status(400).json({ error: "Invalid search query" });
      }
      
      // Call the fetchWebData function from openai.ts service
      const webData = await import("./services/openai").then(module => module.fetchWebData(query));
      
      return res.json({ results: webData });
    } catch (error) {
      console.error("Error searching web:", error);
      return res.status(500).json({ error: "Failed to retrieve web information" });
    }
  });

  // Chat route is implemented below with emergency detection middleware

  // Environmental analysis route
  app.post("/api/analyze-environment", async (req, res) => {
    try {
      const { image, audio } = req.body;
      const analysis = await analyzeEnvironment(image, audio);
      return res.json(analysis);
    } catch (error) {
      console.error("Error analyzing environment:", error);
      return res.status(500).json({ error: "Failed to analyze environment" });
    }
  });

  // Reminder routes
  app.get("/api/reminders", async (req, res) => {
    const userId = 1; // For demo, using default user
    const reminders = await storage.getReminders(userId);
    return res.json(reminders);
  });

  app.post("/api/reminders", async (req, res) => {
    try {
      const userId = 1; // For demo, using default user
      const reminderData = insertReminderSchema.parse({
        ...req.body,
        userId,
      });
      
      const reminder = await storage.createReminder(reminderData);
      return res.status(201).json(reminder);
    } catch (error) {
      return res.status(400).json({ error: error.message });
    }
  });

  app.put("/api/reminders/:id", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const reminder = await storage.getReminderById(id);
      
      if (!reminder) {
        return res.status(404).json({ error: "Reminder not found" });
      }
      
      const updatedReminder = await storage.updateReminder(id, req.body);
      return res.json(updatedReminder);
    } catch (error) {
      return res.status(400).json({ error: error.message });
    }
  });

  app.delete("/api/reminders/:id", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const success = await storage.deleteReminder(id);
      
      if (!success) {
        return res.status(404).json({ error: "Reminder not found" });
      }
      
      return res.status(204).send();
    } catch (error) {
      return res.status(400).json({ error: error.message });
    }
  });

  // Get upcoming reminders (next 24 hours)
  app.get("/api/reminders/upcoming", async (req, res) => {
    const userId = 1; // For demo, using default user
    const upcomingReminders = await storage.getUpcomingReminders(userId, 24); // Next 24 hours
    return res.json(upcomingReminders);
  });

  // Emergency Contact Routes
  app.get("/api/emergency-contacts", async (req, res) => {
    const userId = 1; // For demo, using default user
    const contacts = await storage.getEmergencyContacts(userId);
    return res.json(contacts);
  });

  app.post("/api/emergency-contacts", async (req, res) => {
    try {
      const userId = 1; // For demo, using default user
      const contactData = insertEmergencyContactSchema.parse({
        ...req.body,
        userId,
      });
      
      const contact = await storage.createEmergencyContact(contactData);
      return res.status(201).json(contact);
    } catch (error) {
      return res.status(400).json({ error: error.message });
    }
  });

  app.put("/api/emergency-contacts/:id", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const contact = await storage.getEmergencyContactById(id);
      
      if (!contact) {
        return res.status(404).json({ error: "Emergency contact not found" });
      }
      
      const updatedContact = await storage.updateEmergencyContact(id, req.body);
      return res.json(updatedContact);
    } catch (error) {
      return res.status(400).json({ error: error.message });
    }
  });

  app.delete("/api/emergency-contacts/:id", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const success = await storage.deleteEmergencyContact(id);
      
      if (!success) {
        return res.status(404).json({ error: "Emergency contact not found" });
      }
      
      return res.status(204).send();
    } catch (error) {
      return res.status(400).json({ error: error.message });
    }
  });

  // Get default emergency contact
  app.get("/api/emergency-contacts/default", async (req, res) => {
    const userId = 1; // For demo, using default user
    const defaultContact = await storage.getDefaultEmergencyContact(userId);
    
    if (!defaultContact) {
      return res.status(404).json({ error: "No default emergency contact found" });
    }
    
    return res.json(defaultContact);
  });

  // Emergency detection middleware for chat messages
  // Modify the chat endpoint to check for emergencies
  app.post("/api/chat", async (req, res, next) => {
    const validatedData = chatRequestSchema.parse(req.body);
    const { message, userId } = validatedData;
    
    // Check if the message indicates an emergency
    const emergencyCheck = await checkForEmergency(message, userId);
    
    if (emergencyCheck.isEmergency) {
      console.log(`EMERGENCY DETECTED: ${emergencyCheck.reason} (Level: ${emergencyCheck.level})`);
      
      // Contact emergency contacts based on the emergency level
      const emergencyCalls = await contactEmergencyContacts(
        userId, 
        message, 
        emergencyCheck.level
      );
      
      if (emergencyCalls.length > 0) {
        console.log(`Emergency contacts notified: ${emergencyCalls.length}`);
        
        // Add this information to the request for use in the next middleware
        req.body.emergencyResponse = {
          detected: true,
          level: emergencyCheck.level,
          reason: emergencyCheck.reason,
          contactsNotified: emergencyCalls.map(call => call.contactName)
        };
      }
    }
    
    next();
  }, async (req, res) => {
    try {
      const validatedData = chatRequestSchema.parse(req.body);
      const { message, userId, emotion } = validatedData;
      
      // Save user message
      const userMessage = await storage.createMessage({
        userId,
        content: message,
        role: "user",
        emotion,
      });
      
      // Get conversation history
      const conversationHistory = await storage.getMessagesByUserId(userId, 20);
      
      // Get user history, patterns, and preferences
      // In a real app, this would be more sophisticated and use actual data
      
      // Get history from user-history API (simplified version)
      const userHistoryResponse = await apiRequest('/api/user-history', {}, req);
      const userHistoryData = await userHistoryResponse.json();
      
      // Get pattern analysis from user history data
      const patternAnalysisResponse = await apiRequest('/api/user-history/analyze-patterns', {
        method: 'POST',
        body: JSON.stringify({
          history: userHistoryData.history || [],
          currentContext: {
            time: new Date(),
            dayOfWeek: new Date().getDay(),
            timeOfDay: new Date().getHours()
          }
        })
      }, req);
      
      const patternAnalysisData = await patternAnalysisResponse.json();
      
      // Generate a proactive suggestion
      const suggestionResponse = await apiRequest('/api/user-history/generate-suggestion', {
        method: 'POST',
        body: JSON.stringify({
          currentTime: new Date(),
          currentIntent: patternAnalysisData.currentIntents?.[0] || null,
          currentNeed: patternAnalysisData.currentNeeds?.[0] || null,
          relevantPatterns: patternAnalysisData.patterns || [],
          keyPreferences: patternAnalysisData.preferences || [],
          recentHistory: userHistoryData.history || []
        })
      }, req);
      
      const suggestionData = await suggestionResponse.json();
      
      // Create comprehensive user context with all available data
      let userContext: any = {
        webHistory: ["productivity tools", "meditation guides", "healthy recipes"],
        appUsage: { 
          "productivity": 3.5, 
          "social": 2.1,
          "entertainment": 4.2
        },
        interests: ["health", "productivity", "mindfulness"],
        userHistory: userHistoryData.history || [],
        patterns: patternAnalysisData.patterns || [],
        preferences: patternAnalysisData.preferences || [],
        currentIntents: patternAnalysisData.currentIntents || [],
        currentNeeds: patternAnalysisData.currentNeeds || [],
        proactiveSuggestion: suggestionData.suggestion || null,
        suggestionReasoning: suggestionData.reasoning || null,
        suggestionConfidence: suggestionData.confidence || 0
      };
      
      // Add emergency response information if available
      if (req.body.emergencyResponse) {
        userContext.emergencyResponse = req.body.emergencyResponse;
      }
      
      // Generate AI response using integrated assistant
      const aiResponseContent = await integratedAssistant.generateResponse(
        message,
        userId,
        conversationHistory,
        {
          environmentContext: userContext.environmentContext || null,
          userIntents: userContext.currentIntents || null,
          userNeeds: userContext.currentNeeds || null,
          webSearchResults: userContext.webSearchResults || null,
          emotionalState: emotion || null
        }
      );
      
      // Save AI response
      const aiMessage = await storage.createMessage({
        userId,
        content: aiResponseContent,
        role: "assistant",
        emotion: null,
      });
      
      // Include emergency information in the response if applicable
      const response: any = {
        userMessage,
        aiMessage,
      };
      
      if (req.body.emergencyResponse) {
        response.emergency = req.body.emergencyResponse;
      }
      
      return res.json(response);
    } catch (error) {
      console.error("Error in chat endpoint:", error);
      return res.status(400).json({ error: error.message });
    }
  });

  return httpServer;
}
