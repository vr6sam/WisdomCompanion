import { Request, Response } from 'express';
import { multiAI } from '../services/multi-ai';

/**
 * Get status of all AI providers
 */
export async function getAIStatus(_req: Request, res: Response) {
  try {
    // Force a fresh check of provider status
    await multiAI.checkProviderStatus();
    
    // Get current provider status
    const providerStatus = multiAI.getProviderStatus();
    
    res.json({
      success: true,
      providers: providerStatus,
      hasWorkingProvider: providerStatus.openai || providerStatus.anthropic
    });
  } catch (error: any) {
    console.error('Error getting AI status:', error);
    res.status(500).json({
      success: false,
      error: error.message || 'Failed to get AI provider status'
    });
  }
}