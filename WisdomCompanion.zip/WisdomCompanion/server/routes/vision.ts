import { Router } from 'express';
import OpenAI from 'openai';

const router = Router();

// Initialize OpenAI client
const openai = new OpenAI({
  apiKey: process.env.OPENAI_API_KEY,
});

// Analyze an image using vision model
router.post('/analyze', async (req, res) => {
  try {
    const { image, prompt } = req.body;
    
    if (!image) {
      return res.status(400).json({ error: 'Image data is required' });
    }
    
    // the newest OpenAI model is "gpt-4o" which was released May 13, 2024
    const response = await openai.chat.completions.create({
      model: "gpt-4o",
      messages: [
        {
          role: "system",
          content: "You are an advanced visual analysis assistant. Analyze the image and provide detailed information about what you see including objects, people, environment, lighting, activities, and context."
        },
        {
          role: "user",
          content: [
            {
              type: "text",
              text: prompt || "Analyze this image in detail and describe what you see."
            },
            {
              type: "image_url",
              image_url: {
                url: `data:image/jpeg;base64,${image}`
              }
            }
          ],
        },
      ],
      max_tokens: 800,
    });

    const content = response.choices[0].message.content;
    
    return res.json({ 
      content,
      objects: extractObjects(content),
      sceneDescription: extractSceneDescription(content)
    });
  } catch (error) {
    console.error('Error analyzing image:', error);
    res.status(500).json({ error: 'Failed to analyze image' });
  }
});

// Environment analysis endpoint
router.post('/environment', async (req, res) => {
  try {
    const { image } = req.body;
    
    if (!image) {
      return res.status(400).json({ error: 'Image data is required' });
    }
    
    const prompt = `
      Analyze this environment in detail. Identify:
      1. Lighting conditions (dark/dim/moderate/bright/very bright)
      2. Objects present (prioritize furniture, electronics, and personal items)
      3. General scene description (e.g., office, living room, outdoors)
      4. Approximate number of people visible
      5. Whether the environment appears busy or calm
      6. Whether it's indoor or outdoor
      7. Any potential hazards or safety concerns
      
      Format the response as a JSON object with these properties:
      {
        "lighting": string,
        "objects": array of object names,
        "scene": string,
        "peopleCount": number,
        "isBusy": boolean,
        "isOutdoors": boolean,
        "hazards": array of strings
      }
      
      Respond ONLY with the JSON, nothing else.
    `;
    
    // the newest OpenAI model is "gpt-4o" which was released May 13, 2024
    const response = await openai.chat.completions.create({
      model: "gpt-4o",
      response_format: { type: "json_object" },
      messages: [
        {
          role: "system",
          content: "You are an advanced environmental analysis assistant. You analyze images of environments and output structured JSON data."
        },
        {
          role: "user",
          content: [
            {
              type: "text",
              text: prompt
            },
            {
              type: "image_url",
              image_url: {
                url: `data:image/jpeg;base64,${image}`
              }
            }
          ],
        },
      ],
      max_tokens: 800,
    });

    const content = response.choices[0].message.content;
    
    try {
      // Try to parse the content as JSON
      const jsonData = JSON.parse(content);
      return res.json(jsonData);
    } catch (err) {
      // If parsing fails, return the raw content
      return res.json({ 
        lighting: 'moderate',
        objects: [],
        scene: 'unknown',
        peopleCount: 0,
        isBusy: false,
        isOutdoors: false,
        hazards: [],
        rawContent: content
      });
    }
  } catch (error) {
    console.error('Error analyzing environment:', error);
    res.status(500).json({ error: 'Failed to analyze environment' });
  }
});

// OCR (text detection) endpoint
router.post('/ocr', async (req, res) => {
  try {
    const { image } = req.body;
    
    if (!image) {
      return res.status(400).json({ error: 'Image data is required' });
    }
    
    // the newest OpenAI model is "gpt-4o" which was released May 13, 2024
    const response = await openai.chat.completions.create({
      model: "gpt-4o",
      messages: [
        {
          role: "system",
          content: "You are an OCR assistant. Extract all text visible in the image. Present the text as an array of strings, with each meaningful block of text as a separate string. Respond with JSON in the format: { \"textBlocks\": [\"text1\", \"text2\", ...] }"
        },
        {
          role: "user",
          content: [
            {
              type: "text",
              text: "Extract all text visible in this image."
            },
            {
              type: "image_url",
              image_url: {
                url: `data:image/jpeg;base64,${image}`
              }
            }
          ],
        },
      ],
      response_format: { type: "json_object" },
      max_tokens: 800,
    });

    const content = response.choices[0].message.content;
    
    try {
      // Try to parse the content as JSON
      const jsonData = JSON.parse(content);
      return res.json(jsonData);
    } catch (err) {
      // If parsing fails, return an empty array
      return res.json({ textBlocks: [] });
    }
  } catch (error) {
    console.error('Error performing OCR:', error);
    res.status(500).json({ error: 'Failed to extract text from image' });
  }
});

// Generic describe endpoint - allows custom prompts
router.post('/describe', async (req, res) => {
  try {
    const { image, prompt } = req.body;
    
    if (!image) {
      return res.status(400).json({ error: 'Image data is required' });
    }
    
    // the newest OpenAI model is "gpt-4o" which was released May 13, 2024
    const response = await openai.chat.completions.create({
      model: "gpt-4o",
      messages: [
        {
          role: "user",
          content: [
            {
              type: "text",
              text: prompt || "Describe this image in detail."
            },
            {
              type: "image_url",
              image_url: {
                url: `data:image/jpeg;base64,${image}`
              }
            }
          ],
        },
      ],
      max_tokens: 800,
    });

    const description = response.choices[0].message.content;
    return res.json({ description });
  } catch (error) {
    console.error('Error describing image:', error);
    res.status(500).json({ error: 'Failed to describe image' });
  }
});

// Helper function to extract objects from GPT response
function extractObjects(content: string): string[] {
  // This is a simple extraction that looks for lists of objects
  // A more robust implementation would use more sophisticated NLP
  
  const objectsMatch = content.match(/objects?:?\s*([\w\s,]+)/i);
  if (objectsMatch && objectsMatch[1]) {
    return objectsMatch[1]
      .split(/,|\s+and\s+/)
      .map(obj => obj.trim())
      .filter(obj => obj.length > 0);
  }
  
  // Look for bullet points or numbered lists that might contain objects
  const listItems = content.match(/[•\-\*]\s*([\w\s]+)|\d+\.\s*([\w\s]+)/g);
  if (listItems) {
    return listItems
      .map(item => item.replace(/[•\-\*]\s*|\d+\.\s*/, '').trim())
      .filter(item => item.length > 0);
  }
  
  return [];
}

// Helper function to extract scene description
function extractSceneDescription(content: string): string {
  // Try to find a sentence that describes the scene
  const sceneMatch = content.match(/scene:?\s*([^\.]+)/i) || 
                     content.match(/environment:?\s*([^\.]+)/i) ||
                     content.match(/setting:?\s*([^\.]+)/i) ||
                     content.match(/location:?\s*([^\.]+)/i);
  
  if (sceneMatch && sceneMatch[1]) {
    return sceneMatch[1].trim();
  }
  
  // If no explicit scene description, take the first sentence as a fallback
  const firstSentence = content.split(/\.\s+/)[0];
  if (firstSentence) {
    return firstSentence.trim();
  }
  
  return 'Unknown scene';
}

export default router;