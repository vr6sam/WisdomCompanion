import { Router } from 'express';
import OpenAI from 'openai';

const router = Router();

// Initialize OpenAI client
const openai = new OpenAI({ apiKey: process.env.OPENAI_API_KEY });

/**
 * OpenAI Chat API endpoint
 * Accepts messages array, model, and optional parameters
 */
router.post('/chat', async (req, res) => {
  try {
    const { messages, model = 'gpt-4o', temperature = 0.7, max_tokens = 1000 } = req.body;
    
    if (!messages || !Array.isArray(messages) || messages.length === 0) {
      return res.status(400).json({ error: 'Valid messages array is required' });
    }
    
    // Log the incoming request for debugging
    console.log('Processing OpenAI chat request', { 
      messageCount: messages.length, 
      model
    });

    // Call OpenAI API
    const completion = await openai.chat.completions.create({
      model, // the newest OpenAI model is "gpt-4o" which was released May 13, 2024
      messages,
      temperature,
      max_tokens
    });

    // Extract and return the response content
    const content = completion.choices[0].message.content;
    return res.json({ content });
  } catch (error) {
    console.error('OpenAI chat error:', error);
    
    // Handle API key errors specifically
    if (error.code === 'invalid_api_key' || error.message?.includes('API key')) {
      return res.status(401).json({ 
        error: 'OpenAI API key is invalid or missing',
        message: 'Please check the OPENAI_API_KEY environment variable'
      });
    }
    
    // General error response
    return res.status(500).json({ 
      error: 'Failed to process OpenAI request',
      message: error.message || 'Unknown error'
    });
  }
});

/**
 * Vision API endpoint for image analysis
 */
router.post('/vision', async (req, res) => {
  try {
    const { messages, model = 'gpt-4o', temperature = 0.7, max_tokens = 1000 } = req.body;
    
    if (!messages || !Array.isArray(messages) || messages.length === 0) {
      return res.status(400).json({ error: 'Valid messages array with image content is required' });
    }
    
    // Validate that at least one message contains an image
    const hasImage = messages.some(message => 
      message.content && Array.isArray(message.content) && 
      message.content.some(item => item.type === 'image_url')
    );
    
    if (!hasImage) {
      return res.status(400).json({ error: 'At least one message must contain an image' });
    }

    // Call OpenAI API
    const completion = await openai.chat.completions.create({
      model, // the newest OpenAI model is "gpt-4o" which was released May 13, 2024
      messages,
      temperature,
      max_tokens
    });

    // Extract and return the response content
    const content = completion.choices[0].message.content;
    return res.json({ content });
  } catch (error) {
    console.error('OpenAI vision error:', error);
    return res.status(500).json({ 
      error: 'Failed to process OpenAI Vision request',
      message: error.message || 'Unknown error'
    });
  }
});

/**
 * Transcribe audio to text (uses Whisper model)
 */
router.post('/transcribe', async (req, res) => {
  try {
    const { audio } = req.body;
    
    if (!audio) {
      return res.status(400).json({ error: 'Audio data is required' });
    }
    
    // Convert base64 to buffer
    const buffer = Buffer.from(audio, 'base64');
    
    // Create a temporary file (in a real app, we'd use a proper file handling system)
    const tmpFilePath = `/tmp/audio-${Date.now()}.m4a`;
    require('fs').writeFileSync(tmpFilePath, buffer);
    
    // Call OpenAI Whisper API
    const transcription = await openai.audio.transcriptions.create({
      file: require('fs').createReadStream(tmpFilePath),
      model: 'whisper-1',
    });
    
    // Clean up the temporary file
    require('fs').unlinkSync(tmpFilePath);
    
    return res.json({ text: transcription.text });
  } catch (error) {
    console.error('OpenAI transcription error:', error);
    return res.status(500).json({ 
      error: 'Failed to transcribe audio',
      message: error.message || 'Unknown error'
    });
  }
});

/**
 * Test endpoint to verify OpenAI API key is working
 */
router.get('/test', async (req, res) => {
  try {
    // Test with a simple completion
    const completion = await openai.chat.completions.create({
      model: 'gpt-4o',
      messages: [{ role: 'user', content: 'Hello, are you working?' }],
      max_tokens: 10
    });
    
    return res.json({ 
      success: true, 
      message: 'OpenAI API key is valid and working',
      response: completion.choices[0].message.content
    });
  } catch (error) {
    console.error('OpenAI test error:', error);
    return res.status(500).json({ 
      success: false,
      error: 'OpenAI API key test failed',
      message: error.message || 'Unknown error'
    });
  }
});

export default router;