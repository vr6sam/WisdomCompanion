import { Router } from "express";
import { storage } from "../storage";
import { insertEmotionRecordSchema } from "@shared/schema";

const router = Router();

// Get all emotion records for a user
router.get("/:userId", async (req, res) => {
  try {
    const userId = parseInt(req.params.userId);
    const limit = req.query.limit ? parseInt(req.query.limit as string) : undefined;
    const emotions = await storage.getEmotionRecords(userId, limit);
    return res.json(emotions);
  } catch (error) {
    console.error("Error retrieving emotions:", error);
    return res.status(500).json({ error: "Failed to retrieve emotions" });
  }
});

// Get a specific emotion record by ID
router.get("/record/:id", async (req, res) => {
  try {
    const id = parseInt(req.params.id);
    const emotion = await storage.getEmotionRecordById(id);
    
    if (!emotion) {
      return res.status(404).json({ error: "Emotion record not found" });
    }
    
    return res.json(emotion);
  } catch (error) {
    console.error("Error retrieving emotion record:", error);
    return res.status(500).json({ error: "Failed to retrieve emotion record" });
  }
});

// Create a new emotion record
router.post("/", async (req, res) => {
  try {
    const emotionData = insertEmotionRecordSchema.parse(req.body);
    const emotion = await storage.createEmotionRecord(emotionData);
    return res.status(201).json(emotion);
  } catch (error) {
    console.error("Error creating emotion record:", error);
    return res.status(400).json({ error: error.message });
  }
});

// Delete an emotion record
router.delete("/:id", async (req, res) => {
  try {
    const id = parseInt(req.params.id);
    const success = await storage.deleteEmotionRecord(id);
    
    if (!success) {
      return res.status(404).json({ error: "Emotion record not found" });
    }
    
    return res.status(204).send();
  } catch (error) {
    console.error("Error deleting emotion record:", error);
    return res.status(500).json({ error: "Failed to delete emotion record" });
  }
});

// Get emotions by type
router.get("/:userId/byEmotion/:emotion", async (req, res) => {
  try {
    const userId = parseInt(req.params.userId);
    const emotion = req.params.emotion;
    const emotions = await storage.getEmotionRecordsByEmotion(userId, emotion);
    return res.json(emotions);
  } catch (error) {
    console.error("Error retrieving emotions by type:", error);
    return res.status(500).json({ error: "Failed to retrieve emotions by type" });
  }
});

// Get emotions by time range
router.get("/:userId/byTimeRange", async (req, res) => {
  try {
    const userId = parseInt(req.params.userId);
    const startTime = req.query.start ? new Date(req.query.start as string) : new Date(Date.now() - 7 * 24 * 60 * 60 * 1000); // Default to 1 week ago
    const endTime = req.query.end ? new Date(req.query.end as string) : new Date(); // Default to now
    
    const emotions = await storage.getEmotionRecordsByTimeRange(userId, startTime, endTime);
    return res.json(emotions);
  } catch (error) {
    console.error("Error retrieving emotions by time range:", error);
    return res.status(500).json({ error: "Failed to retrieve emotions by time range" });
  }
});

// Get emotion analytics (aggregated data)
router.get("/:userId/analytics", async (req, res) => {
  try {
    const userId = parseInt(req.params.userId);
    const period = (req.query.period as string) || 'week'; // day, week, month, year
    
    let startDate: Date;
    const now = new Date();
    
    switch (period) {
      case 'day':
        startDate = new Date(now.getTime() - 24 * 60 * 60 * 1000);
        break;
      case 'week':
        startDate = new Date(now.getTime() - 7 * 24 * 60 * 60 * 1000);
        break;
      case 'month':
        startDate = new Date(now.getTime() - 30 * 24 * 60 * 60 * 1000);
        break;
      case 'year':
        startDate = new Date(now.getTime() - 365 * 24 * 60 * 60 * 1000);
        break;
      default:
        startDate = new Date(now.getTime() - 7 * 24 * 60 * 60 * 1000);
    }
    
    const emotions = await storage.getEmotionRecordsByTimeRange(userId, startDate, now);
    
    // Group emotions by type and count frequency
    const emotionCounts: Record<string, number> = {};
    const emotionIntensities: Record<string, number[]> = {};
    
    emotions.forEach(record => {
      const emotion = record.emotion.toLowerCase();
      emotionCounts[emotion] = (emotionCounts[emotion] || 0) + 1;
      
      if (!emotionIntensities[emotion]) {
        emotionIntensities[emotion] = [];
      }
      emotionIntensities[emotion].push(record.intensity);
    });
    
    // Calculate average intensities
    const averageIntensities: Record<string, number> = {};
    Object.keys(emotionIntensities).forEach(emotion => {
      const intensities = emotionIntensities[emotion];
      const sum = intensities.reduce((total, intensity) => total + intensity, 0);
      averageIntensities[emotion] = sum / intensities.length;
    });
    
    // Get emotion trends over time
    let interval: number;
    let intervalUnit: string;
    
    switch (period) {
      case 'day':
        interval = 60 * 60 * 1000; // 1 hour in milliseconds
        intervalUnit = 'hour';
        break;
      case 'week':
        interval = 24 * 60 * 60 * 1000; // 1 day
        intervalUnit = 'day';
        break;
      case 'month':
        interval = 24 * 60 * 60 * 1000; // 1 day
        intervalUnit = 'day';
        break;
      case 'year':
        interval = 7 * 24 * 60 * 60 * 1000; // 1 week
        intervalUnit = 'week';
        break;
      default:
        interval = 24 * 60 * 60 * 1000; // 1 day
        intervalUnit = 'day';
    }
    
    const emotionTrends: any[] = [];
    let currentTime = new Date(startDate);
    
    while (currentTime <= now) {
      const nextTime = new Date(currentTime.getTime() + interval);
      
      const periodEmotions = emotions.filter(e => 
        e.timestamp >= currentTime && e.timestamp < nextTime
      );
      
      // Find dominant emotion for this period
      const emotionsByType: Record<string, number> = {};
      periodEmotions.forEach(e => {
        const emotion = e.emotion.toLowerCase();
        emotionsByType[emotion] = (emotionsByType[emotion] || 0) + 1;
      });
      
      let dominantEmotion = null;
      let maxCount = 0;
      
      Object.entries(emotionsByType).forEach(([emotion, count]) => {
        if (count > maxCount) {
          dominantEmotion = emotion;
          maxCount = count;
        }
      });
      
      emotionTrends.push({
        timeStart: currentTime,
        timeEnd: nextTime,
        count: periodEmotions.length,
        dominantEmotion: dominantEmotion,
        emotionCounts: emotionsByType
      });
      
      currentTime = nextTime;
    }
    
    const analytics = {
      period,
      totalRecords: emotions.length,
      emotionCounts,
      averageIntensities,
      trends: emotionTrends,
      intervalUnit
    };
    
    return res.json(analytics);
  } catch (error) {
    console.error("Error generating emotion analytics:", error);
    return res.status(500).json({ error: "Failed to generate emotion analytics" });
  }
});

export default router;