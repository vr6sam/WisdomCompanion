import { Router } from 'express';
import { storage } from '../storage';
import OpenAI from 'openai';
import { z } from 'zod';

const router = Router();

// Initialize OpenAI client
const openai = new OpenAI({ apiKey: process.env.OPENAI_API_KEY });

// Storage for user history data (in-memory for demo)
const userHistoryData = new Map<number, any[]>();
const userPatternsData = new Map<number, any[]>();
const userPreferencesData = new Map<number, any[]>();

// Schema validation for history item 
const historyItemSchema = z.object({
  type: z.enum(['search', 'app', 'website', 'message', 'reminder', 'location']),
  content: z.string(),
  timestamp: z.string().or(z.date()),
  metadata: z.record(z.any()).optional()
});

// Schema validation for pattern analysis
const patternAnalysisSchema = z.object({
  history: z.array(historyItemSchema),
  phoneData: z.object({
    apps: z.array(z.any()).optional(),
    browserHistory: z.array(z.any()).optional(),
    usageStats: z.any().optional()
  }).optional(),
  currentContext: z.object({
    time: z.string().or(z.date()),
    dayOfWeek: z.number(),
    timeOfDay: z.number()
  })
});

// Schema validation for action prediction
const actionPredictionSchema = z.object({
  currentTime: z.string().or(z.date()),
  currentIntents: z.array(z.any()).optional(),
  userPatterns: z.array(z.any()).optional(),
  recentHistory: z.array(historyItemSchema).optional()
});

// Schema validation for suggestion generation
const suggestionRequestSchema = z.object({
  currentTime: z.string().or(z.date()),
  currentIntent: z.any().nullable(),
  currentNeed: z.any().nullable(),
  relevantPatterns: z.array(z.any()).optional(),
  keyPreferences: z.array(z.any()).optional(),
  recentHistory: z.array(historyItemSchema).optional()
});

// Get user history and patterns
router.get('/', async (req, res) => {
  try {
    const userId = 1; // For demo, using default user
    
    // Get user history from storage
    const historyItems = userHistoryData.get(userId) || [];
    const patterns = userPatternsData.get(userId) || [];
    const preferences = userPreferencesData.get(userId) || [];
    
    res.json({
      history: historyItems,
      patterns,
      preferences
    });
  } catch (error) {
    console.error('Error fetching user history:', error);
    res.status(500).json({ error: 'Failed to fetch user history' });
  }
});

// Record a new history item
router.post('/', async (req, res) => {
  try {
    const userId = 1; // For demo, using default user
    const historyItem = historyItemSchema.parse(req.body);
    
    // Get existing history or initialize empty array
    const userHistory = userHistoryData.get(userId) || [];
    
    // Add new item to the beginning
    userHistory.unshift(historyItem);
    
    // Limit history size (optional)
    if (userHistory.length > 1000) {
      userHistory.length = 1000;
    }
    
    // Update storage
    userHistoryData.set(userId, userHistory);
    
    res.status(201).json({ success: true });
  } catch (error) {
    console.error('Error recording history item:', error);
    res.status(400).json({ error: 'Invalid history item data' });
  }
});

// Analyze patterns in user history
router.post('/analyze-patterns', async (req, res) => {
  try {
    const userId = 1; // For demo, using default user
    const analysisData = patternAnalysisSchema.parse(req.body);
    
    // Use OpenAI for pattern analysis
    const prompt = `
      Analyze the following user history data and identify patterns, preferences, likely intents, and needs.
      
      User History: ${JSON.stringify(analysisData.history.slice(0, 50))}
      
      Phone Data: ${JSON.stringify(analysisData.phoneData || {})}
      
      Current Context: ${JSON.stringify(analysisData.currentContext)}
      
      Return a comprehensive analysis as a JSON object with these properties:
      1. patterns: Array of user behavior patterns, each with type, description, frequency, examples, confidence, and lastUpdated
      2. preferences: Array of user preferences, each with category, subcategory, value, confidence, and lastUpdated
      3. currentIntents: Array of likely current user intents, each with intent, probability, evidenceStrength, suggestedActions, and relatedPatterns
      4. currentNeeds: Array of detected user needs, each with need, urgency, importance, lastDetected, and suggestedResponses
      
      Make the analysis extremely insightful, proactive, and personalized based on the observable patterns.
      Only output the JSON object without any other text.
    `;
    
    const completion = await openai.chat.completions.create({
      model: "gpt-4o", // the newest OpenAI model is "gpt-4o" which was released May 13, 2024. do not change this unless explicitly requested by the user
      messages: [
        { role: "system", content: "You are an expert in user behavior analysis and pattern recognition." },
        { role: "user", content: prompt }
      ],
      response_format: { type: "json_object" }
    });
    
    // Parse the JSON from the response
    const content = completion.choices[0].message.content.trim();
    const analysisResults = JSON.parse(content);
    
    // Store the patterns and preferences
    userPatternsData.set(userId, analysisResults.patterns || []);
    userPreferencesData.set(userId, analysisResults.preferences || []);
    
    res.json(analysisResults);
  } catch (error) {
    console.error('Error analyzing patterns:', error);
    res.status(500).json({ error: 'Pattern analysis failed' });
  }
});

// Predict user's next likely actions
router.post('/predict-actions', async (req, res) => {
  try {
    const predictionData = actionPredictionSchema.parse(req.body);
    
    // Use OpenAI to predict next actions
    const prompt = `
      Based on the following user data, predict the most likely actions the user might take next.
      
      Current Time: ${predictionData.currentTime}
      Current Intents: ${JSON.stringify(predictionData.currentIntents || [])}
      User Patterns: ${JSON.stringify(predictionData.userPatterns || [])}
      Recent History: ${JSON.stringify(predictionData.recentHistory || [])}
      
      Return a JSON object with a property 'predictedActions' containing an array of strings
      describing the most likely next actions in order of probability.
      
      Only output the JSON object without any other text.
    `;
    
    const completion = await openai.chat.completions.create({
      model: "gpt-4o", // the newest OpenAI model is "gpt-4o" which was released May 13, 2024. do not change this unless explicitly requested by the user
      messages: [
        { role: "system", content: "You are an expert in predicting user behavior based on patterns." },
        { role: "user", content: prompt }
      ],
      response_format: { type: "json_object" }
    });
    
    // Parse the JSON from the response
    const content = completion.choices[0].message.content.trim();
    const predictions = JSON.parse(content);
    
    res.json(predictions);
  } catch (error) {
    console.error('Error predicting actions:', error);
    res.status(500).json({ error: 'Action prediction failed' });
  }
});

// Generate personalized suggestion
router.post('/generate-suggestion', async (req, res) => {
  try {
    const suggestionData = suggestionRequestSchema.parse(req.body);
    
    // Use OpenAI to generate suggestion
    const prompt = `
      Generate a personalized suggestion for the user based on the following data:
      
      Current Time: ${suggestionData.currentTime}
      Current Intent: ${JSON.stringify(suggestionData.currentIntent)}
      Current Need: ${JSON.stringify(suggestionData.currentNeed)}
      Relevant Patterns: ${JSON.stringify(suggestionData.relevantPatterns || [])}
      Key Preferences: ${JSON.stringify(suggestionData.keyPreferences || [])}
      Recent History: ${JSON.stringify(suggestionData.recentHistory || [])}
      
      Return a JSON object with:
      1. suggestion: A concise, helpful suggestion that is proactive and personalized
      2. reasoning: Brief explanation of why this suggestion is being made
      3. confidence: A number between 0-1 indicating your confidence in this suggestion
      
      Make the suggestion proactive, insightful, and tailored to what the user would find most helpful right now.
      Only output the JSON object without any other text.
    `;
    
    const completion = await openai.chat.completions.create({
      model: "gpt-4o", // the newest OpenAI model is "gpt-4o" which was released May 13, 2024. do not change this unless explicitly requested by the user
      messages: [
        { role: "system", content: "You are an expert in making proactive, helpful suggestions based on user behavior patterns." },
        { role: "user", content: prompt }
      ],
      response_format: { type: "json_object" }
    });
    
    // Parse the JSON from the response
    const content = completion.choices[0].message.content.trim();
    const suggestion = JSON.parse(content);
    
    res.json(suggestion);
  } catch (error) {
    console.error('Error generating suggestion:', error);
    res.status(500).json({ error: 'Failed to generate suggestion' });
  }
});

export default router;