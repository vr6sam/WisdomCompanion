import express from 'express';
import Anthropic from '@anthropic-ai/sdk';

const router = express.Router();
const anthropic = new Anthropic({
  apiKey: process.env.ANTHROPIC_API_KEY,
});

/**
 * Anthropic Claude API endpoint
 * Accepts messages array and optional parameters
 */
router.post('/chat', async (req, res) => {
  try {
    const { messages, model = 'claude-3-7-sonnet-20250219', maxTokens, temperature, system } = req.body;
    
    if (!messages || !Array.isArray(messages)) {
      return res.status(400).json({ error: 'Messages array is required' });
    }
    
    const response = await anthropic.messages.create({
      model: model,
      messages: messages,
      system: system,
      max_tokens: maxTokens || 1024,
      temperature: temperature || 0.7,
    });
    
    return res.json(response);
  } catch (error) {
    console.error('Error in Anthropic chat endpoint:', error);
    return res.status(500).json({ error: `Anthropic API Error: ${error.message}` });
  }
});

/**
 * Vision API endpoint for image analysis
 */
router.post('/vision', async (req, res) => {
  try {
    const { prompt, imageBase64, model = 'claude-3-7-sonnet-20250219', maxTokens, temperature } = req.body;
    
    if (!prompt) {
      return res.status(400).json({ error: 'Prompt is required' });
    }
    
    if (!imageBase64) {
      return res.status(400).json({ error: 'Image base64 data is required' });
    }
    
    const response = await anthropic.messages.create({
      model: model,
      max_tokens: maxTokens || 1024,
      temperature: temperature || 0.7,
      messages: [{
        role: 'user',
        content: [
          {
            type: 'text',
            text: prompt
          },
          {
            type: 'image',
            source: {
              type: 'base64',
              media_type: 'image/jpeg',
              data: imageBase64
            }
          }
        ]
      }]
    });
    
    return res.json(response);
  } catch (error) {
    console.error('Error in Anthropic vision endpoint:', error);
    return res.status(500).json({ error: `Anthropic API Error: ${error.message}` });
  }
});

/**
 * Test endpoint to verify Anthropic API key is working
 */
router.get('/test', async (req, res) => {
  try {
    const response = await anthropic.messages.create({
      model: 'claude-3-7-sonnet-20250219',
      max_tokens: 10,
      messages: [{ role: 'user', content: 'Hello' }]
    });
    
    return res.json({
      success: true,
      message: 'Anthropic API key is valid',
      modelUsed: 'claude-3-7-sonnet-20250219'
    });
  } catch (error) {
    console.error('Error testing Anthropic API:', error);
    return res.status(500).json({
      success: false,
      message: `Anthropic API Error: ${error.message}`
    });
  }
});

export default router;