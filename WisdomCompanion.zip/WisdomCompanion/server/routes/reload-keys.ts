import { Request, Response } from 'express';
import { multiAIService } from '../services/index';

/**
 * Reload API keys from the client
 * This allows users to provide their own API keys
 */
export async function reloadApiKeys(req: Request, res: Response) {
  try {
    const { openai_api_key, anthropic_api_key } = req.body;
    
    // Set as environment variables
    if (openai_api_key) {
      process.env.OPENAI_API_KEY = openai_api_key;
    }
    
    if (anthropic_api_key) {
      process.env.ANTHROPIC_API_KEY = anthropic_api_key;
    }
    
    // Refresh AI clients to use the new keys
    if (multiAIService && typeof multiAIService.refreshClients === 'function') {
      multiAIService.refreshClients();
      console.log('AI clients refreshed with new API keys');
    }
    
    return res.json({
      success: true,
      message: 'API keys reloaded successfully'
    });
  } catch (error) {
    console.error('Error reloading API keys:', error);
    
    return res.status(500).json({
      success: false,
      message: 'Error reloading API keys'
    });
  }
}