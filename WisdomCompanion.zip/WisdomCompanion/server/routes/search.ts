import { Router } from 'express';
import OpenAI from 'openai';
import axios from 'axios';
import { z } from 'zod';

const router = Router();

// Initialize OpenAI client
const openai = new OpenAI({ apiKey: process.env.OPENAI_API_KEY });

// Schema validation for search requests
const searchRequestSchema = z.object({
  query: z.string().min(1),
  options: z.object({
    maxResults: z.number().optional().default(10),
    safeSearch: z.boolean().optional().default(true),
    timeRange: z.enum(['day', 'week', 'month', 'year', 'all']).optional().default('all'),
    region: z.string().optional()
  }).optional().default({})
});

// Schema validation for Wikipedia search
const wikipediaRequestSchema = z.object({
  query: z.string().min(1)
});

// Schema validation for news search
const newsRequestSchema = z.object({
  query: z.string().min(1),
  count: z.number().optional().default(5)
});

// General web search endpoint
router.post('/', async (req, res) => {
  try {
    const { query, options } = searchRequestSchema.parse(req.body);
    
    // Use OpenAI to perform the search
    // In a production app, we would use a real search API like Google, Bing, etc.
    const prompt = `
      Please perform a web search for "${query}" and provide the top ${options.maxResults} results.
      For each result, include: title, URL, and a brief snippet.
      Format the results as a JSON array with objects containing: title, url, snippet, and source.
      
      Only return the JSON data without any other text.
    `;
    
    const completion = await openai.chat.completions.create({
      model: "gpt-4o", // the newest OpenAI model is "gpt-4o" which was released May 13, 2024. do not change this unless explicitly requested by the user
      messages: [
        { role: "system", content: "You are a search engine assistant that finds information online." },
        { role: "user", content: prompt }
      ],
      response_format: { type: "json_object" }
    });
    
    // Parse the JSON from the response
    const content = completion.choices[0].message.content.trim();
    const results = JSON.parse(content);
    
    res.json(results.results || []);
  } catch (error) {
    console.error('Search API error:', error);
    res.status(500).json({ error: 'Failed to perform search' });
  }
});

// Wikipedia search endpoint
router.post('/wikipedia', async (req, res) => {
  try {
    const { query } = wikipediaRequestSchema.parse(req.body);
    
    // Use OpenAI to simulate Wikipedia search
    // In a production app, we would use actual Wikipedia API
    const prompt = `
      Please provide Wikipedia information about "${query}".
      Include: title, a comprehensive extract (about 2-3 paragraphs), and the URL to the Wikipedia page.
      Format as JSON with: title, extract, and url properties.
      
      Only return the JSON data without any other text.
    `;
    
    const completion = await openai.chat.completions.create({
      model: "gpt-4o", // the newest OpenAI model is "gpt-4o" which was released May 13, 2024. do not change this unless explicitly requested by the user
      messages: [
        { role: "system", content: "You are a Wikipedia lookup assistant that provides accurate information." },
        { role: "user", content: prompt }
      ],
      response_format: { type: "json_object" }
    });
    
    // Parse the JSON from the response
    const content = completion.choices[0].message.content.trim();
    const result = JSON.parse(content);
    
    res.json(result);
  } catch (error) {
    console.error('Wikipedia API error:', error);
    res.status(500).json({ error: 'Failed to retrieve Wikipedia information' });
  }
});

// News search endpoint
router.post('/news', async (req, res) => {
  try {
    const { query, count } = newsRequestSchema.parse(req.body);
    
    // Use OpenAI to simulate news search
    // In a production app, we would use a real news API
    const prompt = `
      Please find the latest news articles about "${query}".
      Provide ${count} results, each with: title, description, source, URL, and publication date.
      Format as a JSON array with objects containing: title, description, url, source, and publishedAt properties.
      
      Only return the JSON data without any other text.
    `;
    
    const completion = await openai.chat.completions.create({
      model: "gpt-4o", // the newest OpenAI model is "gpt-4o" which was released May 13, 2024. do not change this unless explicitly requested by the user
      messages: [
        { role: "system", content: "You are a news search assistant that finds recent news articles." },
        { role: "user", content: prompt }
      ],
      response_format: { type: "json_object" }
    });
    
    // Parse the JSON from the response
    const content = completion.choices[0].message.content.trim();
    const results = JSON.parse(content);
    
    res.json(results.articles || []);
  } catch (error) {
    console.error('News API error:', error);
    res.status(500).json({ error: 'Failed to retrieve news articles' });
  }
});

// Weather information endpoint
router.post('/weather', async (req, res) => {
  try {
    const { location } = req.body;
    
    if (!location) {
      return res.status(400).json({ error: 'Location is required' });
    }
    
    // Use OpenAI to simulate weather data
    // In a production app, we would use a real weather API
    const prompt = `
      Please provide current weather information for "${location}".
      Include: temperature (in Celsius and Fahrenheit), conditions, humidity, wind speed, and forecast for the next 3 days.
      Format as JSON with appropriate properties.
      
      Only return the JSON data without any other text.
    `;
    
    const completion = await openai.chat.completions.create({
      model: "gpt-4o", // the newest OpenAI model is "gpt-4o" which was released May 13, 2024. do not change this unless explicitly requested by the user
      messages: [
        { role: "system", content: "You are a weather information assistant that provides accurate weather data." },
        { role: "user", content: prompt }
      ],
      response_format: { type: "json_object" }
    });
    
    // Parse the JSON from the response
    const content = completion.choices[0].message.content.trim();
    const weatherData = JSON.parse(content);
    
    res.json(weatherData);
  } catch (error) {
    console.error('Weather API error:', error);
    res.status(500).json({ error: 'Failed to retrieve weather information' });
  }
});

export default router;