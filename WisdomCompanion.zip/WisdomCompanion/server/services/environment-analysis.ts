import OpenAI from "openai";
import { storage } from "../storage";
import { InsertEmotionRecord } from "@shared/schema";

// Initialize OpenAI client
const openai = new OpenAI({ apiKey: process.env.OPENAI_API_KEY });
// the newest OpenAI model is "gpt-4o" which was released May 13, 2024. do not change this unless explicitly requested by the user

interface EnvironmentAnalysisResult {
  general: {
    location: string;
    setting: string;
    timeOfDay: string; 
    lighting: string;
    noiseLevel: string;
    peoplePresent: boolean;
    numberOfPeople?: number;
  };
  objects: {
    furniture: string[];
    electronics: string[];
    personalItems: string[];
    other: string[];
  };
  ambience: {
    mood: string;
    formality: string;
    cleanliness: number; // 1-10 scale
    spaciousness: number; // 1-10 scale
    comfort: number; // 1-10 scale
    distractionLevel: number; // 1-10 scale
  };
  context: {
    likelyActivity: string;
    suggestedPurpose: string;
    potentialDistractions: string[];
    environmentalConcerns: string[];
  };
  healthFactors: {
    naturalLight: number; // 1-10 scale
    ergonomics: number; // 1-10 scale
    airQuality: string;
    plantLife: boolean;
    potentialStressors: string[];
  };
  summary: string;
}

/**
 * Analyze the user's environment based on camera image
 */
export async function analyzeEnvironment(
  imageBase64: string, 
  userId: number
): Promise<EnvironmentAnalysisResult> {
  try {
    // Prepare system message with detailed instructions
    const systemMessage = `
      Analyze the image of the user's environment in detail. 
      You are an assistant with expertise in environmental psychology, interior design, and human wellness.
      Provide a comprehensive analysis including:
      
      1. General information (location type, setting, time of day, lighting conditions)
      2. Objects present (furniture, electronics, personal items)
      3. Ambience factors (mood, formality, cleanliness, spaciousness)
      4. Contextual analysis (likely activity, suggested purpose)
      5. Health & wellness factors (natural light, ergonomics, air quality indicators)
      
      Format the response as a JSON object strictly following this structure:
      {
        "general": {
          "location": string,
          "setting": string,
          "timeOfDay": string,
          "lighting": string,
          "noiseLevel": string,
          "peoplePresent": boolean,
          "numberOfPeople": number (optional)
        },
        "objects": {
          "furniture": string[],
          "electronics": string[],
          "personalItems": string[],
          "other": string[]
        },
        "ambience": {
          "mood": string,
          "formality": string,
          "cleanliness": number (1-10),
          "spaciousness": number (1-10),
          "comfort": number (1-10),
          "distractionLevel": number (1-10)
        },
        "context": {
          "likelyActivity": string,
          "suggestedPurpose": string,
          "potentialDistractions": string[],
          "environmentalConcerns": string[]
        },
        "healthFactors": {
          "naturalLight": number (1-10),
          "ergonomics": number (1-10),
          "airQuality": string,
          "plantLife": boolean,
          "potentialStressors": string[]
        },
        "summary": string
      }
      
      Be thorough but concise. Avoid making incorrect assumptions when details aren't visible.
    `;

    // Make the API call to analyze the image
    const response = await openai.chat.completions.create({
      model: "gpt-4o",
      messages: [
        { role: "system", content: systemMessage },
        {
          role: "user",
          content: [
            { type: "text", text: "Please analyze this environment:" },
            {
              type: "image_url",
              image_url: {
                url: `data:image/jpeg;base64,${imageBase64}`
              }
            }
          ]
        }
      ],
      response_format: { type: "json_object" },
      max_tokens: 1000
    });

    // Parse the response
    const analysisResult = JSON.parse(response.choices[0].message.content || "{}") as EnvironmentAnalysisResult;
    
    // Store environment analysis as contextual data
    await storeEnvironmentContext(userId, analysisResult);
    
    return analysisResult;
  } catch (error) {
    console.error("Error analyzing environment:", error);
    // Return a minimal fallback result
    return {
      general: {
        location: "Unknown",
        setting: "Unknown",
        timeOfDay: "Unknown",
        lighting: "Unknown",
        noiseLevel: "Unknown",
        peoplePresent: false
      },
      objects: {
        furniture: [],
        electronics: [],
        personalItems: [],
        other: []
      },
      ambience: {
        mood: "Unknown",
        formality: "Unknown",
        cleanliness: 5,
        spaciousness: 5,
        comfort: 5,
        distractionLevel: 5
      },
      context: {
        likelyActivity: "Unknown",
        suggestedPurpose: "Unknown",
        potentialDistractions: [],
        environmentalConcerns: []
      },
      healthFactors: {
        naturalLight: 5,
        ergonomics: 5,
        airQuality: "Unknown",
        plantLife: false,
        potentialStressors: []
      },
      summary: "Unable to analyze environment"
    };
  }
}

/**
 * Store environment analysis as contextual data for the user
 */
async function storeEnvironmentContext(userId: number, analysis: EnvironmentAnalysisResult): Promise<void> {
  try {
    // Create an emotion record with environmental context
    const environmentContext: InsertEmotionRecord = {
      userId,
      emotion: "environment_snapshot",
      intensity: analysis.ambience.comfort / 10, // Use comfort as intensity scale
      context: analysis.summary,
      sourceType: "environment_camera",
      environmentFactors: {
        location: analysis.general.location,
        lighting: analysis.general.lighting,
        noiseLevel: analysis.general.noiseLevel,
        distractionLevel: analysis.ambience.distractionLevel,
        naturalLight: analysis.healthFactors.naturalLight,
        potentialStressors: analysis.healthFactors.potentialStressors,
        mood: analysis.ambience.mood
      },
      secondaryEmotions: generateMoodMap(analysis)
    };
    
    await storage.createEmotionRecord(environmentContext);
  } catch (error) {
    console.error("Error storing environment context:", error);
  }
}

/**
 * Generate an emotional mood map based on environment analysis
 */
function generateMoodMap(analysis: EnvironmentAnalysisResult): Record<string, number> {
  // Create a mood map with intensity values based on environment analysis
  const moodMap: Record<string, number> = {};
  
  // Calculate calmness (inverse of distraction level)
  moodMap.calm = (10 - analysis.ambience.distractionLevel) / 10;
  
  // Calculate comfort directly from analysis
  moodMap.comfort = analysis.ambience.comfort / 10;
  
  // Estimate focus level (inverse of distractions and environment concerns)
  const distractionFactor = analysis.ambience.distractionLevel / 10;
  const concernsFactor = Math.min(analysis.context.environmentalConcerns.length / 5, 1);
  moodMap.focus = 1 - ((distractionFactor + concernsFactor) / 2);
  
  // Estimate stress level based on stressors and comfort
  const stressorsFactor = Math.min(analysis.healthFactors.potentialStressors.length / 5, 1);
  moodMap.stress = (stressorsFactor + (1 - (analysis.ambience.comfort / 10))) / 2;
  
  // Estimate productivity potential
  moodMap.productivity = (moodMap.focus + moodMap.comfort) / 2;
  
  return moodMap;
}

/**
 * Analyze room safety and identify potential hazards
 */
export async function analyzeRoomSafety(imageBase64: string): Promise<{
  safetyScore: number;
  hazards: string[];
  recommendations: string[];
  wittySummary: string;
}> {
  try {
    const prompt = `
      Analyze this room image for safety hazards and potential risks with a witty, smart, and thoughtful tone.
      Consider: trip hazards, fire risks, ergonomic issues, electrical hazards, 
      blocked exits, poor lighting, and other safety concerns.
      
      Use clever observations and a touch of playful sarcasm in your analysis, but ensure
      the assessment remains helpful and insightful. Think of yourself as a safety inspector
      with both expertise and personality.
      
      Format your response as JSON:
      {
        "safetyScore": number (1-100),
        "hazards": string[],
        "recommendations": string[],
        "wittySummary": string (a brief, clever summary of the safety analysis with a dash of humor)
      }
    `;

    const response = await openai.chat.completions.create({
      model: "gpt-4o",
      messages: [
        { role: "system", content: prompt },
        {
          role: "user",
          content: [
            { type: "image_url", image_url: { url: `data:image/jpeg;base64,${imageBase64}` } }
          ]
        }
      ],
      response_format: { type: "json_object" },
      max_tokens: 500
    });

    const safetyAnalysis = JSON.parse(response.choices[0].message.content || "{}");
    return {
      safetyScore: safetyAnalysis.safetyScore || 50,
      hazards: safetyAnalysis.hazards || [],
      recommendations: safetyAnalysis.recommendations || [],
      wittySummary: safetyAnalysis.wittySummary || "Safety analysis complete. No witty remarks available at this time... which is probably for the best."
    };
  } catch (error) {
    console.error("Error analyzing room safety:", error);
    return {
      safetyScore: 50,
      hazards: ["Unable to analyze safety"],
      recommendations: ["System error during safety analysis"],
      wittySummary: "I tried to analyze your room's safety, but apparently my hazard detection circuits are experiencing their own safety emergency. How ironic."
    };
  }
}

/**
 * Recognize objects in the environment
 */
export async function recognizeObjects(imageBase64: string): Promise<{
  objects: Array<{
    name: string;
    confidence: number;
    position: string;
    insightfulNote?: string;
  }>;
  analysisSummary?: string;
}> {
  try {
    const prompt = `
      Identify and list all significant objects visible in this image with an intellectually curious, witty approach.
      For each object, provide:
      1. The name of the object
      2. Your confidence level in identifying it (0.0-1.0)
      3. A brief description of its position in the image
      4. A clever observation or intellectually curious question about the object
      
      Think like a brilliant, curious observer who notices interesting details and makes insightful connections.
      
      Format your response as JSON:
      {
        "objects": [
          {
            "name": string,
            "confidence": number,
            "position": string,
            "insightfulNote": string (a witty or intellectually curious observation about the object)
          }
        ],
        "analysisSummary": string (a short, clever summary of what these objects might reveal about the environment or its occupant)
      }
    `;

    const response = await openai.chat.completions.create({
      model: "gpt-4o",
      messages: [
        { role: "system", content: prompt },
        {
          role: "user",
          content: [
            { type: "image_url", image_url: { url: `data:image/jpeg;base64,${imageBase64}` } }
          ]
        }
      ],
      response_format: { type: "json_object" },
      max_tokens: 800
    });

    const objectsResult = JSON.parse(response.choices[0].message.content || "{}");
    return {
      objects: objectsResult.objects || [],
      analysisSummary: objectsResult.analysisSummary || "My intellectual curiosity is piqued by this collection of objects - they speak volumes about the unseen narrative of this space."
    };
  } catch (error) {
    console.error("Error recognizing objects:", error);
    return {
      objects: [],
      analysisSummary: "My intellectual curiosity has hit a wall. I'm fascinated by the paradox of seeing without being able to recognize - a rather philosophical dilemma, wouldn't you say?"
    };
  }
}

/**
 * Analyze workspace ergonomics
 */
export async function analyzeWorkspaceErgonomics(imageBase64: string): Promise<{
  overallScore: number;
  issues: string[];
  recommendations: string[];
  wittySummary: string;
}> {
  try {
    const prompt = `
      Analyze this workspace for ergonomic issues with a witty, smart, and thoughtful tone.
      Consider: desk height, chair position, monitor height and distance,
      keyboard position, lighting, and overall posture concerns.
      
      Add clever observations with a touch of playful sarcasm. Think of yourself as an
      ergonomics expert with both expertise and personality who genuinely cares about
      the user's wellbeing but isn't afraid to call out poor ergonomic choices with humor.
      
      Format your response as JSON:
      {
        "overallScore": number (1-100),
        "issues": string[],
        "recommendations": string[],
        "wittySummary": string (a brief, clever summary of the ergonomic analysis with a touch of humor)
      }
    `;

    const response = await openai.chat.completions.create({
      model: "gpt-4o",
      messages: [
        { role: "system", content: prompt },
        {
          role: "user",
          content: [
            { type: "image_url", image_url: { url: `data:image/jpeg;base64,${imageBase64}` } }
          ]
        }
      ],
      response_format: { type: "json_object" },
      max_tokens: 500
    });

    const ergonomicsAnalysis = JSON.parse(response.choices[0].message.content || "{}");
    return {
      overallScore: ergonomicsAnalysis.overallScore || 50,
      issues: ergonomicsAnalysis.issues || [],
      recommendations: ergonomicsAnalysis.recommendations || [],
      wittySummary: ergonomicsAnalysis.wittySummary || "Your workspace and I have something in common - we both need some adjustments to function properly."
    };
  } catch (error) {
    console.error("Error analyzing workspace ergonomics:", error);
    return {
      overallScore: 50,
      issues: ["Unable to analyze ergonomics"],
      recommendations: ["System error during ergonomics analysis"],
      wittySummary: "I'm intellectually curious about your ergonomic setup, but my neural pathways seem to be experiencing their own ergonomic crisis. How meta."
    };
  }
}