// Multi-AI service for server-side operations
// This service coordinates between different AI providers and handles fallbacks

import OpenAI from 'openai';
import Anthropic from '@anthropic-ai/sdk';
import { analyzeTextEmotion } from '../utils';

// AI Provider types
export type AIProvider = 'openai' | 'anthropic' | 'auto';

/**
 * Server-side Multi-AI Service
 * Coordinates between different AI providers and handles fallbacks
 */
export class MultiAIService {
  private openai: OpenAI;
  private anthropic: Anthropic;
  private openaiAvailable: boolean = false;
  private anthropicAvailable: boolean = false;
  private preferredProvider: AIProvider = 'auto';

  constructor() {
    // Initialize the OpenAI client
    this.openai = new OpenAI({
      apiKey: process.env.OPENAI_API_KEY,
    });

    // Initialize the Anthropic client
    this.anthropic = new Anthropic({
      apiKey: process.env.ANTHROPIC_API_KEY,
    });

    // Check API availability on startup
    this.checkProviderStatus();
  }
  
  /**
   * Refresh API clients after new keys are loaded
   */
  refreshClients(): void {
    // Re-initialize clients with updated API keys
    this.openai = new OpenAI({
      apiKey: process.env.OPENAI_API_KEY,
    });
    
    this.anthropic = new Anthropic({
      apiKey: process.env.ANTHROPIC_API_KEY,
    });
    
    // Re-check availability with new keys
    this.checkProviderStatus();
  }

  /**
   * Check if both AI providers are available
   */
  async checkProviderStatus(): Promise<void> {
    try {
      await this.testOpenAI();
      this.openaiAvailable = true;
      console.log('OpenAI is available');
    } catch (error) {
      this.openaiAvailable = false;
      console.error('OpenAI is not available:', error);
    }

    try {
      await this.testAnthropic();
      this.anthropicAvailable = true;
      console.log('Anthropic is available');
    } catch (error) {
      this.anthropicAvailable = false;
      console.error('Anthropic is not available:', error);
    }
  }

  /**
   * Test OpenAI API connectivity
   */
  async testOpenAI(): Promise<boolean> {
    try {
      const response = await this.openai.chat.completions.create({
        model: "gpt-4o",
        messages: [{ role: "user", content: "Hello, are you working?" }],
        max_tokens: 5
      });
      return !!response.choices[0].message.content;
    } catch (error) {
      throw new Error(`OpenAI test error: ${error}`);
    }
  }

  /**
   * Test Anthropic API connectivity
   */
  async testAnthropic(): Promise<boolean> {
    try {
      const response = await this.anthropic.messages.create({
        model: "claude-3-7-sonnet-20250219",
        max_tokens: 5,
        messages: [{ role: "user", content: "Hello, are you working?" }]
      });
      
      // Handle different response structures based on Anthropic API version
      if (response.content && response.content.length > 0) {
        return response.content[0].type === 'text'; // Just check for content presence
      }
      return false;
    } catch (error) {
      throw new Error(`Anthropic test error: ${error}`);
    }
  }

  /**
   * Generate text response using the preferred AI provider
   * Falls back to alternative provider if the preferred one fails
   */
  async generateResponse(
    prompt: string, 
    context: string = '',
    provider: AIProvider = this.preferredProvider
  ): Promise<string> {
    // Emergency fallback responses when APIs are unavailable
    const fallbackResponses = [
      "I'm currently experiencing connectivity issues with my thinking system. I'll be fully operational soon.",
      "My advanced thinking capabilities are temporarily offline. I'm still here to assist you, but with limited responses for now.",
      "I'm having trouble accessing my knowledge base at the moment. Please try again in a few moments.",
      "I'm currently operating in limited mode while my main systems reconnect. I'll be back to full capacity shortly.",
      "My advanced reasoning systems are currently updating. I'll be able to provide more detailed responses soon."
    ];
    
    try {
      // If auto provider selected, try available providers in order
      if (provider === 'auto') {
        if (this.openaiAvailable) {
          try {
            return await this.generateOpenAIResponse(prompt, context);
          } catch (error) {
            console.error('OpenAI generation failed, trying Anthropic:', error);
            
            // Try Anthropic if available
            if (this.anthropicAvailable) {
              try {
                return await this.generateAnthropicResponse(prompt, context);
              } catch (anthropicError) {
                console.error('Anthropic fallback also failed:', anthropicError);
                return this.getFallbackResponse(prompt, fallbackResponses);
              }
            } else {
              return this.getFallbackResponse(prompt, fallbackResponses);
            }
          }
        } else if (this.anthropicAvailable) {
          try {
            return await this.generateAnthropicResponse(prompt, context);
          } catch (error) {
            console.error('Anthropic generation failed:', error);
            return this.getFallbackResponse(prompt, fallbackResponses);
          }
        } else {
          console.warn('No AI providers available, using fallback response');
          return this.getFallbackResponse(prompt, fallbackResponses);
        }
      } 
      // Specific provider requested
      else if (provider === 'openai') {
        if (this.openaiAvailable) {
          try {
            return await this.generateOpenAIResponse(prompt, context);
          } catch (error) {
            console.error('OpenAI generation failed:', error);
            return this.getFallbackResponse(prompt, fallbackResponses);
          }
        } else {
          console.warn('OpenAI not available, using fallback response');
          return this.getFallbackResponse(prompt, fallbackResponses);
        }
      } else if (provider === 'anthropic') {
        if (this.anthropicAvailable) {
          try {
            return await this.generateAnthropicResponse(prompt, context);
          } catch (error) {
            console.error('Anthropic generation failed:', error);
            return this.getFallbackResponse(prompt, fallbackResponses);
          }
        } else {
          console.warn('Anthropic not available, using fallback response');
          return this.getFallbackResponse(prompt, fallbackResponses);
        }
      }
      
      return this.getFallbackResponse(prompt, fallbackResponses);
    } catch (error) {
      console.error('Error in multiAI generateResponse:', error);
      return this.getFallbackResponse(prompt, fallbackResponses);
    }
  }
  
  /**
   * Get contextually appropriate fallback response
   */
  private getFallbackResponse(prompt: string, fallbackResponses: string[]): string {
    // For questions, use a specific response
    if (prompt.trim().endsWith('?')) {
      return "I'm sorry, I can't answer questions right now while my knowledge systems are updating. Please try again later.";
    }
    
    // For greetings, respond appropriately
    if (/^(hi|hello|hey|greetings)/i.test(prompt.trim())) {
      return "Hello! I'm currently operating in limited mode while my systems are updating. I'll be fully operational soon.";
    }
    
    // Pick a random fallback response for other cases
    const randomIndex = Math.floor(Math.random() * fallbackResponses.length);
    return fallbackResponses[randomIndex];
  }

  /**
   * Generate a response using OpenAI
   */
  private async generateOpenAIResponse(prompt: string, context: string = ''): Promise<string> {
    const messages = [];
    
    // Add system message with context if provided
    if (context) {
      messages.push({
        role: "system",
        content: `Use the following context about the user and conversation: ${context}`
      });
    }
    
    // Add user message
    messages.push({
      role: "user",
      content: prompt
    });
    
    // Generate response
    const response = await this.openai.chat.completions.create({
      model: "gpt-4o", // the newest OpenAI model is "gpt-4o" which was released May 13, 2024. do not change this unless explicitly requested by the user
      messages,
      temperature: 0.7,
      max_tokens: 800
    });
    
    return response.choices[0].message.content || "I couldn't generate a response at this time.";
  }

  /**
   * Generate a response using Anthropic
   */
  private async generateAnthropicResponse(prompt: string, context: string = ''): Promise<string> {
    // Prepare system prompt with context if provided
    const systemPrompt = context ? 
      `You are a helpful assistant. Use the following context about the user and conversation: ${context}` : 
      "You are a helpful assistant.";
    
    // Generate response
    const response = await this.anthropic.messages.create({
      model: "claude-3-7-sonnet-20250219", // the newest Anthropic model is "claude-3-7-sonnet-20250219" which was released February 24, 2025
      system: systemPrompt,
      max_tokens: 800,
      messages: [
        { role: "user", content: prompt }
      ]
    });
    
    // Access the content safely by checking the type
    const contentBlock = response.content[0];
    if (contentBlock && contentBlock.type === 'text') {
      // @ts-ignore - Type definitions might be out of date, but this works at runtime
      return contentBlock.text || "I couldn't generate a response at this time.";
    }
    return "I couldn't generate a response at this time.";
  }

  /**
   * Analyze an image to detect emotions
   */
  async detectEmotion(imageBase64: string): Promise<string> {
    try {
      if (this.openaiAvailable) {
        try {
          return await this.detectEmotionOpenAI(imageBase64);
        } catch (error) {
          console.error('OpenAI emotion detection failed, trying Anthropic:', error);
          if (this.anthropicAvailable) {
            try {
              return await this.detectEmotionAnthropic(imageBase64);
            } catch (anthropicError) {
              console.error('Anthropic emotion detection fallback failed:', anthropicError);
              return 'neutral'; // Default fallback
            }
          }
          return 'neutral';
        }
      } else if (this.anthropicAvailable) {
        try {
          return await this.detectEmotionAnthropic(imageBase64);
        } catch (error) {
          console.error('Anthropic emotion detection failed:', error);
          return 'neutral';
        }
      }
    } catch (error) {
      console.error('Error in emotion detection:', error);
    }
    
    return 'neutral';
  }
  
  /**
   * Detect emotion in an image using OpenAI
   */
  private async detectEmotionOpenAI(imageBase64: string): Promise<string> {
    const response = await this.openai.chat.completions.create({
      model: "gpt-4o",
      messages: [
        {
          role: "user",
          content: [
            {
              type: "text",
              text: "Analyze the facial expression in this image. What is the primary emotion being expressed? Respond with just one word: happy, sad, angry, surprised, disgusted, fearful, or neutral."
            },
            {
              type: "image_url",
              image_url: {
                url: `data:image/jpeg;base64,${imageBase64}`
              }
            }
          ]
        }
      ],
      max_tokens: 10
    });
    
    const emotion = response.choices[0].message.content?.toLowerCase().trim() || 'neutral';
    
    // Normalize to one of our standard emotions
    const validEmotions = ['happy', 'sad', 'angry', 'surprised', 'disgusted', 'fearful', 'neutral'];
    return validEmotions.includes(emotion) ? emotion : 'neutral';
  }
  
  /**
   * Detect emotion in an image using Anthropic
   */
  private async detectEmotionAnthropic(imageBase64: string): Promise<string> {
    const response = await this.anthropic.messages.create({
      model: "claude-3-7-sonnet-20250219",
      max_tokens: 10,
      messages: [
        {
          role: "user",
          content: [
            {
              type: "text",
              text: "Analyze the facial expression in this image. What is the primary emotion being expressed? Respond with just one word: happy, sad, angry, surprised, disgusted, fearful, or neutral."
            },
            {
              type: "image",
              source: {
                type: "base64",
                media_type: "image/jpeg",
                data: imageBase64
              }
            }
          ]
        }
      ]
    });
    
    // Access the content safely
    let emotion = 'neutral';
    const contentBlock = response.content[0];
    if (contentBlock && contentBlock.type === 'text') {
      // @ts-ignore - Handle type mismatch safely
      emotion = contentBlock.text?.toLowerCase().trim() || 'neutral';
    }
    
    // Normalize to one of our standard emotions
    const validEmotions = ['happy', 'sad', 'angry', 'surprised', 'disgusted', 'fearful', 'neutral'];
    return validEmotions.includes(emotion) ? emotion : 'neutral';
  }
  
  /**
   * Analyze image and return a description
   */
  async analyzeImage(
    imageBase64: string,
    prompt: string = 'Analyze this image and describe what you see.'
  ): Promise<string> {
    try {
      if (this.openaiAvailable) {
        try {
          return await this.analyzeImageOpenAI(imageBase64, prompt);
        } catch (error) {
          console.error('OpenAI image analysis failed, trying Anthropic:', error);
          if (this.anthropicAvailable) {
            try {
              return await this.analyzeImageAnthropic(imageBase64, prompt);
            } catch (anthropicError) {
              console.error('Anthropic image analysis fallback failed:', anthropicError);
              return "I'm unable to analyze this image at the moment.";
            }
          }
          return "I'm unable to analyze this image at the moment.";
        }
      } else if (this.anthropicAvailable) {
        try {
          return await this.analyzeImageAnthropic(imageBase64, prompt);
        } catch (error) {
          console.error('Anthropic image analysis failed:', error);
          return "I'm unable to analyze this image at the moment.";
        }
      }
    } catch (error) {
      console.error('Error in image analysis:', error);
    }
    
    return "I'm unable to analyze this image at the moment.";
  }
  
  /**
   * Analyze image using OpenAI
   */
  private async analyzeImageOpenAI(imageBase64: string, prompt: string): Promise<string> {
    const response = await this.openai.chat.completions.create({
      model: "gpt-4o",
      messages: [
        {
          role: "user",
          content: [
            {
              type: "text",
              text: prompt
            },
            {
              type: "image_url",
              image_url: {
                url: `data:image/jpeg;base64,${imageBase64}`
              }
            }
          ]
        }
      ],
      max_tokens: 500
    });
    
    return response.choices[0].message.content || "I couldn't analyze this image.";
  }
  
  /**
   * Analyze image using Anthropic
   */
  private async analyzeImageAnthropic(imageBase64: string, prompt: string): Promise<string> {
    const response = await this.anthropic.messages.create({
      model: "claude-3-7-sonnet-20250219",
      max_tokens: 500,
      messages: [
        {
          role: "user",
          content: [
            {
              type: "text",
              text: prompt
            },
            {
              type: "image",
              source: {
                type: "base64",
                media_type: "image/jpeg",
                data: imageBase64
              }
            }
          ]
        }
      ]
    });
    
    // Access content safely
    const contentBlock = response.content[0];
    if (contentBlock && contentBlock.type === 'text') {
      // @ts-ignore - Handle type mismatch safely
      return contentBlock.text || "I couldn't analyze this image.";
    }
    return "I couldn't analyze this image.";
  }
  
  /**
   * Analyze the environment in an image
   */
  async analyzeEnvironment(imageBase64: string): Promise<any> {
    // Create a default environment analysis in case of failure
    const defaultEnvAnalysis = {
      lighting: 'moderate',
      objects: [],
      scene: 'unknown',
      peopleCount: 0,
      isBusy: false,
      isOutdoors: false,
      hazards: []
    };
    
    try {
      // Determine which providers are available
      let useProvider: 'openai' | 'anthropic' | null = null;
      
      if (this.openaiAvailable) {
        useProvider = 'openai';
      } else if (this.anthropicAvailable) {
        useProvider = 'anthropic';
      }
      
      if (!useProvider) {
        console.warn('No providers available for environment analysis');
        return defaultEnvAnalysis;
      }
      
      const analysisPrompt = `
        Analyze this environment image and provide a structured JSON response with the following fields:
        - lighting: the brightness level (dark/dim/moderate/bright)
        - objects: array of notable objects visible
        - scene: brief description of the setting (e.g., office, living room)
        - peopleCount: estimated number of people visible
        - isBusy: boolean indicating if the environment appears crowded or busy
        - isOutdoors: boolean indicating if this is an indoor or outdoor scene
        - hazards: array of any potential hazards or dangers visible
        
        Format as valid JSON only.
      `;
      
      let analysisResult;
      
      if (useProvider === 'openai') {
        try {
          const response = await this.openai.chat.completions.create({
            model: "gpt-4o",
            response_format: { type: "json_object" },
            messages: [
              {
                role: "user",
                content: [
                  {
                    type: "text",
                    text: analysisPrompt
                  },
                  {
                    type: "image_url",
                    image_url: {
                      url: `data:image/jpeg;base64,${imageBase64}`
                    }
                  }
                ]
              }
            ],
            max_tokens: 800
          });
          
          try {
            analysisResult = JSON.parse(response.choices[0].message.content || '{}');
          } catch (parseError) {
            console.error('Error parsing OpenAI environment analysis JSON:', parseError);
            return defaultEnvAnalysis;
          }
        } catch (openaiError) {
          console.error('OpenAI environment analysis failed:', openaiError);
          if (this.anthropicAvailable) {
            useProvider = 'anthropic';
          } else {
            return defaultEnvAnalysis;
          }
        }
      }
      
      if (useProvider === 'anthropic') {
        try {
          const response = await this.anthropic.messages.create({
            model: "claude-3-7-sonnet-20250219",
            max_tokens: 800,
            messages: [
              {
                role: "user",
                content: [
                  {
                    type: "text",
                    text: analysisPrompt
                  },
                  {
                    type: "image",
                    source: {
                      type: "base64",
                      media_type: "image/jpeg",
                      data: imageBase64
                    }
                  }
                ]
              }
            ]
          });
          
          // Extract JSON from response
          let responseText = '';
          // Access the content safely
          const contentBlock = response.content[0];
          if (contentBlock && contentBlock.type === 'text') {
            // @ts-ignore - Type definitions might be out of date
            responseText = contentBlock.text || '';
          }
          const jsonMatch = responseText.match(/\{[\s\S]*\}/);
          
          if (jsonMatch) {
            try {
              analysisResult = JSON.parse(jsonMatch[0]);
            } catch (parseError) {
              console.error('Error parsing Anthropic environment analysis JSON:', parseError);
              return defaultEnvAnalysis;
            }
          } else {
            console.error('No JSON found in Anthropic environment analysis response');
            return defaultEnvAnalysis;
          }
        } catch (anthropicError) {
          console.error('Anthropic environment analysis failed:', anthropicError);
          return defaultEnvAnalysis;
        }
      }
      
      // Validate and normalize the result
      return {
        lighting: analysisResult?.lighting || defaultEnvAnalysis.lighting,
        objects: Array.isArray(analysisResult?.objects) ? analysisResult.objects : defaultEnvAnalysis.objects,
        scene: analysisResult?.scene || defaultEnvAnalysis.scene,
        peopleCount: typeof analysisResult?.peopleCount === 'number' ? analysisResult.peopleCount : defaultEnvAnalysis.peopleCount,
        isBusy: !!analysisResult?.isBusy,
        isOutdoors: !!analysisResult?.isOutdoors,
        hazards: Array.isArray(analysisResult?.hazards) ? analysisResult.hazards : defaultEnvAnalysis.hazards
      };
    } catch (error) {
      console.error('Error in environment analysis:', error);
      return defaultEnvAnalysis;
    }
  }
  
  /**
   * Set the preferred provider
   */
  setPreferredProvider(provider: AIProvider): void {
    this.preferredProvider = provider;
  }
  
  /**
   * Get provider status
   */
  getProviderStatus(): { openai: boolean, anthropic: boolean } {
    return {
      openai: this.openaiAvailable,
      anthropic: this.anthropicAvailable
    };
  }
}

// Export singleton instance
export const multiAI = new MultiAIService();