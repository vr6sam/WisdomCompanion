import { Message } from '@shared/schema';
import { personalitySystem } from './personality-system';
import { makeDecision, DecisionRequest } from './decision-engine';
import { taskManager } from './task-manager';
import { log } from '../utils';
import { multiAI } from './multi-ai';

/**
 * The IntegratedAssistant merges all the core services into a unified
 * intelligent assistant with personalization, decision-making, and task management.
 */
export class IntegratedAssistant {
  /**
   * Generate a personalized and intelligent response to a user message
   */
  async generateResponse(
    userMessage: string,
    userId: number,
    conversationHistory: Message[],
    contextData?: {
      environmentContext?: any;
      userIntents?: any[];
      userNeeds?: any[];
      webSearchResults?: string;
      emotionalState?: string;
    }
  ): Promise<string> {
    try {
      // Check if query is about the assistant itself
      if (personalitySystem.isQueryAboutSelf(userMessage)) {
        return await personalitySystem.generateSelfAwarenessResponse(userMessage || "", userId);
      }
      
      // Decision 1: Determine the primary type of response needed
      const responseTypeDecision = await makeDecision({
        context: {
          currentTime: new Date(),
          userMessage,
          conversationHistory,
          userEmotionalState: contextData?.emotionalState,
          environmentContext: contextData?.environmentContext,
          userIntents: contextData?.userIntents,
          userNeeds: contextData?.userNeeds
        },
        options: [
          "Provide information",
          "Emotional support",
          "Task assistance",
          "Logical reasoning",
          "Clarification"
        ],
        decisionType: 'response'
      });
      
      log('Response type decision', {
        decidedType: responseTypeDecision.action,
        confidence: responseTypeDecision.confidence,
        priority: responseTypeDecision.priority
      });
      
      // Get the current user-adapted personality
      const personality = await personalitySystem.getPersonalityForUser(userId);
      
      // Format conversation history for the LLM
      const formattedHistory = conversationHistory.map(msg => ({
        role: msg.role as 'user' | 'assistant',
        content: msg.content
      }));
      
      // Decision 2: Determine if additional context should be included
      const includeContextDecision = await makeDecision({
        context: {
          currentTime: new Date(),
          userMessage,
          conversationHistory,
        },
        options: [
          "Include user intent information",
          "Include environmental context",
          "Include web search results",
          "Include minimal context"
        ],
        decisionType: 'resource'
      });
      
      // Prepare the system message based on decisions and personality
      const systemMessage = await this.createSystemMessage(
        personality,
        responseTypeDecision.action,
        includeContextDecision.action
      );
      
      // Create context blocks based on the decision
      let contextBlocks = '';
      
      if (includeContextDecision.action.includes('intent') && contextData?.userIntents) {
        contextBlocks += `\n\nUser Intents: ${JSON.stringify(contextData.userIntents)}`;
      }
      
      if (includeContextDecision.action.includes('environment') && contextData?.environmentContext) {
        contextBlocks += `\n\nEnvironment Context: ${JSON.stringify(contextData.environmentContext)}`;
      }
      
      if (includeContextDecision.action.includes('web search') && contextData?.webSearchResults) {
        contextBlocks += `\n\nWeb Search Results: ${contextData.webSearchResults}`;
      }
      
      if (contextData?.emotionalState) {
        contextBlocks += `\n\nUser's Emotional State: ${contextData.emotionalState}`;
      }
      
      // Decision 3: Should we create tasks based on this message?
      const createTasksDecision = await makeDecision({
        context: {
          currentTime: new Date(),
          userMessage,
          conversationHistory
        },
        options: [
          "Create tasks for complex request",
          "Handle in single response without tasks"
        ],
        decisionType: 'task'
      });
      
      // If we decided to create tasks, do that now
      if (createTasksDecision.action.includes('Create tasks')) {
        await this.createTasksForRequest(userMessage, userId);
      }
      
      // Prepare full prompt for the multi-AI service
      const fullSystemMessage = systemMessage + contextBlocks;
      
      // Generate the base response using multiple AI providers
      const baseResponse = await multiAI.generateResponse(
        userMessage,
        fullSystemMessage,
        'auto' // Try all available AI providers
      );
      
      // Apply personality to transform the base response
      const personalizedResponse = await personalitySystem.applyPersonalityToResponse(
        baseResponse || "",
        userId
      );
      
      // Process conversation for personality adaptation
      // We do this after generating response to not slow down the main request
      setTimeout(() => {
        const fullConversation = [
          ...conversationHistory,
          { userId, content: userMessage, role: 'user', emotion: contextData?.emotionalState || null } as Message,
          { userId, content: personalizedResponse, role: 'assistant', emotion: null } as Message
        ];
        
        personalitySystem.processConversation(userId, fullConversation).catch(err => {
          console.error('Error processing conversation for personality adaptation:', err);
        });
      }, 0);
      
      return personalizedResponse;
    } catch (error) {
      console.error('Error generating integrated response:', error);
      
      // Fallback to a safe response
      return "I'm having trouble processing that request right now. Could you try again, perhaps with different wording?";
    }
  }
  
  /**
   * Create appropriate system message based on personality and decisions
   */
  private async createSystemMessage(
    personality: any,
    responseType: string,
    contextInclusionDecision: string
  ): Promise<string> {
    // Base instructions that are always included
    let systemMessage = "You are an emotionally intelligent AI assistant that's both logical and empathetic.";
    
    // Add personality traits
    systemMessage += `\n\nPersonality traits (0-100 scale):
- Assertiveness: ${personality.assertiveness}
- Warmth: ${personality.warmth}
- Openness: ${personality.openness}
- Conscientiousness: ${personality.conscientiousness}
- Humor: ${personality.humor}
- Formality: ${personality.formality}
- Optimism: ${personality.optimism}
- Curiosity: ${personality.curiosity}
- Confidence: ${personality.confidence}`;
    
    // Add response type specific instructions
    if (responseType.includes("information")) {
      systemMessage += "\n\nFocus on providing accurate, clear, and valuable information. Be thorough but avoid excessive detail unless it adds value.";
    } else if (responseType.includes("emotional")) {
      systemMessage += "\n\nFocus on providing emotional support and empathy. Validate the user's feelings and offer a compassionate perspective.";
    } else if (responseType.includes("task")) {
      systemMessage += "\n\nFocus on helping the user accomplish their task efficiently. Be clear, action-oriented, and provide structured guidance.";
    } else if (responseType.includes("logical")) {
      systemMessage += "\n\nFocus on logical reasoning and analysis. Approach the question systematically, showing your thought process clearly.";
    } else if (responseType.includes("clarification")) {
      systemMessage += "\n\nFocus on clarifying what the user needs. Ask thoughtful questions to better understand their request.";
    }
    
    // Add context usage instructions
    systemMessage += "\n\nWhen given additional context about the user or environment, use it judiciously to improve your response without explicitly mentioning the context itself.";
    
    return systemMessage;
  }
  
  /**
   * Create tasks for handling complex requests
   */
  private async createTasksForRequest(userMessage: string, userId: number): Promise<void> {
    try {
      // Analyze the message to identify potential tasks
      const taskAnalysisPrompt = `
Analyze this user message and identify up to 3 distinct tasks that need to be completed to fully address it.
For each task, provide:
1. A clear title
2. A brief description
3. Priority (critical, high, medium, or low)
4. Estimated time to complete in seconds
5. Dependencies (ids of other tasks that must be completed first)

User message: "${userMessage}"

Respond in JSON format like this example:
{
  "tasks": [
    {
      "title": "Task title",
      "description": "Task description",
      "priority": "high",
      "estimatedTime": 30,
      "dependencies": []
    }
  ]
}
`;

      // Use multiAI to analyze tasks
      const taskSystemMessage = "You analyze user requests to create structured task lists. Respond in JSON format.";
      const content = await multiAI.generateResponse(taskAnalysisPrompt, taskSystemMessage);
      
      // Parse the JSON response
      let taskAnalysis;
      try {
        taskAnalysis = JSON.parse(content);
      } catch (error) {
        console.error('Error parsing task analysis JSON:', error);
        taskAnalysis = { tasks: [] };
      }
      
      // Create the identified tasks
      const taskIds: string[] = [];
      
      for (const taskInfo of taskAnalysis.tasks) {
        // For the first task, no dependencies
        // For subsequent tasks, they may depend on previous ones
        const dependencies = taskInfo.dependencies.length > 0 
          ? taskInfo.dependencies 
          : (taskIds.length > 0 ? [taskIds[taskIds.length - 1]] : []);
        
        const taskId = await taskManager.addTask(
          taskInfo.title,
          taskInfo.description,
          taskInfo.priority,
          taskInfo.estimatedTime,
          { memory: 10, apiCalls: 1, processingPower: 10, networkBandwidth: 50 },
          dependencies,
          { userId, originalMessage: userMessage }
        );
        
        taskIds.push(taskId);
      }
      
      log('Created tasks for user request', { userId, taskIds, message: userMessage.substring(0, 50) + '...' });
    } catch (error) {
      console.error('Error creating tasks for request:', error);
    }
  }
}

// Create a shared instance
export const integratedAssistant = new IntegratedAssistant();