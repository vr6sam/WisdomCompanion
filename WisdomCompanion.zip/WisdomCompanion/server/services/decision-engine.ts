import OpenAI from 'openai';
import { Message } from '@shared/schema';
import { log } from '../utils';

// Initialize OpenAI client
const openai = new OpenAI({ apiKey: process.env.OPENAI_API_KEY });

// Decision types
export type DecisionPriority = 'critical' | 'high' | 'medium' | 'low';

export interface Decision {
  id: string;
  priority: DecisionPriority;
  action: string;
  reasoning: string;
  confidence: number; // 0-1
  timestamp: Date;
  metadata?: Record<string, any>;
}

export interface DecisionRequest {
  context: {
    currentTime: Date;
    userMessage?: string;
    conversationHistory?: Message[];
    userEmotionalState?: string;
    environmentContext?: any;
    userIntents?: any[];
    userNeeds?: any[];
  };
  options: string[];
  constraints?: {
    timeConstraint?: number; // seconds available to make decision
    resourceConstraints?: Record<string, number>; // e.g., {"memory": 100, "api_calls": 5}
    priorityThreshold?: DecisionPriority; // minimum priority level to consider
  };
  decisionType: 'response' | 'task' | 'resource' | 'emergency';
}

export interface EvaluationResult {
  score: number; // 0-100
  strengths: string[];
  weaknesses: string[];
  improvements: string[];
}

// Function to generate a decision with logical reasoning
export async function makeDecision(request: DecisionRequest): Promise<Decision> {
  try {
    const startTime = Date.now();
    
    // Format the context for the decision
    const contextStr = JSON.stringify(request.context, null, 2);
    const optionsStr = request.options.map((opt, i) => `Option ${i+1}: ${opt}`).join('\n');
    const constraintsStr = request.constraints ? JSON.stringify(request.constraints, null, 2) : 'No specific constraints';
    
    // Create the prompt for logical decision making
    const prompt = `
You are a logical decision-making system for an AI assistant. Analyze the following context and options to make an optimal decision.

## Context:
${contextStr}

## Options:
${optionsStr}

## Constraints:
${constraintsStr}

## Decision Type:
${request.decisionType}

Make a logical decision by analyzing:
1. Relevance to user's immediate needs and emotional state
2. Efficiency and resource usage
3. Priority and urgency
4. Long-term impact and alignment with user goals
5. Confidence level based on available information

Provide your decision in JSON format with the following structure:
{
  "action": "The selected option or a modified action",
  "priority": "critical/high/medium/low",
  "reasoning": "Detailed logical reasoning for this decision, including tradeoffs considered",
  "confidence": 0.XX (confidence level between 0-1),
  "alternatives": ["Alternative actions in descending order of preference"]
}

Only return the JSON object without any other text.
`;

    // Make API call to OpenAI for logical reasoning
    const completion = await openai.chat.completions.create({
      model: "gpt-4o", // the newest OpenAI model is "gpt-4o" which was released May 13, 2024. do not change this unless explicitly requested by the user
      messages: [
        { role: "system", content: "You are a logical decision-making system focused on efficiency, clarity, and optimal outcomes." },
        { role: "user", content: prompt }
      ],
      response_format: { type: "json_object" }
    });
    
    // Parse the response
    const content = completion.choices[0].message.content.trim();
    const result = JSON.parse(content);
    
    // Create the final decision object
    const decision: Decision = {
      id: generateDecisionId(),
      priority: result.priority as DecisionPriority,
      action: result.action,
      reasoning: result.reasoning,
      confidence: result.confidence,
      timestamp: new Date(),
      metadata: {
        alternatives: result.alternatives,
        processingTime: Date.now() - startTime,
        decisionType: request.decisionType
      }
    };
    
    // Log the decision (in production, would store in database)
    log(`Decision made [${decision.priority}]: ${decision.action}`, { 
      confidence: decision.confidence,
      reasoning: decision.reasoning.substring(0, 100) + '...' 
    });
    
    return decision;
  } catch (error) {
    console.error('Error in decision-making process:', error);
    
    // Fallback decision in case of failure
    return {
      id: generateDecisionId(),
      priority: 'medium',
      action: request.options[0] || 'Proceed with caution due to decision-making error',
      reasoning: 'Decision-making process encountered an error. Selected safest option.',
      confidence: 0.5,
      timestamp: new Date()
    };
  }
}

// Evaluate the quality of a made decision (for learning and improvement)
export async function evaluateDecision(decision: Decision, actualOutcome: string): Promise<EvaluationResult> {
  try {
    const prompt = `
Evaluate the quality of the following AI decision based on the actual outcome:

## Decision Made:
${JSON.stringify(decision, null, 2)}

## Actual Outcome:
${actualOutcome}

Provide your evaluation in JSON format with:
1. score: A score from 0-100 on decision quality
2. strengths: Array of decision strengths
3. weaknesses: Array of decision weaknesses
4. improvements: Array of suggested improvements for future similar decisions

Only return the JSON object without any other text.
`;

    const completion = await openai.chat.completions.create({
      model: "gpt-4o", // the newest OpenAI model is "gpt-4o" which was released May 13, 2024. do not change this unless explicitly requested by the user
      messages: [
        { role: "system", content: "You are an evaluation system for AI decisions that provides fair, balanced feedback." },
        { role: "user", content: prompt }
      ],
      response_format: { type: "json_object" }
    });
    
    const content = completion.choices[0].message.content.trim();
    const result = JSON.parse(content);
    
    return {
      score: result.score,
      strengths: result.strengths,
      weaknesses: result.weaknesses,
      improvements: result.improvements
    };
  } catch (error) {
    console.error('Error evaluating decision:', error);
    return {
      score: 50,
      strengths: ['Attempted to make a decision with available information'],
      weaknesses: ['Unable to properly evaluate decision quality due to error'],
      improvements: ['Improve error handling in decision evaluation process']
    };
  }
}

// Function to optimize resource usage based on current system state
export async function optimizeResources(
  availableResources: Record<string, number>,
  pendingTasks: Array<{ id: string; resourceNeeds: Record<string, number>; priority: DecisionPriority }>
): Promise<Array<{ taskId: string; allocated: Record<string, number> }>> {
  // Sort tasks by priority (critical > high > medium > low)
  const priorityValues: Record<DecisionPriority, number> = { 'critical': 3, 'high': 2, 'medium': 1, 'low': 0 };
  const sortedTasks = [...pendingTasks].sort((a, b) => 
    priorityValues[b.priority] - priorityValues[a.priority]
  );
  
  const allocations: Array<{ taskId: string; allocated: Record<string, number> }> = [];
  const remainingResources = { ...availableResources };
  
  // Allocate resources based on priority
  for (const task of sortedTasks) {
    const allocation: Record<string, number> = {};
    
    // For each resource type requested by the task
    for (const [resource, needed] of Object.entries(task.resourceNeeds)) {
      // If we have this resource type available
      if (resource in remainingResources) {
        // Allocate either what's needed or what's left, whichever is smaller
        const allocating = Math.min(needed, remainingResources[resource]);
        allocation[resource] = allocating;
        remainingResources[resource] -= allocating;
      } else {
        allocation[resource] = 0; // No resource of this type available
      }
    }
    
    allocations.push({ taskId: task.id, allocated: allocation });
  }
  
  return allocations;
}

// Function to determine the most efficient action sequence for multiple tasks
export function planActionSequence(
  tasks: Array<{ 
    id: string; 
    action: string; 
    dependencies: string[]; 
    estimatedTime: number;
    priority: DecisionPriority;
  }>
): { sequence: string[]; estimatedCompletionTime: number; reasoning: string } {
  // Create a dependency graph
  const taskMap = new Map(tasks.map(task => [task.id, task]));
  const completed = new Set<string>();
  const sequence: string[] = [];
  let totalTime = 0;
  
  // First, handle all critical tasks regardless of dependencies
  const criticalTasks = tasks.filter(t => t.priority === 'critical');
  for (const task of criticalTasks) {
    sequence.push(task.id);
    completed.add(task.id);
    totalTime += task.estimatedTime;
  }
  
  // Process remaining tasks based on priority and dependencies
  const remainingTasks = tasks
    .filter(t => t.priority !== 'critical')
    .sort((a, b) => {
      // Sort by priority first
      const priorityValues: Partial<Record<DecisionPriority, number>> = { 'high': 2, 'medium': 1, 'low': 0 };
      const priorityDiff = (priorityValues[b.priority] || 0) - (priorityValues[a.priority] || 0);
      if (priorityDiff !== 0) return priorityDiff;
      
      // Then by efficiency (time divided by remaining dependencies)
      const aDeps = a.dependencies.filter(d => !completed.has(d)).length;
      const bDeps = b.dependencies.filter(d => !completed.has(d)).length;
      const aEfficiency = aDeps === 0 ? a.estimatedTime : a.estimatedTime / aDeps;
      const bEfficiency = bDeps === 0 ? b.estimatedTime : b.estimatedTime / bDeps;
      return aEfficiency - bEfficiency;
    });
  
  // Process tasks until all are completed
  while (completed.size < tasks.length) {
    let progress = false;
    
    for (const task of remainingTasks) {
      if (completed.has(task.id)) continue;
      
      // Check if all dependencies are satisfied
      const dependenciesMet = task.dependencies.every(dep => completed.has(dep));
      
      if (dependenciesMet) {
        sequence.push(task.id);
        completed.add(task.id);
        totalTime += task.estimatedTime;
        progress = true;
      }
    }
    
    // If no progress was made in this iteration, we have a dependency cycle
    if (!progress && completed.size < tasks.length) {
      // Find tasks with unsatisfied dependencies and force the one with highest priority
      const blocked = remainingTasks.filter(t => !completed.has(t.id));
      const highest = blocked.sort((a, b) => {
        const priorityValues: Partial<Record<DecisionPriority, number>> = { 'high': 2, 'medium': 1, 'low': 0 };
        return (priorityValues[b.priority] || 0) - (priorityValues[a.priority] || 0);
      })[0];
      
      sequence.push(highest.id);
      completed.add(highest.id);
      totalTime += highest.estimatedTime;
    }
  }
  
  // Generate reasoning for the sequence
  const reasoning = generateSequenceReasoning(sequence, taskMap);
  
  return {
    sequence,
    estimatedCompletionTime: totalTime,
    reasoning
  };
}

// Helper function to generate reasoning for a sequence
function generateSequenceReasoning(
  sequence: string[],
  taskMap: Map<string, { 
    id: string; 
    action: string; 
    dependencies: string[]; 
    estimatedTime: number;
    priority: DecisionPriority;
  }>
): string {
  let reasoning = "Task sequence optimized based on priority and dependencies:\n";
  
  sequence.forEach((taskId, index) => {
    const task = taskMap.get(taskId);
    if (!task) return;
    
    reasoning += `${index + 1}. ${task.action} (Priority: ${task.priority}, Time: ${task.estimatedTime}s)`;
    
    if (task.dependencies.length > 0) {
      reasoning += ` - Depends on: ${task.dependencies.join(', ')}`;
    }
    
    reasoning += '\n';
  });
  
  return reasoning;
}

// Generate a unique ID for decisions
function generateDecisionId(): string {
  return 'dec_' + Math.random().toString(36).substring(2, 15);
}