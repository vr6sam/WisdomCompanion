import { makeDecision, planActionSequence, optimizeResources, DecisionPriority } from './decision-engine';
import { log } from '../utils';

// Task status types
export type TaskStatus = 'pending' | 'running' | 'completed' | 'failed' | 'cancelled';

// Task interface
export interface Task {
  id: string;
  title: string;
  description: string;
  status: TaskStatus;
  priority: DecisionPriority;
  createdAt: Date;
  startedAt?: Date;
  completedAt?: Date;
  error?: string;
  dependencies: string[];
  estimatedTime: number; // seconds
  resourceNeeds: Record<string, number>;
  metadata?: Record<string, any>;
  result?: any;
}

// Resource type definition
export interface ResourcePool {
  memory: number; // MB available
  apiCalls: number; // API calls available
  processingPower: number; // Arbitrary units
  networkBandwidth: number; // KB/s
}

// TaskManager class to handle task execution and resource allocation
export class TaskManager {
  private tasks: Map<string, Task> = new Map();
  private runningTasks: Set<string> = new Set();
  private maxConcurrentTasks: number = 5;
  private resourcePool: ResourcePool;
  private taskQueue: string[] = [];
  
  constructor(resourcePool: ResourcePool) {
    this.resourcePool = resourcePool;
    
    // Set up interval to process task queue
    setInterval(() => this.processTaskQueue(), 1000);
    
    // Set up interval to monitor and adjust resources
    setInterval(() => this.monitorResources(), 10000);
  }
  
  // Add a new task to the manager
  async addTask(
    title: string, 
    description: string, 
    priority: DecisionPriority, 
    estimatedTime: number,
    resourceNeeds: Record<string, number>,
    dependencies: string[] = [],
    metadata?: Record<string, any>
  ): Promise<string> {
    const taskId = 'task_' + Math.random().toString(36).substring(2, 15);
    
    const task: Task = {
      id: taskId,
      title,
      description,
      status: 'pending',
      priority,
      createdAt: new Date(),
      dependencies,
      estimatedTime,
      resourceNeeds,
      metadata
    };
    
    this.tasks.set(taskId, task);
    this.taskQueue.push(taskId);
    
    log(`Task added: ${title} [${priority}]`, { taskId, estimatedTime });
    
    // Immediately attempt to process the task queue
    this.processTaskQueue();
    
    return taskId;
  }
  
  // Get a task by ID
  getTask(taskId: string): Task | undefined {
    return this.tasks.get(taskId);
  }
  
  // Get all tasks
  getAllTasks(): Task[] {
    return Array.from(this.tasks.values());
  }
  
  // Cancel a task
  cancelTask(taskId: string): boolean {
    const task = this.tasks.get(taskId);
    if (!task) return false;
    
    if (task.status === 'pending') {
      task.status = 'cancelled';
      this.taskQueue = this.taskQueue.filter(id => id !== taskId);
      log(`Task cancelled: ${task.title}`, { taskId });
      return true;
    }
    
    if (task.status === 'running') {
      task.status = 'cancelled';
      this.runningTasks.delete(taskId);
      log(`Running task cancelled: ${task.title}`, { taskId });
      return true;
    }
    
    return false;
  }
  
  // Process the task queue
  private async processTaskQueue() {
    if (this.runningTasks.size >= this.maxConcurrentTasks) {
      return; // Already at max capacity
    }
    
    // Calculate available resources
    const availableResources = { ...this.resourcePool };
    
    // Subtract resources already allocated to running tasks
    for (const taskId of this.runningTasks) {
      const task = this.tasks.get(taskId);
      if (!task) continue;
      
      for (const [resource, amount] of Object.entries(task.resourceNeeds)) {
        if (resource in availableResources) {
          availableResources[resource as keyof ResourcePool] -= amount;
        }
      }
    }
    
    // Get pending tasks that are not already in the running set
    const pendingTasks = this.taskQueue
      .map(id => this.tasks.get(id))
      .filter(task => task && task.status === 'pending' && !this.runningTasks.has(task.id)) as Task[];
    
    if (pendingTasks.length === 0) return;
    
    // Prepare for resource optimization
    const taskResourceNeeds = pendingTasks.map(task => ({
      id: task.id,
      resourceNeeds: task.resourceNeeds,
      priority: task.priority
    }));
    
    // Optimize resource allocation
    const allocations = await optimizeResources(
      availableResources as Record<string, number>,
      taskResourceNeeds
    );
    
    // Determine which tasks to run based on resource allocation
    const tasksToRun: Task[] = [];
    
    for (const allocation of allocations) {
      // Skip if already at max capacity
      if (tasksToRun.length + this.runningTasks.size >= this.maxConcurrentTasks) {
        break;
      }
      
      const task = this.tasks.get(allocation.taskId);
      if (!task || task.status !== 'pending') continue;
      
      // Check if all resources were allocated sufficiently
      const sufficientResources = Object.entries(task.resourceNeeds).every(([resource, needed]) => 
        (allocation.allocated[resource] || 0) >= needed
      );
      
      // Check if all dependencies are completed
      const dependenciesMet = task.dependencies.every(depId => {
        const depTask = this.tasks.get(depId);
        return depTask && depTask.status === 'completed';
      });
      
      if (sufficientResources && dependenciesMet) {
        tasksToRun.push(task);
      }
    }
    
    // Start running the selected tasks
    for (const task of tasksToRun) {
      this.startTask(task.id);
    }
  }
  
  // Start executing a task
  private async startTask(taskId: string) {
    const task = this.tasks.get(taskId);
    if (!task || task.status !== 'pending') return;
    
    // Update task status
    task.status = 'running';
    task.startedAt = new Date();
    this.runningTasks.add(taskId);
    
    // Remove from queue
    this.taskQueue = this.taskQueue.filter(id => id !== taskId);
    
    log(`Starting task: ${task.title}`, { taskId });
    
    try {
      // Simulate task execution with timeout based on estimated time
      const result = await this.executeTask(task);
      
      // Task completed successfully
      task.status = 'completed';
      task.completedAt = new Date();
      task.result = result;
      
      log(`Task completed: ${task.title}`, { 
        taskId, 
        duration: (task.completedAt.getTime() - task.startedAt!.getTime()) / 1000 
      });
    } catch (error) {
      // Task failed
      task.status = 'failed';
      task.completedAt = new Date();
      task.error = error.message;
      
      log(`Task failed: ${task.title}`, { taskId, error: error.message });
    }
    
    // Remove from running tasks
    this.runningTasks.delete(taskId);
    
    // Process queue again to see if we can run more tasks
    this.processTaskQueue();
  }
  
  // Execute a task (this would be implemented with real functionality)
  private async executeTask(task: Task): Promise<any> {
    return new Promise((resolve, reject) => {
      setTimeout(() => {
        // For demonstration, we're just resolving with mock data
        // In a real implementation, this would do actual work
        if (Math.random() > 0.1) { // 10% chance of failure
          resolve({
            success: true,
            executionTime: task.estimatedTime,
            message: `Successfully executed task: ${task.title}`
          });
        } else {
          reject(new Error(`Random failure in task execution: ${task.title}`));
        }
      }, Math.min(task.estimatedTime * 1000, 5000)); // Cap at 5 seconds for demo
    });
  }
  
  // Plan optimal task sequence for a set of pending tasks
  async planTaskSequence(): Promise<{
    sequence: string[];
    estimatedCompletionTime: number;
    reasoning: string;
  }> {
    // Get all pending tasks
    const pendingTasks = Array.from(this.tasks.values())
      .filter(t => t.status === 'pending')
      .map(t => ({
        id: t.id,
        action: t.title,
        dependencies: t.dependencies,
        estimatedTime: t.estimatedTime,
        priority: t.priority
      }));
    
    if (pendingTasks.length === 0) {
      return {
        sequence: [],
        estimatedCompletionTime: 0,
        reasoning: "No pending tasks to plan."
      };
    }
    
    // Use the decision engine to plan the sequence
    return planActionSequence(pendingTasks);
  }
  
  // Monitor and adjust resources based on current workload
  private async monitorResources() {
    // Get counts of tasks by priority
    const taskCounts: Record<DecisionPriority, number> = {
      critical: 0,
      high: 0,
      medium: 0,
      low: 0
    };
    
    for (const task of this.tasks.values()) {
      if (task.status === 'pending' || task.status === 'running') {
        taskCounts[task.priority]++;
      }
    }
    
    // Adjust max concurrent tasks based on priority distribution
    if (taskCounts.critical > 0) {
      // If there are critical tasks, allow more concurrent execution
      this.maxConcurrentTasks = 8;
    } else if (taskCounts.high > taskCounts.medium + taskCounts.low) {
      // If high priority tasks dominate, maintain higher concurrency
      this.maxConcurrentTasks = 6;
    } else {
      // Default concurrency
      this.maxConcurrentTasks = 5;
    }
    
    // Log current resource state for monitoring
    log('Resource monitor update', {
      pendingTasks: this.taskQueue.length,
      runningTasks: this.runningTasks.size,
      maxConcurrentTasks: this.maxConcurrentTasks,
      resourcePool: this.resourcePool
    });
  }
}

// Create a default task manager instance
const defaultResourcePool: ResourcePool = {
  memory: 1024, // 1GB in MB
  apiCalls: 100, // 100 API calls
  processingPower: 100, // Arbitrary units
  networkBandwidth: 5000 // 5MB/s
};

export const taskManager = new TaskManager(defaultResourcePool);