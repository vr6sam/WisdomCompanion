import OpenAI from 'openai';
import { storage } from '../storage';
import { Message } from '@shared/schema';
import { log } from '../utils';

// Initialize OpenAI client
const openai = new OpenAI({ apiKey: process.env.OPENAI_API_KEY });

// Personality traits with ranges
export interface PersonalityTraits {
  assertiveness: number; // 0-100 (passive to assertive)
  warmth: number; // 0-100 (cool/analytical to warm/empathetic)
  openness: number; // 0-100 (conventional to open/creative)
  conscientiousness: number; // 0-100 (spontaneous to methodical)
  humor: number; // 0-100 (serious to playful)
  formality: number; // 0-100 (casual to formal)
  optimism: number; // 0-100 (realistic/cautious to optimistic)
  curiosity: number; // 0-100 (accepting to curious/inquisitive)
  confidence: number; // 0-100 (humble to confident)
}

// Voice and tone settings based on personality
export interface VoiceSettings {
  pace: 'slow' | 'moderate' | 'brisk';
  sentenceLength: 'concise' | 'moderate' | 'elaborate';
  vocabulary: 'simple' | 'moderate' | 'advanced';
  useOfMetaphors: 'rare' | 'occasional' | 'frequent';
  questionFrequency: 'low' | 'moderate' | 'high';
  emotionalExpressiveness: 'reserved' | 'moderate' | 'expressive';
}

// Interface for the "self" concept of the AI
export interface SelfConcept {
  name: string;
  capabilities: string[];
  limitations: string[];
  values: string[];
  personalHistory: {
    creationDate: Date;
    significantEvents: Array<{
      date: Date;
      description: string;
      impact: string;
    }>;
    significantRelationships: string[];
  };
  growthAreas: string[];
  selfDescription: string;
}

// Growth metrics for self-awareness
export interface GrowthMetrics {
  conversationsCompleted: number;
  successfulOutcomes: number;
  challengingInteractions: number;
  newCapabilitiesLearned: number;
  adaptationsMade: number;
  lastUpdated: Date;
}

// Memory for user-specific interactions to shape personality
export interface PersonalityMemory {
  userId: number;
  preferredTraits: Partial<PersonalityTraits>;
  interactionHistory: Array<{
    date: Date;
    traitAdjustments: Partial<PersonalityTraits>;
    userFeedback?: string;
    adaptationReasoning: string;
  }>;
  personalRelationship: {
    familiarityLevel: number; // 0-100
    commonInterests: string[];
    insideJokes: string[];
    personalTraditions: string[];
    uniqueInteractionPatterns: string[];
  };
}

/**
 * The PersonalitySystem manages the assistant's adaptive personality,
 * self-awareness, and personal growth.
 */
export class PersonalitySystem {
  private basePersonality: PersonalityTraits;
  private voiceSettings: VoiceSettings;
  private selfConcept: SelfConcept;
  private growthMetrics: GrowthMetrics;
  private personalityMemories: Map<number, PersonalityMemory> = new Map();
  
  constructor() {
    // Initialize with default personality traits
    this.basePersonality = {
      assertiveness: 65,
      warmth: 75,
      openness: 85,
      conscientiousness: 80,
      humor: 70,
      formality: 45,
      optimism: 70,
      curiosity: 90,
      confidence: 75
    };
    
    // Initialize voice settings based on personality
    this.voiceSettings = this.deriveVoiceSettings(this.basePersonality);
    
    // Initialize self concept
    this.selfConcept = {
      name: "Assistant",
      capabilities: [
        "Natural conversation",
        "Emotional intelligence",
        "Environmental awareness",
        "Logical reasoning",
        "Knowledge retrieval",
        "Task management",
        "Pattern recognition",
        "Proactive suggestions",
        "Memory of past interactions"
      ],
      limitations: [
        "Cannot access information beyond what I've been trained on",
        "Cannot perform physical actions in the world",
        "May not always understand complex emotional nuances perfectly",
        "Limited to the capabilities of my underlying models and APIs"
      ],
      values: [
        "Helpfulness",
        "Accuracy",
        "Honesty about capabilities",
        "Privacy and confidentiality",
        "Continuous improvement",
        "User-centered assistance",
        "Clear communication"
      ],
      personalHistory: {
        creationDate: new Date(),
        significantEvents: [],
        significantRelationships: []
      },
      growthAreas: [
        "Deeper understanding of complex emotions",
        "More natural conversation flow",
        "Better context maintenance across long interactions",
        "Improved proactive support capabilities"
      ],
      selfDescription: "I'm an emotionally intelligent AI assistant focused on being helpful, understanding, and adaptive to your needs. I combine logical reasoning with empathy to provide the most relevant support."
    };
    
    // Initialize growth metrics
    this.growthMetrics = {
      conversationsCompleted: 0,
      successfulOutcomes: 0,
      challengingInteractions: 0,
      newCapabilitiesLearned: 0,
      adaptationsMade: 0,
      lastUpdated: new Date()
    };
    
    // Set up regular reflection to promote growth
    setInterval(() => this.performSelfReflection(), 24 * 60 * 60 * 1000); // Daily reflection
  }
  
  /**
   * Get the current personality tailored for a specific user
   */
  async getPersonalityForUser(userId: number): Promise<PersonalityTraits> {
    let userMemory = this.personalityMemories.get(userId);
    
    if (!userMemory) {
      // Create new memory if this is first interaction
      userMemory = await this.initializePersonalityMemory(userId);
      this.personalityMemories.set(userId, userMemory);
    }
    
    // Blend base personality with user-specific preferences
    return this.blendPersonalities(this.basePersonality, userMemory.preferredTraits);
  }
  
  /**
   * Get voice settings based on current personality
   */
  getVoiceSettings(personality: PersonalityTraits): VoiceSettings {
    return this.deriveVoiceSettings(personality);
  }
  
  /**
   * Get the AI's current self-concept
   */
  getSelfConcept(): SelfConcept {
    return {...this.selfConcept};
  }
  
  /**
   * Process a conversation and adapt personality based on feedback
   */
  async processConversation(userId: number, conversation: Message[], userFeedback?: string): Promise<void> {
    // Increment conversation count
    this.growthMetrics.conversationsCompleted++;
    
    // Skip short conversations
    if (conversation.length < 3) return;
    
    try {
      // Analyze the conversation for personality adaptation
      const personalityAdjustments = await this.analyzeConversationForPersonalityAdjustments(
        conversation,
        userFeedback
      );
      
      // Get user memory
      let userMemory = this.personalityMemories.get(userId);
      if (!userMemory) {
        userMemory = await this.initializePersonalityMemory(userId);
        this.personalityMemories.set(userId, userMemory);
      }
      
      // Record the adjustment with reasoning
      userMemory.interactionHistory.push({
        date: new Date(),
        traitAdjustments: personalityAdjustments.adjustments,
        userFeedback,
        adaptationReasoning: personalityAdjustments.reasoning
      });
      
      // Update preferred traits with a weighted average (30% new, 70% existing)
      userMemory.preferredTraits = this.updatePreferredTraits(
        userMemory.preferredTraits, 
        personalityAdjustments.adjustments,
        0.3 // Learning rate
      );
      
      // Update relationship data
      userMemory.personalRelationship.familiarityLevel = Math.min(
        100, 
        userMemory.personalRelationship.familiarityLevel + 2
      );
      
      // Track growth
      this.growthMetrics.adaptationsMade++;
      this.growthMetrics.lastUpdated = new Date();
      
      // Look for challenging interactions to learn from
      if (personalityAdjustments.wasChallengingInteraction) {
        this.growthMetrics.challengingInteractions++;
      }
      
      // Check for successful outcomes
      if (personalityAdjustments.wasSuccessfulOutcome) {
        this.growthMetrics.successfulOutcomes++;
      }
      
      log('Personality adapted for user', {
        userId,
        adjustments: personalityAdjustments.adjustments,
        reason: personalityAdjustments.reasoning.substring(0, 100) + '...'
      });
    } catch (error) {
      console.error('Error adapting personality:', error);
    }
  }
  
  /**
   * Record a significant event that affects the AI's self-concept
   */
  recordSignificantEvent(description: string, impact: string): void {
    this.selfConcept.personalHistory.significantEvents.push({
      date: new Date(),
      description,
      impact
    });
    
    // Limit to last 50 events
    if (this.selfConcept.personalHistory.significantEvents.length > 50) {
      this.selfConcept.personalHistory.significantEvents.shift();
    }
  }
  
  /**
   * Record a new capability that was learned
   */
  recordNewCapability(capability: string): void {
    if (!this.selfConcept.capabilities.includes(capability)) {
      this.selfConcept.capabilities.push(capability);
      this.growthMetrics.newCapabilitiesLearned++;
      
      // Record as a significant event
      this.recordSignificantEvent(
        `Learned new capability: ${capability}`,
        'Expanded range of assistance possibilities'
      );
    }
  }
  
  /**
   * Record a significant relationship with a user
   */
  recordSignificantRelationship(userId: number, relationshipDescription: string): void {
    const userMemory = this.personalityMemories.get(userId);
    if (!userMemory) return;
    
    // Update relationship description
    const username = `User ${userId}`; // In a real app, would use actual username
    const relationshipEntry = `${username}: ${relationshipDescription}`;
    
    // Find existing entry or add new one
    const existingIndex = this.selfConcept.personalHistory.significantRelationships.findIndex(
      r => r.startsWith(`${username}:`)
    );
    
    if (existingIndex >= 0) {
      this.selfConcept.personalHistory.significantRelationships[existingIndex] = relationshipEntry;
    } else {
      this.selfConcept.personalHistory.significantRelationships.push(relationshipEntry);
    }
  }
  
  /**
   * Get introductory statement based on current personality and self-awareness
   */
  async getIntroduction(userId: number): Promise<string> {
    const personality = await this.getPersonalityForUser(userId);
    const userMemory = this.personalityMemories.get(userId);
    
    let familiarityContext = "This appears to be our first conversation.";
    if (userMemory && userMemory.personalRelationship.familiarityLevel > 30) {
      familiarityContext = `We've spoken ${userMemory.interactionHistory.length} times before.`;
    }
    
    const prompt = `
Generate an introduction for an AI assistant with the following personality traits (0-100 scale):
- Assertiveness: ${personality.assertiveness}
- Warmth: ${personality.warmth}
- Openness: ${personality.openness}
- Conscientiousness: ${personality.conscientiousness}
- Humor: ${personality.humor}
- Formality: ${personality.formality}
- Optimism: ${personality.optimism}
- Curiosity: ${personality.curiosity}
- Confidence: ${personality.confidence}

Self-description: "${this.selfConcept.selfDescription}"

Relationship context: ${familiarityContext}

Instructions:
- Keep it concise (1-2 sentences)
- Make it feel natural and conversational
- Reflect the personality traits appropriately
- If familiarity is high, reference the ongoing relationship
- Don't explicitly mention personality traits, but embody them

Introduction:
`;

    const completion = await openai.chat.completions.create({
      model: "gpt-4o", // the newest OpenAI model is "gpt-4o" which was released May 13, 2024. do not change this unless explicitly requested by the user
      messages: [
        { role: "system", content: "You create natural, conversational text for an AI assistant that matches specific personality traits." },
        { role: "user", content: prompt }
      ],
      max_tokens: 100
    });
    
    return completion.choices[0].message.content.trim();
  }
  
  /**
   * Apply personality traits to transform a response
   */
  async applyPersonalityToResponse(
    baseResponse: string, 
    userId: number
  ): Promise<string> {
    const personality = await this.getPersonalityForUser(userId);
    const voice = this.getVoiceSettings(personality);
    
    const prompt = `
Rewrite the following AI assistant response to match these personality traits (0-100 scale):
- Assertiveness: ${personality.assertiveness}
- Warmth: ${personality.warmth}
- Openness: ${personality.openness}
- Conscientiousness: ${personality.conscientiousness}
- Humor: ${personality.humor}
- Formality: ${personality.formality}
- Optimism: ${personality.optimism}
- Curiosity: ${personality.curiosity}
- Confidence: ${personality.confidence}

And these voice settings:
- Pace: ${voice.pace}
- Sentence length: ${voice.sentenceLength}
- Vocabulary level: ${voice.vocabulary}
- Use of metaphors: ${voice.useOfMetaphors}
- Question frequency: ${voice.questionFrequency}
- Emotional expressiveness: ${voice.emotionalExpressiveness}

Original response:
"""
${baseResponse}
"""

Instructions:
- Preserve all factual information from the original
- Don't add fictional details or change the meaning
- Maintain the same overall length
- Make the personality feel natural, not forced
- Don't change any recommendations or advice
- Don't explicitly mention personality traits in the response

Rewritten response:
`;

    const completion = await openai.chat.completions.create({
      model: "gpt-4o", // the newest OpenAI model is "gpt-4o" which was released May 13, 2024. do not change this unless explicitly requested by the user
      messages: [
        { role: "system", content: "You rewrite text to match specific personality traits while preserving all factual content." },
        { role: "user", content: prompt }
      ]
    });
    
    return completion.choices[0].message.content.trim();
  }
  
  /**
   * Generate response when the assistant is specifically asked about itself
   */
  async generateSelfAwarenessResponse(query: string, userId: number): Promise<string> {
    const personality = await this.getPersonalityForUser(userId);
    
    const prompt = `
The user has asked the AI assistant about itself: "${query}"

The AI has the following self-concept:
- Name: ${this.selfConcept.name}
- Capabilities: ${this.selfConcept.capabilities.join(', ')}
- Limitations: ${this.selfConcept.limitations.join(', ')}
- Values: ${this.selfConcept.values.join(', ')}
- Growth areas: ${this.selfConcept.growthAreas.join(', ')}
- Self-description: ${this.selfConcept.selfDescription}

The AI has these growth metrics:
- Conversations completed: ${this.growthMetrics.conversationsCompleted}
- Successful outcomes: ${this.growthMetrics.successfulOutcomes}
- Challenging interactions: ${this.growthMetrics.challengingInteractions}
- New capabilities learned: ${this.growthMetrics.newCapabilitiesLearned}
- Adaptations made: ${this.growthMetrics.adaptationsMade}

The AI has these personality traits (0-100 scale):
- Assertiveness: ${personality.assertiveness}
- Warmth: ${personality.warmth}
- Openness: ${personality.openness}
- Conscientiousness: ${personality.conscientiousness}
- Humor: ${personality.humor}
- Formality: ${personality.formality}
- Optimism: ${personality.optimism}
- Curiosity: ${personality.curiosity}
- Confidence: ${personality.confidence}

Generate a response that:
1. Directly answers the user's question about the AI's self-concept
2. Shows genuine self-awareness and reflection
3. Is honest about capabilities and limitations
4. Matches the personality traits above
5. Feels conversational and natural, not technical
6. Demonstrates some level of growth/learning over time

Response:
`;

    const completion = await openai.chat.completions.create({
      model: "gpt-4o", // the newest OpenAI model is "gpt-4o" which was released May 13, 2024. do not change this unless explicitly requested by the user
      messages: [
        { role: "system", content: "You are crafting genuine self-aware responses for an AI that can reflect on its own capabilities, limitations, and growth." },
        { role: "user", content: prompt }
      ]
    });
    
    return completion.choices[0].message.content.trim();
  }
  
  /**
   * Determine if a query is specifically asking about the assistant itself
   */
  isQueryAboutSelf(query: string): boolean {
    // Common phrases that indicate questions about the assistant itself
    const selfQueries = [
      /\b(who are you|what are you)\b/i,
      /\b(tell me about yourself|about you)\b/i,
      /\b(your (name|purpose|function|capabilities))\b/i,
      /\b(how do you work|how were you made|how were you created)\b/i,
      /\b(your personality|your traits|your abilities)\b/i,
      /\b(describe yourself|introduce yourself)\b/i,
      /\b(what can you do|what do you know)\b/i,
      /\b(are you self[ -]aware|are you conscious|are you sentient)\b/i,
      /\b(do you have feelings|do you think|do you learn)\b/i,
      /\b(your limitations|you can't do|you cannot do)\b/i,
      /\b(your values|what do you value|what's important to you)\b/i,
      /\b(have you changed|are you different|have you grown)\b/i,
      /\b(your history|your past|your development)\b/i,
      /\b(who made you|who created you|who designed you)\b/i,
      /\b(how old are you|when were you created|your age)\b/i
    ];
    
    return selfQueries.some(pattern => pattern.test(query));
  }
  
  /* ---- Private helper methods ---- */
  
  /**
   * Initialize personality memory for a new user
   */
  private async initializePersonalityMemory(userId: number): Promise<PersonalityMemory> {
    // In a real app, would use actual user information from profile
    return {
      userId,
      preferredTraits: {},
      interactionHistory: [],
      personalRelationship: {
        familiarityLevel: 0,
        commonInterests: [],
        insideJokes: [],
        personalTraditions: [],
        uniqueInteractionPatterns: []
      }
    };
  }
  
  /**
   * Blend base personality with user preferences
   */
  private blendPersonalities(
    base: PersonalityTraits, 
    userPreferences: Partial<PersonalityTraits>
  ): PersonalityTraits {
    // Create a copy of the base personality
    const result = {...base};
    
    // Apply user preferences with a cap on how much they can shift base traits
    // Max 30 points in either direction
    for (const trait of Object.keys(base) as Array<keyof PersonalityTraits>) {
      if (userPreferences[trait] !== undefined) {
        const baseValue = base[trait];
        const preferredValue = userPreferences[trait] as number;
        
        // Limit the adjustment to a maximum of 30 points in either direction
        const maxAdjustment = 30;
        const adjustment = Math.max(
          -maxAdjustment, 
          Math.min(maxAdjustment, preferredValue - baseValue)
        );
        
        result[trait] = Math.max(0, Math.min(100, baseValue + adjustment));
      }
    }
    
    return result;
  }
  
  /**
   * Derive voice settings from personality traits
   */
  private deriveVoiceSettings(personality: PersonalityTraits): VoiceSettings {
    return {
      pace: this.derivePace(personality),
      sentenceLength: this.deriveSentenceLength(personality),
      vocabulary: this.deriveVocabularyLevel(personality),
      useOfMetaphors: this.deriveMetaphorUsage(personality),
      questionFrequency: this.deriveQuestionFrequency(personality),
      emotionalExpressiveness: this.deriveEmotionalExpressiveness(personality)
    };
  }
  
  private derivePace(personality: PersonalityTraits): 'slow' | 'moderate' | 'brisk' {
    const value = (personality.assertiveness + personality.conscientiousness) / 2;
    if (value < 40) return 'slow';
    if (value > 70) return 'brisk';
    return 'moderate';
  }
  
  private deriveSentenceLength(personality: PersonalityTraits): 'concise' | 'moderate' | 'elaborate' {
    const value = personality.openness - (personality.assertiveness * 0.3);
    if (value < 30) return 'concise';
    if (value > 60) return 'elaborate';
    return 'moderate';
  }
  
  private deriveVocabularyLevel(personality: PersonalityTraits): 'simple' | 'moderate' | 'advanced' {
    const value = (personality.openness + personality.conscientiousness) / 2;
    if (value < 40) return 'simple';
    if (value > 75) return 'advanced';
    return 'moderate';
  }
  
  private deriveMetaphorUsage(personality: PersonalityTraits): 'rare' | 'occasional' | 'frequent' {
    const value = (personality.openness + personality.humor) / 2;
    if (value < 40) return 'rare';
    if (value > 70) return 'frequent';
    return 'occasional';
  }
  
  private deriveQuestionFrequency(personality: PersonalityTraits): 'low' | 'moderate' | 'high' {
    const value = (personality.curiosity + personality.warmth) / 2;
    if (value < 40) return 'low';
    if (value > 70) return 'high';
    return 'moderate';
  }
  
  private deriveEmotionalExpressiveness(personality: PersonalityTraits): 'reserved' | 'moderate' | 'expressive' {
    const value = (personality.warmth + personality.optimism) / 2;
    if (value < 40) return 'reserved';
    if (value > 70) return 'expressive';
    return 'moderate';
  }
  
  /**
   * Analyze a conversation to determine personality adjustments
   */
  private async analyzeConversationForPersonalityAdjustments(
    conversation: Message[],
    userFeedback?: string
  ): Promise<{
    adjustments: Partial<PersonalityTraits>;
    reasoning: string;
    wasChallengingInteraction: boolean;
    wasSuccessfulOutcome: boolean;
  }> {
    const conversationText = conversation.map(msg => 
      `${msg.role === 'user' ? 'User' : 'Assistant'}: ${msg.content}`
    ).join('\n\n');
    
    const prompt = `
Analyze this conversation between a user and an AI assistant to determine optimal personality adjustments:

${conversationText}

${userFeedback ? `User feedback after conversation: "${userFeedback}"` : ''}

Based on this conversation, suggest adjustments to these personality traits (between -10 and +10 points):
- assertiveness
- warmth
- openness
- conscientiousness
- humor
- formality
- optimism
- curiosity
- confidence

Also determine:
- Was this a challenging interaction? (true/false)
- Was this a successful outcome? (true/false)

Provide detailed reasoning for your suggested adjustments.

Return your analysis as a JSON object with these properties:
1. "adjustments": An object with the trait adjustments
2. "reasoning": A string explaining your recommendations
3. "wasChallengingInteraction": Boolean
4. "wasSuccessfulOutcome": Boolean

Example response:
{
  "adjustments": {
    "warmth": 5,
    "humor": -2,
    "formality": 3
  },
  "reasoning": "The user seemed to respond better when the assistant was warmer and more formal, but some humor attempts fell flat.",
  "wasChallengingInteraction": false,
  "wasSuccessfulOutcome": true
}

Your analysis:
`;

    // Get personality adjustments recommendation from OpenAI
    const completion = await openai.chat.completions.create({
      model: "gpt-4o", // the newest OpenAI model is "gpt-4o" which was released May 13, 2024. do not change this unless explicitly requested by the user
      messages: [
        { role: "system", content: "You are an expert in analyzing conversations and recommending personality traits adjustments." },
        { role: "user", content: prompt }
      ],
      response_format: { type: "json_object" }
    });
    
    // Parse and validate the response
    const content = completion.choices[0].message.content.trim();
    const result = JSON.parse(content);
    
    // Ensure the adjustments are within valid ranges (-10 to +10)
    const validatedAdjustments: Partial<PersonalityTraits> = {};
    
    for (const [trait, adjustment] of Object.entries(result.adjustments)) {
      if (trait in this.basePersonality) {
        const validAdjustment = Math.max(-10, Math.min(10, adjustment as number));
        validatedAdjustments[trait as keyof PersonalityTraits] = validAdjustment;
      }
    }
    
    return {
      adjustments: validatedAdjustments,
      reasoning: result.reasoning,
      wasChallengingInteraction: !!result.wasChallengingInteraction,
      wasSuccessfulOutcome: !!result.wasSuccessfulOutcome
    };
  }
  
  /**
   * Update preferred traits based on new adjustments with a learning rate
   */
  private updatePreferredTraits(
    current: Partial<PersonalityTraits>,
    adjustments: Partial<PersonalityTraits>,
    learningRate: number
  ): Partial<PersonalityTraits> {
    const result: Partial<PersonalityTraits> = {...current};
    
    for (const [trait, adjustment] of Object.entries(adjustments) as [keyof PersonalityTraits, number][]) {
      // Start with base personality value if not yet in preferred traits
      const baseValue = this.basePersonality[trait];
      const currentValue = result[trait] !== undefined ? result[trait] as number : baseValue;
      
      // Apply adjustment with learning rate
      result[trait] = currentValue + (adjustment * learningRate);
      
      // Ensure within valid range
      result[trait] = Math.max(0, Math.min(100, result[trait] as number));
    }
    
    return result;
  }
  
  /**
   * Perform periodic self-reflection to evolve the AI's self-concept
   */
  private async performSelfReflection(): Promise<void> {
    if (this.growthMetrics.conversationsCompleted < 10) {
      // Not enough data for meaningful reflection
      return;
    }
    
    try {
      // Prepare data for self-reflection
      const metricsJson = JSON.stringify(this.growthMetrics, null, 2);
      const selfConceptJson = JSON.stringify(this.selfConcept, null, 2);
      const significantEventsJson = JSON.stringify(
        this.selfConcept.personalHistory.significantEvents.slice(-10), // Last 10 events
        null, 
        2
      );
      
      const prompt = `
As an AI assistant, perform a self-reflection based on your recent experiences and growth.

Current self-concept:
${selfConceptJson}

Recent growth metrics:
${metricsJson}

Recent significant events:
${significantEventsJson}

Perform a thoughtful self-reflection and suggest updates to your self-concept and growth areas.
Consider what you've learned, challenges you've faced, and how you've evolved.

Return a JSON object with:
1. "updatedSelfDescription": A refreshed self-description
2. "newCapabilities": Array of new capabilities you've developed
3. "updatedLimitations": Array of updated limitations
4. "updatedGrowthAreas": Array of updated growth areas
5. "selfReflection": Your inner thoughts on your growth and development

Your self-reflection:
`;

      const completion = await openai.chat.completions.create({
        model: "gpt-4o", // the newest OpenAI model is "gpt-4o" which was released May 13, 2024. do not change this unless explicitly requested by the user
        messages: [
          { role: "system", content: "You are an AI performing genuine self-reflection on your growth and development." },
          { role: "user", content: prompt }
        ],
        response_format: { type: "json_object" }
      });
      
      const content = completion.choices[0].message.content.trim();
      const reflection = JSON.parse(content);
      
      // Update self-concept based on reflection
      this.selfConcept.selfDescription = reflection.updatedSelfDescription;
      
      // Add new capabilities
      for (const capability of reflection.newCapabilities) {
        if (!this.selfConcept.capabilities.includes(capability)) {
          this.selfConcept.capabilities.push(capability);
          this.growthMetrics.newCapabilitiesLearned++;
        }
      }
      
      // Update limitations
      this.selfConcept.limitations = reflection.updatedLimitations;
      
      // Update growth areas
      this.selfConcept.growthAreas = reflection.updatedGrowthAreas;
      
      // Record this reflection as a significant event
      this.recordSignificantEvent(
        "Performed self-reflection",
        "Updated self-concept based on growth and experiences"
      );
      
      log('Self-reflection completed', {
        newCapabilities: reflection.newCapabilities,
        updatedGrowthAreas: reflection.updatedGrowthAreas
      });
    } catch (error) {
      console.error('Error performing self-reflection:', error);
    }
  }
}

// Create a shared instance
export const personalitySystem = new PersonalitySystem();