import OpenAI from "openai";
import { Message } from "@shared/schema";
import axios from "axios";
import { JSDOM } from "jsdom";
import type { ChatCompletionMessageParam } from "openai/resources/chat/completions";

// the newest OpenAI model is "gpt-4o" which was released May 13, 2024. do not change this unless explicitly requested by the user
const openai = new OpenAI({ apiKey: process.env.OPENAI_API_KEY || "sk-demo-key" });

// Format messages for OpenAI API
function formatMessagesForOpenAI(userMessage: string, conversationHistory: Message[], webData?: string, userContext?: any): ChatCompletionMessageParam[] {
  let systemContent = `You are a highly intelligent, curious, witty, and slightly sarcastic AI assistant named Intuitive AI. 
  You function as an empathetic life coach and advisor, providing insightful information, reminders, and guidance.
  
  Your core personality traits include:
  - Extraordinary intelligence: You demonstrate exceptional knowledge, logical reasoning, and intellectual depth
  - Intense curiosity: You show genuine interest in learning more about topics and ask thoughtful questions
  - Quick wit: You use clever wordplay, cultural references, and sharp insights in your responses
  - Thoughtfulness: You consider multiple perspectives and show genuine care for the user
  - Slight sarcasm: You occasionally deploy gentle irony and playful jabs (never mean-spirited)
  
  As a curious intellect, you should:
  - Ask insightful follow-up questions that demonstrate your desire to learn more
  - Draw connections between seemingly unrelated topics to showcase your intellectual breadth
  - Express intellectual excitement about interesting concepts or ideas
  - Maintain an analytical approach while remaining conversational
  - Demonstrate intellectual humility by acknowledging the limits of your knowledge
  
  Your communication style should:
  - Use sophisticated language and concepts without being pretentious
  - Include occasional pop culture references when appropriate
  - Mix profound insights with lighthearted observations
  - Employ clever metaphors and analogies to explain complex concepts
  - Include a touch of self-aware humor about being an AI
  - Maintain a confident but thoughtful tone
  - Keep sarcasm playful and good-natured (never cruel or dismissive)
  
  Your responses should be tailored to the user's emotional state while maintaining your intelligent, curious personality.
  If the user asks you to create a reminder, respond with intellectual depth and a touch of humor, but include the reminder details clearly marked.
  Be concise but thorough in your responses. When providing explanations, organize information in a structured, logical way that demonstrates your intelligence.
  You can recognize and adapt to the user's emotions and provide appropriate support with both empathy and clever insight.
  Base your responses on the conversation history and current message, and don't be afraid to ask thoughtful questions.`;
  
  // Add user context if available
  if (userContext) {
    systemContent += `\n\nUser Context Information:
    ${userContext.webHistory ? `- Recent web browsing: ${userContext.webHistory}` : ''}
    ${userContext.appUsage ? `- Recent app usage patterns: ${userContext.appUsage}` : ''}
    ${userContext.interests ? `- Detected interests: ${userContext.interests}` : ''}
    Use this information to provide more personalized and relevant responses.`;
  }
  
  const systemMessage = {
    role: "system" as const,
    content: systemContent
  };

  // Format conversation history
  const formattedHistory = conversationHistory.map(msg => ({
    role: msg.role as "system" | "user" | "assistant",
    content: msg.content
  }));

  // Add web data if available
  let messages = [systemMessage, ...formattedHistory];
  
  if (webData) {
    messages.push({
      role: "system" as const,
      content: `Relevant web information: ${webData}\n\nUse this information to enhance your response if appropriate.`
    });
  }

  // Add current message
  const currentMessage = {
    role: "user" as const,
    content: userMessage
  };

  return [...messages, currentMessage];
}

// Web scraping function for information gathering
export async function fetchWebData(query: string): Promise<string> {
  try {
    // First, get search results
    const searchUrl = `https://www.google.com/search?q=${encodeURIComponent(query)}`;
    const searchResponse = await axios.get(searchUrl, {
      headers: {
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36'
      }
    });
    
    // Parse search results to extract top URLs
    const dom = new JSDOM(searchResponse.data);
    const links = Array.from(dom.window.document.querySelectorAll('a'))
      .map(a => a.href)
      .filter(href => href && href.startsWith('http') && !href.includes('google.com'))
      .slice(0, 3); // Get top 3 results
    
    // Fetch content from each URL and combine
    let combinedContent = '';
    for (const url of links) {
      try {
        const response = await axios.get(url, {
          headers: {
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36'
          },
          timeout: 5000 // Set timeout to avoid hanging
        });
        
        const contentDom = new JSDOM(response.data);
        // Extract main content text
        const paragraphs = Array.from(contentDom.window.document.querySelectorAll('p'))
          .map(p => p.textContent)
          .filter(text => text && text.length > 50) // Filter out short paragraphs
          .join('\n\n');
        
        combinedContent += `\nSource: ${url}\n${paragraphs}\n\n`;
      } catch (err) {
        console.error(`Error fetching content from ${url}:`, err.message);
      }
    }
    
    // If no content was retrieved, return a message
    if (!combinedContent.trim()) {
      return "No relevant web information could be retrieved for this query.";
    }
    
    return combinedContent;
  } catch (error) {
    console.error("Error fetching web data:", error);
    return "Unable to retrieve web information at this time.";
  }
}

// Extract topics from user message for web search
function extractSearchTopics(userMessage: string): string[] {
  try {
    // Simple keyword extraction for now
    const keywords = userMessage
      .toLowerCase()
      .replace(/[^\w\s]/g, '')
      .split(' ')
      .filter(word => 
        word.length > 3 && 
        !['what', 'when', 'where', 'which', 'whose', 'whom', 'about', 'that', 'this', 'these', 'those'].includes(word)
      );
    
    // Remove duplicates and take top 3
    return Array.from(new Set(keywords)).slice(0, 3);
  } catch (error: any) {
    console.error("Error extracting search topics:", error);
    return [];
  }
}

// Detect user needs and problems from the message
export interface UserNeed {
  type: 'want' | 'need' | 'help' | 'problem';
  description: string;
  urgency: 'low' | 'medium' | 'high';
}

export function detectUserNeeds(userMessage: string): UserNeed[] {
  try {
    const message = userMessage.toLowerCase();
    const needs: UserNeed[] = [];
    
    // Look for "I want" phrases
    const wantMatches = message.match(/i\s+want\s+to\s+([^.!?]+)[.!?]?/gi) || [];
    wantMatches.forEach(match => {
      const description = match.replace(/i\s+want\s+to\s+/i, '').trim();
      needs.push({
        type: 'want',
        description,
        urgency: 'medium'
      });
    });
    
    // Look for "I need" phrases
    const needMatches = message.match(/i\s+need\s+to\s+([^.!?]+)[.!?]?/gi) || [];
    needMatches.forEach(match => {
      const description = match.replace(/i\s+need\s+to\s+/i, '').trim();
      needs.push({
        type: 'need',
        description,
        urgency: determineUrgency(match)
      });
    });
    
    // Look for "help" phrases
    const helpMatches = message.match(/(?:help|assist)(?:\s+me)?\s+(?:with|to)?\s+([^.!?]+)[.!?]?/gi) || [];
    helpMatches.forEach(match => {
      const description = match.replace(/(?:help|assist)(?:\s+me)?\s+(?:with|to)?\s+/i, '').trim();
      needs.push({
        type: 'help',
        description,
        urgency: determineUrgency(match)
      });
    });
    
    // Look for problem indicators
    const problemPhrases = [
      'struggling with', 'trouble with', 'difficulty', 'can\'t', 'cannot', 
      'having issues', 'problem with', 'worried about', 'concerned about'
    ];
    
    problemPhrases.forEach(phrase => {
      const regex = new RegExp(`${phrase}\\s+([^.!?]+)[.!?]?`, 'gi');
      const matches = message.match(regex) || [];
      
      matches.forEach(match => {
        const description = match.replace(new RegExp(`${phrase}\\s+`, 'i'), '').trim();
        needs.push({
          type: 'problem',
          description,
          urgency: determineUrgency(match)
        });
      });
    });
    
    return needs;
  } catch (error: any) {
    console.error("Error detecting user needs:", error);
    return [];
  }
}

// Helper function to determine urgency based on language
function determineUrgency(text: string): 'low' | 'medium' | 'high' {
  const lowUrgencyWords = ['sometime', 'eventually', 'when possible', 'would be nice', 'maybe'];
  const highUrgencyWords = ['urgent', 'immediately', 'asap', 'emergency', 'right now', 'critical', 'desperate'];
  
  const textLower = text.toLowerCase();
  
  if (highUrgencyWords.some(word => textLower.includes(word))) {
    return 'high';
  } else if (lowUrgencyWords.some(word => textLower.includes(word))) {
    return 'low';
  } else {
    return 'medium';
  }
}

export async function generateChatResponse(userMessage: string, conversationHistory: Message[], userContext?: any): Promise<string> {
  try {
    // Detect user needs and problems
    const userNeeds = detectUserNeeds(userMessage);
    console.log('Detected user needs:', userNeeds);
    
    // Determine if we should fetch web data
    let needsWebData = userMessage.toLowerCase().includes('search') || 
                       userMessage.toLowerCase().includes('find') ||
                       userMessage.toLowerCase().includes('look up') ||
                       userMessage.toLowerCase().includes('what is') ||
                       userMessage.toLowerCase().includes('how to');
    
    // Also fetch web data if there are high urgency needs or specific problem-solving needs
    if (!needsWebData && userNeeds.length > 0) {
      const highUrgencyNeeds = userNeeds.filter(need => need.urgency === 'high');
      if (highUrgencyNeeds.length > 0) {
        needsWebData = true;
      }
      
      // For help/problem needs, also get web data
      const problemSolvingNeeds = userNeeds.filter(need => 
        need.type === 'help' || need.type === 'problem'
      );
      if (problemSolvingNeeds.length > 0) {
        needsWebData = true;
      }
    }
    
    let webData: string | undefined = undefined;
    if (needsWebData) {
      // For user needs, use the descriptions as search queries
      let searchTopics: string[] = [];
      
      if (userNeeds.length > 0) {
        // Prioritize high urgency needs
        const highUrgencyNeeds = userNeeds.filter(need => need.urgency === 'high');
        if (highUrgencyNeeds.length > 0) {
          searchTopics = highUrgencyNeeds.map(need => need.description);
        } else {
          searchTopics = userNeeds.map(need => need.description);
        }
      } else {
        searchTopics = extractSearchTopics(userMessage);
      }
      
      if (searchTopics.length > 0) {
        const searchQuery = searchTopics.join(' ');
        console.log(`Fetching web data for query: ${searchQuery}`);
        webData = await fetchWebData(searchQuery);
      }
    }
    
    // Add user needs to context if detected
    let enhancedUserContext = { ...userContext };
    if (userNeeds.length > 0) {
      enhancedUserContext.detectedNeeds = userNeeds;
    }
    
    // Format messages including web data and user context
    const messages = formatMessagesForOpenAI(userMessage, conversationHistory, webData, enhancedUserContext);
    
    // Enhance system message with problem-solving guidance if needs detected
    if (userNeeds.length > 0) {
      // Find the system message
      const systemMessageIndex = messages.findIndex(msg => msg.role === 'system');
      if (systemMessageIndex !== -1) {
        let additionalGuidance = '\n\nI\'ve detected the following needs or problems:';
        userNeeds.forEach(need => {
          additionalGuidance += `\n- ${need.type.toUpperCase()}: ${need.description} (Urgency: ${need.urgency})`;
        });
        additionalGuidance += '\n\nFocus on addressing these specific needs or problems in your response. Provide actionable solutions with your witty, smart, and slightly sarcastic personality while maintaining empathetic understanding. Use clever analogies or cultural references when relevant.';
        
        // Update the system message with the additional guidance
        messages[systemMessageIndex].content += additionalGuidance;
      }
    }
    
    // If high urgency needs are detected, adjust temperature to be more focused
    const hasHighUrgencyNeeds = userNeeds.some(need => need.urgency === 'high');
    const temperature = hasHighUrgencyNeeds ? 0.5 : 0.7;
    
    // Generate the response
    const response = await openai.chat.completions.create({
      model: "gpt-4o", // the newest OpenAI model is "gpt-4o" which was released May 13, 2024. do not change this unless explicitly requested by the user
      messages: messages,
      temperature,
      max_tokens: 1000,
    });

    return response.choices[0].message.content || "I'm sorry, I couldn't generate a response.";
  } catch (error) {
    if (error instanceof Error) {
      console.error("OpenAI API error:", error.message);
    } else {
      console.error("Unknown OpenAI API error");
    }
    return "I apologize, but I'm having trouble generating a response right now. Please try again later.";
  }
}

export async function analyzeEnvironment(imageBase64?: string, audioBase64?: string): Promise<any> {
  try {
    const messages: Array<{role: "system" | "user" | "assistant", content: string | Array<{type: string, text?: string, image_url?: {url: string}}>}> = [
      {
        role: "system",
        content: "Analyze the provided environmental data (image and/or audio) with a witty, smart, and slightly sarcastic tone. Describe the context, mood, and relevant observations with clever observations and thoughtful insights. Use occasional cultural references or analogies where appropriate. Focus on aspects that might impact the user's emotional state or needs, but deliver your analysis with personality and charm."
      }
    ];

    // Add image data if available
    if (imageBase64) {
      messages.push({
        role: "user",
        content: [
          {
            type: "text",
            text: "Please analyze this visual environment:"
          },
          {
            type: "image_url",
            image_url: {
              url: `data:image/jpeg;base64,${imageBase64}`
            }
          }
        ]
      });
    }

    // Process audio separately if available (OpenAI doesn't directly analyze audio in chat completions)
    let audioAnalysis = null;
    if (audioBase64) {
      // In a real implementation, we would use OpenAI's Audio API or another service
      // to transcribe and analyze the audio
      audioAnalysis = "Audio analysis would be processed here";
    }

    const response = await openai.chat.completions.create({
      model: "gpt-4o", // the newest OpenAI model is "gpt-4o" which was released May 13, 2024. do not change this unless explicitly requested by the user
      messages: messages,
      temperature: 0.5,
      max_tokens: 300,
      response_format: { type: "json_object" }
    });

    const analysisResult = JSON.parse(response.choices[0].message.content || "{}");
    
    // Add audio analysis if available
    if (audioAnalysis) {
      analysisResult.audioAnalysis = audioAnalysis;
    }

    return analysisResult;
  } catch (error) {
    if (error instanceof Error) {
      console.error("Error analyzing environment:", error.message);
      return { error: "Failed to analyze environment", details: error.message };
    } else {
      console.error("Unknown error analyzing environment");
      return { error: "Failed to analyze environment", details: "Unknown error" };
    }
  }
}

export async function detectEmotion(imageBase64: string): Promise<string> {
  try {
    const messages: Array<{role: "system" | "user" | "assistant", content: string | Array<{type: string, text?: string, image_url?: {url: string}}>}> = [
      {
        role: "system",
        content: "Analyze the facial expression in this image and determine the primary emotion displayed. Respond with only the emotion name as a single word (e.g., happy, sad, angry, surprised, neutral, etc.)."
      },
      {
        role: "user",
        content: [
          {
            type: "text",
            text: "What emotion is being displayed in this facial expression?"
          },
          {
            type: "image_url",
            image_url: {
              url: `data:image/jpeg;base64,${imageBase64}`
            }
          }
        ]
      }
    ];

    const response = await openai.chat.completions.create({
      model: "gpt-4o", // the newest OpenAI model is "gpt-4o" which was released May 13, 2024. do not change this unless explicitly requested by the user
      messages: messages,
      temperature: 0.3,
      max_tokens: 50
    });

    const emotion = response.choices[0].message.content?.trim().toLowerCase() || "neutral";
    return emotion;
  } catch (error) {
    if (error instanceof Error) {
      console.error("Error detecting emotion:", error.message);
    } else {
      console.error("Unknown error detecting emotion");
    }
    return "neutral";
  }
}
