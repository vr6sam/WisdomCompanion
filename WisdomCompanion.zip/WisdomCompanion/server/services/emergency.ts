import { storage } from "../storage";
import { detectUserNeeds } from "./openai";
import type { EmergencyContact, Message } from "@shared/schema";

// Emergency level types
export type EmergencyLevel = 'low' | 'medium' | 'high';

// Record of a call made to an emergency contact
export interface EmergencyCall {
  contactId: number;
  contactName: string;
  timestamp: Date;
  message: string;
  status: 'pending' | 'completed' | 'failed';
}

// Keep track of recent calls to avoid duplicate calls
const recentCalls = new Map<number, EmergencyCall[]>();

// Clear calls older than 1 hour
function cleanupOldCalls() {
  const oneHourAgo = new Date(Date.now() - 60 * 60 * 1000);
  
  for (const [userId, calls] of recentCalls.entries()) {
    const recentCallsForUser = calls.filter(call => call.timestamp > oneHourAgo);
    if (recentCallsForUser.length === 0) {
      recentCalls.delete(userId);
    } else {
      recentCalls.set(userId, recentCallsForUser);
    }
  }
}

// Run cleanup every hour
setInterval(cleanupOldCalls, 60 * 60 * 1000);

// Check if a message indicates an emergency that requires contacting someone
export async function checkForEmergency(message: string, userId: number): Promise<{ isEmergency: boolean, level: EmergencyLevel, reason: string }> {
  // Use the detectUserNeeds function to identify potential emergencies
  const userNeeds = detectUserNeeds(message);
  
  // Check for high urgency needs
  const highUrgencyNeeds = userNeeds.filter(need => need.urgency === 'high');
  if (highUrgencyNeeds.length > 0) {
    return { 
      isEmergency: true, 
      level: 'high',
      reason: highUrgencyNeeds.map(need => need.description).join(', ')
    };
  }
  
  // Check for help requests
  const helpNeeds = userNeeds.filter(need => need.type === 'help');
  if (helpNeeds.length > 0) {
    return { 
      isEmergency: true, 
      level: 'medium',
      reason: helpNeeds.map(need => need.description).join(', ')
    };
  }
  
  // Check for specific emergency phrases
  const emergencyPhrases = [
    'i need help', 'help me', 'emergency', 'sos', 'urgent',
    'call for help', 'call someone', 'call my',
    'not feeling well', 'in danger', 'in trouble',
    'medical emergency', 'health emergency'
  ];
  
  const messageLower = message.toLowerCase();
  for (const phrase of emergencyPhrases) {
    if (messageLower.includes(phrase)) {
      return { 
        isEmergency: true, 
        level: phrase.includes('emergency') || phrase.includes('urgent') ? 'high' : 'medium',
        reason: `Message contains "${phrase}"`
      };
    }
  }
  
  return { isEmergency: false, level: 'low', reason: 'No emergency detected' };
}

// Contact emergency contacts based on the emergency level
export async function contactEmergencyContacts(
  userId: number, 
  message: string, 
  emergencyLevel: EmergencyLevel
): Promise<EmergencyCall[]> {
  // Get emergency contacts for the user
  const contacts = await storage.getEmergencyContacts(userId);
  if (!contacts || contacts.length === 0) {
    console.log(`No emergency contacts found for user ${userId}`);
    return [];
  }
  
  // Determine which contacts to call based on emergency level
  let contactsToCall: EmergencyContact[] = [];
  
  if (emergencyLevel === 'high') {
    // For high emergencies, call all contacts
    contactsToCall = contacts;
  } else if (emergencyLevel === 'medium') {
    // For medium emergencies, call default contact or first in the list
    const defaultContact = await storage.getDefaultEmergencyContact(userId);
    contactsToCall = defaultContact ? [defaultContact] : [contacts[0]];
  } else {
    // For low emergencies, don't call anyone
    return [];
  }
  
  // Check if we've recently called these contacts
  const userRecentCalls = recentCalls.get(userId) || [];
  const now = new Date();
  const tenMinutesAgo = new Date(now.getTime() - 10 * 60 * 1000);
  
  // Filter out contacts we've called in the last 10 minutes
  contactsToCall = contactsToCall.filter(contact => {
    const recentCall = userRecentCalls.find(
      call => call.contactId === contact.id && call.timestamp > tenMinutesAgo
    );
    return !recentCall;
  });
  
  if (contactsToCall.length === 0) {
    console.log(`All emergency contacts were recently called for user ${userId}`);
    return [];
  }
  
  // Prepare the emergency message
  const emergencyMsg = `EMERGENCY ALERT: ${message}`;
  
  // Make the calls (in a real implementation, this would integrate with a calling API)
  const calls: EmergencyCall[] = [];
  for (const contact of contactsToCall) {
    console.log(`EMERGENCY CALL to ${contact.name} (${contact.phoneNumber}): ${emergencyMsg}`);
    
    // In a real implementation, this would make an actual call
    // For demo purposes, we'll just log it and record it as completed
    const call: EmergencyCall = {
      contactId: contact.id,
      contactName: contact.name,
      timestamp: new Date(),
      message: emergencyMsg,
      status: 'completed' // In a real app, this would start as 'pending'
    };
    
    calls.push(call);
    
    // Update recent calls list
    const updatedRecentCalls = [...(recentCalls.get(userId) || []), call];
    recentCalls.set(userId, updatedRecentCalls);
  }
  
  return calls;
}