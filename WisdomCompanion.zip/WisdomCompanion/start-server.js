// Updated server start script that uses our custom module resolver
import { spawn } from 'child_process';
import path from 'path';
import { fileURLToPath } from 'url';
import fs from 'fs';

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const nodeModulesPath = path.resolve(__dirname, 'node_modules');

// Check if the problematic module exists and fix it if needed
const resolveUriMjsPath = path.join(nodeModulesPath, '@jridgewell/resolve-uri/dist/resolve-uri.mjs');
const resolveUriUmdPath = path.join(nodeModulesPath, '@jridgewell/resolve-uri/dist/resolve-uri.umd.js');

// Create a symlink from .mjs to .umd.js if the .mjs file doesn't exist
if (!fs.existsSync(resolveUriMjsPath) && fs.existsSync(resolveUriUmdPath)) {
  try {
    // Create directory if it doesn't exist
    const dir = path.dirname(resolveUriMjsPath);
    if (!fs.existsSync(dir)) {
      fs.mkdirSync(dir, { recursive: true });
    }
    
    // Create a JavaScript file that re-exports the UMD module
    const moduleCode = `
      import * as umdModule from './resolve-uri.umd.js';
      export default umdModule.default || umdModule;
      export const resolve = umdModule.resolve;
    `;
    
    fs.writeFileSync(resolveUriMjsPath, moduleCode, 'utf8');
    console.log('Created MJS module from UMD module for @jridgewell/resolve-uri');
  } catch (err) {
    console.error('Failed to create module file:', err);
  }
}

// Start the server with our custom module resolver
console.log('Starting the server...');
const nodeProcess = spawn('node', [
  '--experimental-loader=./module-resolver.js',
  '--no-warnings',
  './node_modules/.bin/tsx',
  'server/index.ts'
], {
  stdio: 'inherit',
  env: {
    ...process.env,
    NODE_ENV: 'development'
  }
});

nodeProcess.on('error', (error) => {
  console.error('Failed to start server process:', error);
  process.exit(1);
});

nodeProcess.on('exit', (code) => {
  console.log(`Server process exited with code ${code}`);
  process.exit(code || 0);
});

// Handle termination signals
process.on('SIGINT', () => {
  console.log('Received SIGINT, shutting down...');
  nodeProcess.kill('SIGINT');
});

process.on('SIGTERM', () => {
  console.log('Received SIGTERM, shutting down...');
  nodeProcess.kill('SIGTERM');
});