import { apiRequest } from '@/lib/queryClient';

// the newest Anthropic model is "claude-3-7-sonnet-20250219" which was released February 24, 2025
const MODEL = 'claude-3-7-sonnet-20250219';

interface AnalyzeTextOptions {
  temperature?: number;
  max_tokens?: number;
}

/**
 * Analyze text using Anthropic Claude API
 */
export async function analyzeText(
  text: string, 
  prompt: string = 'Analyze this text and provide insights:', 
  options: AnalyzeTextOptions = {}
): Promise<string> {
  try {
    const response = await apiRequest('/api/anthropic/chat', {
      method: 'POST',
      body: JSON.stringify({
        messages: [
          { role: 'user', content: text }
        ],
        system: prompt,
        model: MODEL,
        temperature: options.temperature || 0.7,
        maxTokens: options.max_tokens || 1000
      })
    });

    if (!response.ok) {
      throw new Error('Failed to analyze text');
    }

    const data = await response.json();
    return data.content?.[0]?.text || '';
  } catch (error) {
    console.error('Error analyzing text with Claude:', error);
    return 'Error analyzing text';
  }
}

/**
 * Analyze an image using Anthropic Claude's vision capabilities
 */
export async function analyzeImage(
  imageBase64: string,
  prompt: string = 'Analyze this image in detail and describe what you see:',
  options: AnalyzeTextOptions = {}
): Promise<any> {
  try {
    const response = await apiRequest('/api/anthropic/vision', {
      method: 'POST',
      body: JSON.stringify({
        prompt,
        imageBase64,
        model: MODEL,
        temperature: options.temperature || 0.7,
        maxTokens: options.max_tokens || 1000
      })
    });

    if (!response.ok) {
      throw new Error('Failed to analyze image');
    }

    const data = await response.json();
    return data.content?.[0]?.text || '';
  } catch (error) {
    console.error('Error analyzing image with Claude:', error);
    return 'Error analyzing image';
  }
}

/**
 * Detect emotion from an image using Anthropic Claude
 */
export async function detectEmotion(imageBase64: string): Promise<string> {
  try {
    const prompt = 'What emotion is the person showing in this image? Respond with a single word like "happy", "sad", "angry", "neutral", etc. Only respond with a single emotion word, nothing else.';
    
    const response = await apiRequest('/api/anthropic/vision', {
      method: 'POST',
      body: JSON.stringify({
        prompt,
        imageBase64,
        model: MODEL,
        temperature: 0.3,
        maxTokens: 50
      })
    });

    if (!response.ok) {
      throw new Error('Failed to detect emotion');
    }

    const data = await response.json();
    
    // Extract just the single emotion word
    const content = data.content?.[0]?.text || '';
    const emotion = content.trim().toLowerCase().replace(/[^a-z]/g, '');
    return emotion || 'neutral';
  } catch (error) {
    console.error('Error detecting emotion with Claude:', error);
    return 'neutral';
  }
}

/**
 * Generate a text response to a user query using Anthropic Claude
 */
export async function generateResponse(
  prompt: string, 
  context: string = '', 
  options: AnalyzeTextOptions = {}
): Promise<string> {
  try {
    const response = await apiRequest('/api/anthropic/chat', {
      method: 'POST',
      body: JSON.stringify({
        messages: [
          { role: 'user', content: prompt }
        ],
        system: `You are a helpful, empathetic AI assistant. ${context}`,
        model: MODEL,
        temperature: options.temperature || 0.7,
        maxTokens: options.max_tokens || 1000
      })
    });

    if (!response.ok) {
      throw new Error('Failed to generate response');
    }

    const data = await response.json();
    return data.content?.[0]?.text || 'I\'m not sure how to respond to that.';
  } catch (error) {
    console.error('Error generating response with Claude:', error);
    return 'Sorry, I\'m having trouble processing your request right now.';
  }
}

export async function analyzeEnvironment(imageBase64: string): Promise<any> {
  try {
    const prompt = `
      Analyze this environment in detail. Identify:
      1. Lighting conditions (dark/dim/moderate/bright/very bright)
      2. Objects present (prioritize furniture, electronics, and personal items)
      3. General scene description (e.g., office, living room, outdoors)
      4. Approximate number of people visible
      5. Whether the environment appears busy or calm
      6. Whether it's indoor or outdoor
      7. Any potential hazards or safety concerns
      
      Format the response as a JSON object with these properties:
      {
        "lighting": string,
        "objects": array of object names,
        "scene": string,
        "peopleCount": number,
        "isBusy": boolean,
        "isOutdoors": boolean,
        "hazards": array of strings
      }
      
      Respond ONLY with the JSON, nothing else.
    `;
    
    const response = await analyzeImage(imageBase64, prompt, { temperature: 0.3 });
    
    // Parse the JSON response
    try {
      // If the response is already a JSON object, return it
      if (typeof response === 'object') return response;
      
      // Otherwise try to parse the string response as JSON
      // Find JSON object in the response text (in case there's extra text)
      const jsonMatch = response.match(/\{[\s\S]*\}/);
      if (jsonMatch) {
        return JSON.parse(jsonMatch[0]);
      }
      
      // If no valid JSON found, return a default object
      return {
        lighting: 'moderate',
        objects: [],
        scene: 'unknown',
        peopleCount: 0,
        isBusy: false,
        isOutdoors: false,
        hazards: []
      };
    } catch (error) {
      console.error('Error parsing environment JSON:', error);
      
      // Return a default object on parsing error
      return {
        lighting: 'moderate',
        objects: [],
        scene: 'unknown',
        peopleCount: 0,
        isBusy: false,
        isOutdoors: false,
        hazards: []
      };
    }
  } catch (error) {
    console.error('Error analyzing environment with Claude:', error);
    
    // Return a default object on analysis error
    return {
      lighting: 'moderate',
      objects: [],
      scene: 'unknown',
      peopleCount: 0,
      isBusy: false,
      isOutdoors: false,
      hazards: []
    };
  }
}