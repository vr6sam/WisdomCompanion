import { apiRequest } from '@/lib/queryClient';

// the newest OpenAI model is "gpt-4o" which was released May 13, 2024. do not change this unless explicitly requested by the user
const MODEL = 'gpt-4o';

interface AnalyzeTextOptions {
  temperature?: number;
  max_tokens?: number;
}

/**
 * Analyze text using OpenAI's API
 */
export async function analyzeText(
  text: string, 
  prompt: string = 'Analyze this text and provide insights:', 
  options: AnalyzeTextOptions = {}
): Promise<string> {
  try {
    const response = await apiRequest('/api/openai/chat', {
      method: 'POST',
      body: JSON.stringify({
        messages: [
          { role: 'system', content: prompt },
          { role: 'user', content: text }
        ],
        model: MODEL,
        temperature: options.temperature || 0.7,
        max_tokens: options.max_tokens || 1000
      })
    });

    if (!response.ok) {
      throw new Error('Failed to analyze text');
    }

    const data = await response.json();
    return data.content || '';
  } catch (error) {
    console.error('Error analyzing text:', error);
    return 'Error analyzing text';
  }
}

/**
 * Analyze an image using OpenAI's vision capabilities
 */
export async function analyzeImage(
  imageBase64: string,
  prompt: string = 'Analyze this image in detail and describe what you see:',
  options: AnalyzeTextOptions = {}
): Promise<any> {
  try {
    const response = await apiRequest('/api/openai/vision', {
      method: 'POST',
      body: JSON.stringify({
        messages: [
          {
            role: 'user',
            content: [
              { type: 'text', text: prompt },
              {
                type: 'image_url',
                image_url: {
                  url: `data:image/jpeg;base64,${imageBase64}`
                }
              }
            ]
          }
        ],
        model: MODEL,
        temperature: options.temperature || 0.7,
        max_tokens: options.max_tokens || 1000
      })
    });

    if (!response.ok) {
      throw new Error('Failed to analyze image');
    }

    const data = await response.json();
    return data.content || '';
  } catch (error) {
    console.error('Error analyzing image:', error);
    return 'Error analyzing image';
  }
}

/**
 * Detect emotion from an image
 */
export async function detectEmotion(imageBase64: string): Promise<string> {
  try {
    const response = await apiRequest('/api/openai/vision', {
      method: 'POST',
      body: JSON.stringify({
        messages: [
          {
            role: 'user',
            content: [
              { 
                type: 'text', 
                text: 'What emotion is the person showing in this image? Respond with a single word like "happy", "sad", "angry", "neutral", etc. Only respond with a single emotion word, nothing else.' 
              },
              {
                type: 'image_url',
                image_url: {
                  url: `data:image/jpeg;base64,${imageBase64}`
                }
              }
            ]
          }
        ],
        model: MODEL,
        temperature: 0.3,
        max_tokens: 50
      })
    });

    if (!response.ok) {
      throw new Error('Failed to detect emotion');
    }

    const data = await response.json();
    
    // Extract just the single emotion word
    const emotion = data.content.trim().toLowerCase().replace(/[^a-z]/g, '');
    return emotion || 'neutral';
  } catch (error) {
    console.error('Error detecting emotion:', error);
    return 'neutral';
  }
}

/**
 * Generate a text response to a user query
 */
export async function generateResponse(
  prompt: string, 
  context: string = '', 
  options: AnalyzeTextOptions = {}
): Promise<string> {
  try {
    const response = await apiRequest('/api/openai/chat', {
      method: 'POST',
      body: JSON.stringify({
        messages: [
          { 
            role: 'system', 
            content: `You are a helpful, empathetic AI assistant. ${context}` 
          },
          { role: 'user', content: prompt }
        ],
        model: MODEL,
        temperature: options.temperature || 0.7,
        max_tokens: options.max_tokens || 1000
      })
    });

    if (!response.ok) {
      throw new Error('Failed to generate response');
    }

    const data = await response.json();
    return data.content || 'I\'m not sure how to respond to that.';
  } catch (error) {
    console.error('Error generating response:', error);
    return 'Sorry, I\'m having trouble processing your request right now.';
  }
}

/**
 * Transcribe audio to text
 */
export async function transcribeAudio(audioBase64: string): Promise<string> {
  try {
    const response = await apiRequest('/api/openai/transcribe', {
      method: 'POST',
      body: JSON.stringify({ audio: audioBase64 })
    });
    
    if (!response.ok) {
      throw new Error('Failed to transcribe audio');
    }
    
    const data = await response.json();
    return data.text || '';
  } catch (error) {
    console.error('Error transcribing audio:', error);
    return '';
  }
}

export async function analyzeEnvironment(imageBase64: string): Promise<any> {
  try {
    const prompt = `
      Analyze this environment in detail. Identify:
      1. Lighting conditions (dark/dim/moderate/bright/very bright)
      2. Objects present (prioritize furniture, electronics, and personal items)
      3. General scene description (e.g., office, living room, outdoors)
      4. Approximate number of people visible
      5. Whether the environment appears busy or calm
      6. Whether it's indoor or outdoor
      7. Any potential hazards or safety concerns
      
      Format the response as a JSON object with these properties:
      {
        "lighting": string,
        "objects": array of object names,
        "scene": string,
        "peopleCount": number,
        "isBusy": boolean,
        "isOutdoors": boolean,
        "hazards": array of strings
      }
      
      Respond ONLY with the JSON, nothing else.
    `;
    
    const response = await analyzeImage(imageBase64, prompt, { temperature: 0.3 });
    
    // Parse the JSON response
    try {
      // If the response is already a JSON object, return it
      if (typeof response === 'object') return response;
      
      // Otherwise try to parse the string response as JSON
      // Find JSON object in the response text (in case there's extra text)
      const jsonMatch = response.match(/\{[\s\S]*\}/);
      if (jsonMatch) {
        return JSON.parse(jsonMatch[0]);
      }
      
      // If no valid JSON found, return a default object
      return {
        lighting: 'moderate',
        objects: [],
        scene: 'unknown',
        peopleCount: 0,
        isBusy: false,
        isOutdoors: false,
        hazards: []
      };
    } catch (error) {
      console.error('Error parsing environment JSON:', error);
      
      // Return a default object on parsing error
      return {
        lighting: 'moderate',
        objects: [],
        scene: 'unknown',
        peopleCount: 0,
        isBusy: false,
        isOutdoors: false,
        hazards: []
      };
    }
  } catch (error) {
    console.error('Error analyzing environment:', error);
    
    // Return a default object on analysis error
    return {
      lighting: 'moderate',
      objects: [],
      scene: 'unknown',
      peopleCount: 0,
      isBusy: false,
      isOutdoors: false,
      hazards: []
    };
  }
}