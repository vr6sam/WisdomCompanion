import * as faceapi from 'face-api.js';

/**
 * Load face-api.js models from multiple possible paths.
 * @returns Promise that resolves when models are loaded successfully, or rejects when all paths fail.
 */
export async function loadFaceApiModels(): Promise<void> {
  // Try different paths to find the models
  const modelPaths = [
    '/models',                          // Root relative 
    window.location.origin + '/models', // Absolute with origin
    './models',                         // Relative to current directory
    '../models',                        // Up one directory
  ];
  
  let lastError: Error | null = null;
  
  for (const modelPath of modelPaths) {
    try {
      console.log('Attempting to load face-api models from:', modelPath);
      
      // Load model definitions with explicit paths
      await Promise.all([
        faceapi.nets.tinyFaceDetector.loadFromUri(modelPath),
        faceapi.nets.faceExpressionNet.loadFromUri(modelPath)
      ]);
      
      console.log('Face-api models loaded successfully from:', modelPath);
      return; // Successfully loaded
    } catch (err) {
      console.warn(`Failed to load face-api models from ${modelPath}:`, err);
      lastError = err as Error;
      // Continue to the next path
    }
  }
  
  // If we get here, all paths failed
  console.error('Failed to load face-api models from any path');
  throw new Error(`Failed to load face-api models: ${lastError?.message || 'Unknown error'}`);
}

/**
 * Detect facial emotion from a base64 encoded image.
 * @param imageBase64 Base64 encoded image data
 * @returns The detected emotion string or 'neutral' if nothing detected
 */
export async function detectFacialEmotion(imageBase64: string): Promise<{
  emotion: string;
  scores: Record<string, number>;
}> {
  try {
    // Create an HTML image element
    const img = new Image();
    img.src = `data:image/jpeg;base64,${imageBase64}`;
    
    // Wait for the image to load
    await new Promise((resolve) => {
      img.onload = resolve;
    });

    // Run face detection and expression recognition
    const detections = await faceapi
      .detectSingleFace(img, new faceapi.TinyFaceDetectorOptions())
      .withFaceExpressions();

    if (detections) {
      // Get expression with highest confidence
      const expressions = detections.expressions;
      const expressionEntries = Object.entries(expressions);
      const [highestEmotion, highestConfidence] = expressionEntries.reduce(
        (prev, current) => (current[1] > prev[1] ? current : prev)
      );

      // Convert FaceExpressions to Record<string, number> manually
      const expressionsRecord: Record<string, number> = {};
      for (const [key, value] of Object.entries(expressions)) {
        expressionsRecord[key] = value;
      }
      
      return {
        emotion: highestEmotion,
        scores: expressionsRecord
      };
    } else {
      // No face detected, return neutral
      return {
        emotion: 'neutral',
        scores: { neutral: 1.0 }
      };
    }
  } catch (err) {
    console.error('Error detecting facial emotion:', err);
    return {
      emotion: 'neutral',
      scores: { neutral: 1.0 }
    };
  }
}

// Helper to check if models are loaded
export function areModelsLoaded(): boolean {
  return faceapi.nets.tinyFaceDetector.isLoaded && faceapi.nets.faceExpressionNet.isLoaded;
}