import { type ClassValue, clsx } from "clsx"
import { twMerge } from "tailwind-merge"
import { format, addMinutes, addHours, addDays, parse, isValid } from "date-fns"
import { 
  Calendar, 
  Clock, 
  Coffee, 
  ShoppingCart, 
  Briefcase, 
  Pill, 
  DumbbellIcon, 
  HeartPulse, 
  Utensils,
  Phone,
  LucideIcon,
  User,
  BookOpen,
  GraduationCap,
  Plane,
  Music,
  Gamepad2,
  Tv
} from "lucide-react"

// Function to request API keys via the ask_secrets Replit tool
export const ask_secrets = (
  secret_keys: string[],
  user_message: string
) => {
  // Special Replit interface for requesting secrets
  // This is replaced by actual function call during Replit execution
  console.log("Requesting secrets:", secret_keys, user_message);
}

// Types for extracted reminders
interface ExtractedReminder {
  title: string;
  dateTime: Date | null;
  description?: string;
  priority?: 'low' | 'medium' | 'high';
}
 
export function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs))
}

/**
 * Format a datetime to a readable string
 */
export function formatDateTime(date: Date | string): string {
  if (!date) return "";
  const dateObj = typeof date === 'string' ? new Date(date) : date;
  return format(dateObj, 'PPp'); // 'Apr 29, 2023, 1:30 PM'
}

/**
 * Get an icon based on reminder title
 */
export function getReminderIconByTitle(title: string): LucideIcon {
  const lowerTitle = title.toLowerCase();
  
  if (lowerTitle.includes('coffee') || lowerTitle.includes('tea')) return Coffee;
  if (lowerTitle.includes('meeting') || lowerTitle.includes('call')) return Phone;
  if (lowerTitle.includes('shop') || lowerTitle.includes('buy')) return ShoppingCart;
  if (lowerTitle.includes('work') || lowerTitle.includes('deadline')) return Briefcase;
  if (lowerTitle.includes('medicine') || lowerTitle.includes('pill')) return Pill;
  if (lowerTitle.includes('exercise') || lowerTitle.includes('workout')) return DumbbellIcon;
  if (lowerTitle.includes('health') || lowerTitle.includes('doctor')) return HeartPulse;
  if (lowerTitle.includes('eat') || lowerTitle.includes('food') || lowerTitle.includes('meal')) return Utensils;
  if (lowerTitle.includes('appointment')) return Calendar;
  if (lowerTitle.includes('read') || lowerTitle.includes('book')) return BookOpen;
  if (lowerTitle.includes('study') || lowerTitle.includes('class')) return GraduationCap;
  if (lowerTitle.includes('travel') || lowerTitle.includes('trip')) return Plane;
  if (lowerTitle.includes('music') || lowerTitle.includes('concert')) return Music;
  if (lowerTitle.includes('game') || lowerTitle.includes('play')) return Gamepad2;
  if (lowerTitle.includes('watch') || lowerTitle.includes('movie')) return Tv;
  
  // Default icon for time-related reminders
  if (lowerTitle.includes('time') || lowerTitle.includes('remind')) return Clock;
  
  // Fallback to a generic user icon
  return User;
}

/**
 * Extract reminder information from natural language text
 */
export function extractReminder(text: string): ExtractedReminder | null {
  // Early return if text is too short
  if (!text || text.length < 5) return null;
  
  // Check if the text is about setting a reminder
  const reminderIndicators = ['remind', 'remember', 'don\'t forget', 'schedule', 'appointment'];
  const hasReminderIndicator = reminderIndicators.some(indicator => 
    text.toLowerCase().includes(indicator.toLowerCase())
  );
  
  if (!hasReminderIndicator) return null;
  
  // Extract potential title (the main topic of the reminder)
  let title = '';
  
  // Look for patterns like "remind me to..." or "remember to..."
  const toPattern = /(remind|remember|don't forget)\s+(me|us)?\s+to\s+([^,\.!?]+)/i;
  const toMatch = text.match(toPattern);
  
  if (toMatch && toMatch[3]) {
    title = toMatch[3].trim();
  } else {
    // Look for "about..." pattern
    const aboutPattern = /(remind|remember|don't forget)\s+(me|us)?\s+about\s+([^,\.!?]+)/i;
    const aboutMatch = text.match(aboutPattern);
    
    if (aboutMatch && aboutMatch[3]) {
      title = aboutMatch[3].trim();
    } else {
      // Check if there's a more generic subject after reminder indicators
      for (const indicator of reminderIndicators) {
        const index = text.toLowerCase().indexOf(indicator.toLowerCase());
        if (index !== -1) {
          const afterIndicator = text.substring(index + indicator.length).trim();
          // Extract until punctuation or end of string
          const simpleTitleMatch = afterIndicator.match(/^[^,\.!?]+/);
          if (simpleTitleMatch) {
            title = simpleTitleMatch[0].trim();
            break;
          }
        }
      }
    }
  }
  
  // If we still couldn't extract a title, use a default
  if (!title) {
    title = "Reminder";
  }
  
  // Extract date and time information
  let dateTime: Date | null = null;
  
  // Check for specific time patterns
  const timePatterns = [
    // Today at specific time
    { regex: /today\s+at\s+(\d{1,2}):?(\d{2})?\s*(am|pm)?/i, handler: (match: RegExpMatchArray) => {
      const now = new Date();
      let hours = parseInt(match[1]);
      const minutes = match[2] ? parseInt(match[2]) : 0;
      const period = match[3]?.toLowerCase();
      
      // Adjust hours for PM
      if (period === 'pm' && hours < 12) hours += 12;
      if (period === 'am' && hours === 12) hours = 0;
      
      return new Date(now.getFullYear(), now.getMonth(), now.getDate(), hours, minutes);
    }},
    
    // Tomorrow
    { regex: /tomorrow/i, handler: () => {
      const tomorrow = new Date();
      tomorrow.setDate(tomorrow.getDate() + 1);
      return tomorrow;
    }},
    
    // Next specific day
    { regex: /next\s+(monday|tuesday|wednesday|thursday|friday|saturday|sunday)/i, handler: (match: RegExpMatchArray) => {
      const today = new Date();
      const dayNames = ['sunday', 'monday', 'tuesday', 'wednesday', 'thursday', 'friday', 'saturday'];
      const targetDay = dayNames.indexOf(match[1].toLowerCase());
      const todayDay = today.getDay();
      
      let daysToAdd = targetDay - todayDay;
      if (daysToAdd <= 0) daysToAdd += 7; // Next week
      
      return addDays(today, daysToAdd);
    }},
    
    // In X minutes/hours/days
    { regex: /in\s+(\d+)\s+(minute|minutes|hour|hours|day|days)/i, handler: (match: RegExpMatchArray) => {
      const amount = parseInt(match[1]);
      const unit = match[2].toLowerCase();
      const now = new Date();
      
      if (unit.startsWith('minute')) return addMinutes(now, amount);
      if (unit.startsWith('hour')) return addHours(now, amount);
      if (unit.startsWith('day')) return addDays(now, amount);
      
      return now;
    }},
    
    // Specific date formats
    { regex: /(\d{1,2})[-\/](\d{1,2})[-\/](\d{2,4})/i, handler: (match: RegExpMatchArray) => {
      const month = parseInt(match[1]) - 1; // JS months are 0-indexed
      const day = parseInt(match[2]);
      let year = parseInt(match[3]);
      
      // Handle 2-digit years
      if (year < 100) {
        year = year < 50 ? 2000 + year : 1900 + year;
      }
      
      return new Date(year, month, day);
    }},
    
    // Natural language date like "April 15th"
    { regex: /(January|February|March|April|May|June|July|August|September|October|November|December)\s+(\d{1,2})(st|nd|rd|th)?/i, handler: (match: RegExpMatchArray) => {
      const monthNames = ['january', 'february', 'march', 'april', 'may', 'june', 'july', 'august', 'september', 'october', 'november', 'december'];
      const month = monthNames.indexOf(match[1].toLowerCase());
      const day = parseInt(match[2]);
      const now = new Date();
      
      // Default to current year, but if the date would be in the past, use next year
      let year = now.getFullYear();
      const tentativeDate = new Date(year, month, day);
      
      if (tentativeDate < now) {
        year++;
      }
      
      return new Date(year, month, day);
    }}
  ];
  
  // Try each pattern until we find a match
  for (const pattern of timePatterns) {
    const match = text.match(pattern.regex);
    if (match) {
      dateTime = pattern.handler(match);
      break;
    }
  }
  
  // Extract priority
  let priority: 'low' | 'medium' | 'high' | undefined;
  
  if (text.match(/\b(urgent|asap|immediately|critical|high priority)\b/i)) {
    priority = 'high';
  } else if (text.match(/\b(important|soon|medium priority)\b/i)) {
    priority = 'medium';
  } else if (text.match(/\b(whenever|low priority|not urgent)\b/i)) {
    priority = 'low';
  }
  
  // Extract a potential description
  let description: string | undefined;
  
  // Look for explanatory phrases after the main request
  const descPatterns = [
    /because\s+([^\.!?]+)/i,
    /so that\s+([^\.!?]+)/i,
    /for\s+([^\.!?]+)/i
  ];
  
  for (const pattern of descPatterns) {
    const match = text.match(pattern);
    if (match && match[1]) {
      description = match[1].trim();
      break;
    }
  }
  
  return {
    title,
    dateTime,
    description,
    priority
  };
}

/**
 * Analyze user emotions from text
 * This function extracts emotional indicators from text
 */
export function analyzeTextEmotion(text: string): {
  primaryEmotion: string;
  intensity: number;
  indicators: string[];
} {
  const emotionIndicators = {
    happy: ['happy', 'joy', 'excited', 'pleased', 'delighted', 'thrilled', 'glad', 'smile', 'yay', 'fantastic', 'wonderful', 'love it'],
    sad: ['sad', 'unhappy', 'depressed', 'down', 'blue', 'gloomy', 'miserable', 'disappointed', 'upset', 'heartbroken', 'crying'],
    angry: ['angry', 'mad', 'furious', 'irritated', 'annoyed', 'frustrated', 'enraged', 'infuriated', 'hate', 'pissed', 'outraged'],
    anxious: ['anxious', 'worried', 'nervous', 'afraid', 'scared', 'fearful', 'stressed', 'uneasy', 'tense', 'concerned', 'dread'],
    surprised: ['surprised', 'shocked', 'amazed', 'astonished', 'stunned', 'wow', 'unexpected', 'incredible', 'unbelievable'],
    confused: ['confused', 'puzzled', 'perplexed', 'uncertain', 'unsure', 'bewildered', 'disoriented', 'lost', 'unclear'],
    neutral: ['fine', 'okay', 'ok', 'alright', 'neutral', 'so-so', 'meh']
  };
  
  const intensifiers = ['very', 'extremely', 'incredibly', 'really', 'so', 'absolutely', 'totally', 'completely', 'utterly'];
  
  // Count occurrences of emotion words
  const emotionCounts: Record<string, { count: number, indicators: string[] }> = {
    happy: { count: 0, indicators: [] },
    sad: { count: 0, indicators: [] },
    angry: { count: 0, indicators: [] },
    anxious: { count: 0, indicators: [] },
    surprised: { count: 0, indicators: [] },
    confused: { count: 0, indicators: [] },
    neutral: { count: 0, indicators: [] }
  };
  
  // Base intensity
  let intensity = 0.5;
  
  // Check for intensifiers
  intensifiers.forEach(intensifier => {
    if (text.toLowerCase().includes(intensifier)) {
      intensity += 0.1; // Increase intensity for each intensifier found
    }
  });
  
  // Count emotion indicators
  const lowerText = text.toLowerCase();
  Object.entries(emotionIndicators).forEach(([emotion, indicators]) => {
    indicators.forEach(indicator => {
      // Check for the indicator as a whole word
      const regex = new RegExp(`\\b${indicator}\\b`, 'i');
      if (regex.test(lowerText)) {
        emotionCounts[emotion].count++;
        emotionCounts[emotion].indicators.push(indicator);
      }
    });
  });
  
  // Find the emotion with the highest count
  let primaryEmotion = 'neutral';
  let maxCount = 0;
  
  Object.entries(emotionCounts).forEach(([emotion, data]) => {
    if (data.count > maxCount) {
      maxCount = data.count;
      primaryEmotion = emotion;
    }
  });
  
  // Adjust intensity based on count
  if (maxCount > 0) {
    intensity = Math.min(1.0, intensity + (maxCount * 0.1));
  }
  
  // Cap intensity between 0.1 and 1.0
  intensity = Math.max(0.1, Math.min(1.0, intensity));
  
  return {
    primaryEmotion,
    intensity,
    indicators: emotionCounts[primaryEmotion].indicators
  };
}

/**
 * Function to create human-like typing delays
 * Returns a promise that resolves after a delay proportional to text length
 */
export function createTypingDelay(text: string): Promise<void> {
  // Base speed: ~200-300 characters per minute for average typing
  const baseDelay = 200; // milliseconds
  const charsPerTime = 5; // characters per time unit
  
  // Calculate delay based on text length
  const delay = Math.min(3000, baseDelay + (text.length / charsPerTime * 10)); 
  
  return new Promise(resolve => setTimeout(resolve, delay));
}