import { multiAI } from './multiAI';

export interface ConversationContext {
  recentMessages: {
    role: 'user' | 'assistant';
    content: string;
    timestamp: Date;
  }[];
  userTopics: string[];
  userPreferences: Record<string, any>;
  userEmotionalState: string;
  environmentContext?: {
    location?: string;
    activity?: string;
    timeOfDay?: string;
    detectedObjects?: string[];
  };
  lastInteractionTime?: Date;
  pendingQuestions?: string[];
  conversationStage: 'greeting' | 'discussion' | 'clarification' | 'conclusion' | 'idle';
}

export interface DialogueOptions {
  emotionalTone?: 'neutral' | 'empathetic' | 'professional' | 'friendly' | 'concerned';
  responseLength?: 'concise' | 'moderate' | 'detailed';
  includeSuggestions?: boolean;
  includeFollowUpQuestions?: boolean;
  maintenanceMode?: boolean;
}

const defaultContext: ConversationContext = {
  recentMessages: [],
  userTopics: [],
  userPreferences: {},
  userEmotionalState: 'neutral',
  conversationStage: 'greeting'
};

const defaultOptions: DialogueOptions = {
  emotionalTone: 'neutral',
  responseLength: 'moderate',
  includeSuggestions: true,
  includeFollowUpQuestions: true,
  maintenanceMode: false
};

/**
 * Determine what stage of the conversation we're in based on context
 */
export function determineConversationStage(context: ConversationContext): 'greeting' | 'discussion' | 'clarification' | 'conclusion' | 'idle' {
  const messages = context.recentMessages;
  
  // If no messages, we're in greeting stage
  if (messages.length === 0) {
    return 'greeting';
  }
  
  // Check if the last interaction was more than 5 minutes ago
  const now = new Date();
  const lastInteractionTime = context.lastInteractionTime || now;
  const timeSinceLastInteraction = now.getTime() - lastInteractionTime.getTime();
  
  // If more than 5 minutes since last interaction, reset to idle
  if (timeSinceLastInteraction > 5 * 60 * 1000) { // 5 minutes in ms
    return 'idle';
  }
  
  // If the user's last message was a question, we're in clarification
  const lastUserMessage = [...messages].reverse().find(m => m.role === 'user')?.content || '';
  if (lastUserMessage.endsWith('?')) {
    return 'clarification';
  }
  
  // If we've exchanged a lot of messages, we're in discussion
  if (messages.length > 4) {
    return 'discussion';
  }
  
  // If we just received a closing phrase like "thank you" or "goodbye"
  const closingPhrases = ['thank you', 'thanks', 'bye', 'goodbye', 'see you', 'later'];
  if (closingPhrases.some(phrase => lastUserMessage.toLowerCase().includes(phrase))) {
    return 'conclusion';
  }
  
  return 'discussion';
}

/**
 * Detects user intent from their message
 */
export function detectUserIntent(message: string): 'question' | 'statement' | 'command' | 'greeting' | 'farewell' | 'unknown' {
  // Check for questions
  if (message.endsWith('?') || message.toLowerCase().startsWith('what') || 
      message.toLowerCase().startsWith('how') || message.toLowerCase().startsWith('why') ||
      message.toLowerCase().startsWith('when') || message.toLowerCase().startsWith('where') ||
      message.toLowerCase().startsWith('who') || message.toLowerCase().startsWith('can you') ||
      message.toLowerCase().startsWith('could you')) {
    return 'question';
  }
  
  // Check for commands
  if (message.toLowerCase().startsWith('please') || message.toLowerCase().includes('i need') ||
      message.toLowerCase().includes('i want') || message.toLowerCase().startsWith('help me') ||
      message.toLowerCase().includes('remind me') || message.toLowerCase().startsWith('set a')) {
    return 'command';
  }
  
  // Check for greetings
  const greetings = ['hi', 'hello', 'hey', 'good morning', 'good afternoon', 'good evening', 'greetings'];
  if (greetings.some(greeting => message.toLowerCase().startsWith(greeting))) {
    return 'greeting';
  }
  
  // Check for farewells
  const farewells = ['bye', 'goodbye', 'see you', 'farewell', 'good night', 'catch you later'];
  if (farewells.some(farewell => message.toLowerCase().includes(farewell))) {
    return 'farewell';
  }
  
  // Default to statement
  return 'statement';
}

/**
 * Adjusts the response style based on the detected emotion
 */
export function adaptToEmotionalState(options: DialogueOptions, emotionalState: string): DialogueOptions {
  const adjustedOptions = { ...options };
  
  switch (emotionalState.toLowerCase()) {
    case 'happy':
    case 'excited':
      adjustedOptions.emotionalTone = 'friendly';
      break;
    case 'sad':
    case 'depressed':
      adjustedOptions.emotionalTone = 'empathetic';
      adjustedOptions.responseLength = 'moderate';
      break;
    case 'angry':
    case 'frustrated':
      adjustedOptions.emotionalTone = 'professional';
      adjustedOptions.responseLength = 'concise';
      break;
    case 'anxious':
    case 'worried':
      adjustedOptions.emotionalTone = 'concerned';
      adjustedOptions.includeSuggestions = true;
      break;
    default:
      // Keep default options
      break;
  }
  
  return adjustedOptions;
}

/**
 * Generates a response using the right prompting strategy based on conversation context and detected intent
 */
export async function generateContextualResponse(
  userMessage: string,
  context: ConversationContext,
  options: DialogueOptions = defaultOptions
): Promise<string> {
  // Update conversation stage
  const stage = determineConversationStage(context);
  context.conversationStage = stage;
  
  // Detect intent
  const intent = detectUserIntent(userMessage);
  
  // Adapt to emotional state
  const adjustedOptions = adaptToEmotionalState(options, context.userEmotionalState);
  
  // Build the system prompt based on context and options
  let systemPrompt = 'You are an emotionally intelligent AI assistant. ';
  
  // Add emotional tone instructions
  switch (adjustedOptions.emotionalTone) {
    case 'empathetic':
      systemPrompt += 'Be warm, empathetic, and understanding. ';
      break;
    case 'professional':
      systemPrompt += 'Be professional, clear, and focused on solutions. ';
      break;
    case 'friendly':
      systemPrompt += 'Be friendly, conversational, and slightly informal. ';
      break;
    case 'concerned':
      systemPrompt += 'Be supportive, caring, and reassuring. ';
      break;
    default:
      systemPrompt += 'Be helpful, clear, and natural in your responses. ';
  }
  
  // Add response length instructions
  switch (adjustedOptions.responseLength) {
    case 'concise':
      systemPrompt += 'Keep responses brief and to the point. ';
      break;
    case 'detailed':
      systemPrompt += 'Provide comprehensive, thorough responses with detail. ';
      break;
    default:
      systemPrompt += 'Aim for balanced, moderately detailed responses. ';
  }
  
  // Add context-specific information
  if (context.userTopics.length > 0) {
    systemPrompt += `The user has shown interest in: ${context.userTopics.join(', ')}. `;
  }
  
  if (Object.keys(context.userPreferences).length > 0) {
    const preferences = Object.entries(context.userPreferences)
      .map(([key, value]) => `${key}: ${value}`)
      .join(', ');
    systemPrompt += `The user's known preferences: ${preferences}. `;
  }
  
  // Add instructions for conversation stage
  switch (stage) {
    case 'greeting':
      systemPrompt += 'The conversation is just beginning. Start warmly and build rapport. ';
      break;
    case 'discussion':
      systemPrompt += 'The conversation is ongoing. Maintain continuity with previous exchanges. ';
      break;
    case 'clarification':
      systemPrompt += 'The user has asked a question. Provide clear, accurate information. ';
      break;
    case 'conclusion':
      systemPrompt += 'The conversation appears to be concluding. Wrap up gracefully. ';
      break;
    case 'idle':
      systemPrompt += 'The conversation is resuming after a period of inactivity. Provide a gentle reintroduction. ';
      break;
  }
  
  // Add user emotional state context
  systemPrompt += `The user appears to be feeling ${context.userEmotionalState}. `;
  
  // For maintenance mode (when APIs are having issues)
  if (adjustedOptions.maintenanceMode) {
    systemPrompt += 'Note: You are in maintenance mode with limited functionality. ' +
      'Be upfront about limitations while still being helpful. ';
  }
  
  // Build conversation context for the AI
  let conversationContext = '';
  
  // Add recent conversation history for context
  if (context.recentMessages.length > 0) {
    conversationContext += 'Recent conversation:\n';
    // Take last 5 messages maximum
    const recentMessages = context.recentMessages.slice(-5);
    recentMessages.forEach(msg => {
      conversationContext += `${msg.role === 'user' ? 'User' : 'Assistant'}: ${msg.content}\n`;
    });
  }
  
  // Add environmental context if available
  if (context.environmentContext) {
    conversationContext += 'Environmental context:\n';
    if (context.environmentContext.location) {
      conversationContext += `Location: ${context.environmentContext.location}\n`;
    }
    if (context.environmentContext.activity) {
      conversationContext += `Activity: ${context.environmentContext.activity}\n`;
    }
    if (context.environmentContext.timeOfDay) {
      conversationContext += `Time: ${context.environmentContext.timeOfDay}\n`;
    }
    if (context.environmentContext.detectedObjects && context.environmentContext.detectedObjects.length > 0) {
      conversationContext += `Objects in environment: ${context.environmentContext.detectedObjects.join(', ')}\n`;
    }
  }
  
  // Try to generate a response using the MultiAI service
  try {
    return await multiAI.generateResponse(userMessage, `${systemPrompt}\n\n${conversationContext}`);
  } catch (error) {
    console.error('Error generating contextual response:', error);
    
    // Fallback responses based on intent if AI generation fails
    if (intent === 'greeting') {
      return "Hello! I'm here to help you today. How can I assist you?";
    } else if (intent === 'farewell') {
      return "Goodbye! It was nice chatting with you. Feel free to reach out whenever you need assistance.";
    } else if (intent === 'question') {
      return "That's an interesting question. I'm having some trouble with my knowledge systems at the moment. Could you ask me again in a bit?";
    } else {
      return "I appreciate your message. I'm experiencing some temporary issues with my thinking systems, but I'll be fully operational again soon.";
    }
  }
}