import * as openAI from './openai';
import * as anthropicAI from './anthropic';
import { apiRequest } from '@/lib/queryClient';

// Supported AI providers
export type AIProvider = 'openai' | 'anthropic' | 'auto';

/**
 * Client-side MultiAI service for handling multiple AI providers
 * Automatically falls back to available providers if one fails
 */
export class MultiAIService {
  private preferredProvider: AIProvider = 'auto';
  private providerStatus: Record<string, boolean> = {
    openai: true,
    anthropic: true
  };

  constructor() {
    // Check provider availability on initialization
    this.checkProviderStatus();
  }

  /**
   * Check the status of all AI providers
   */
  async checkProviderStatus(): Promise<void> {
    // Check OpenAI
    try {
      const openAIResponse = await apiRequest('/api/openai/test');
      const openAIData = await openAIResponse.json();
      this.providerStatus.openai = openAIData.success;
    } catch (error) {
      console.error('Error checking OpenAI status:', error);
      this.providerStatus.openai = false;
    }

    // Check Anthropic
    try {
      const anthropicResponse = await apiRequest('/api/anthropic/test');
      const anthropicData = await anthropicResponse.json();
      this.providerStatus.anthropic = anthropicData.success;
    } catch (error) {
      console.error('Error checking Anthropic status:', error);
      this.providerStatus.anthropic = false;
    }
  }

  /**
   * Generate a response using the selected provider
   */
  async generateResponse(
    prompt: string,
    context: string = '',
    provider: AIProvider = this.preferredProvider
  ): Promise<string> {
    // Emergency fallback responses when APIs are unavailable
    const fallbackResponses = [
      "I'm currently experiencing connectivity issues with my thinking system. I'll be fully operational soon.",
      "My advanced thinking capabilities are temporarily offline. I'm still here to assist you, but with limited responses for now.",
      "I'm having trouble accessing my knowledge base at the moment. Please try again in a few moments.",
      "I'm currently operating in limited mode while my main systems reconnect. I'll be back to full capacity shortly.",
      "My advanced reasoning systems are currently updating. I'll be able to provide more detailed responses soon."
    ];
    
    try {
      if (provider === 'auto') {
        try {
          // Try OpenAI first if available
          if (this.providerStatus.openai) {
            return await openAI.generateResponse(prompt, context);
          } 
          // Fall back to Anthropic if available
          else if (this.providerStatus.anthropic) {
            return await anthropicAI.generateResponse(prompt, context);
          }
          // No providers available - use fallback
          else {
            console.warn('No AI providers available, using fallback response');
            return this.getFallbackResponse(prompt, fallbackResponses);
          }
        } catch (error) {
          console.error('Error using auto provider:', error);
          // If OpenAI failed, try Anthropic
          if (this.providerStatus.anthropic) {
            try {
              return await anthropicAI.generateResponse(prompt, context);
            } catch (anthropicError) {
              console.error('Anthropic fallback failed:', anthropicError);
              return this.getFallbackResponse(prompt, fallbackResponses);
            }
          }
          return this.getFallbackResponse(prompt, fallbackResponses);
        }
      } else if (provider === 'openai') {
        try {
          return await openAI.generateResponse(prompt, context);
        } catch (error) {
          console.error('OpenAI provider failed:', error);
          return this.getFallbackResponse(prompt, fallbackResponses);
        }
      } else if (provider === 'anthropic') {
        try {
          return await anthropicAI.generateResponse(prompt, context);
        } catch (error) {
          console.error('Anthropic provider failed:', error);
          return this.getFallbackResponse(prompt, fallbackResponses);
        }
      }

      throw new Error(`Unknown provider: ${provider}`);
    } catch (error) {
      console.error('All AI providers failed:', error);
      return this.getFallbackResponse(prompt, fallbackResponses);
    }
  }
  
  /**
   * Get a contextually appropriate fallback response when AI services are unavailable
   */
  private getFallbackResponse(prompt: string, fallbackResponses: string[]): string {
    // For questions, use a different response set
    if (prompt.trim().endsWith('?')) {
      return "I'm sorry, I can't answer questions right now while my knowledge systems are updating. Please try again later.";
    }
    
    // For greetings, respond appropriately
    if (/^(hi|hello|hey|greetings)/i.test(prompt.trim())) {
      return "Hello! I'm currently operating in limited mode while my systems are updating. I'll be fully operational soon.";
    }
    
    // Pick a random fallback response for other cases
    const randomIndex = Math.floor(Math.random() * fallbackResponses.length);
    return fallbackResponses[randomIndex];
  }

  /**
   * Analyze an image using the selected provider
   */
  async analyzeImage(
    imageBase64: string,
    prompt: string = 'Analyze this image in detail and describe what you see:',
    provider: AIProvider = this.preferredProvider
  ): Promise<string> {
    // Fallback responses for image analysis
    const fallbackResponses = [
      "I'm having trouble processing this image at the moment. My vision systems are currently limited.",
      "I can't analyze this image right now. My visual processing capabilities are temporarily offline.",
      "I'm unable to process visual information at the moment. Please try again later when my systems are fully restored."
    ];
    
    try {
      if (provider === 'auto') {
        try {
          // Try OpenAI first if available
          if (this.providerStatus.openai) {
            return await openAI.analyzeImage(imageBase64, prompt);
          } 
          // Fall back to Anthropic if available
          else if (this.providerStatus.anthropic) {
            return await anthropicAI.analyzeImage(imageBase64, prompt);
          }
          // No providers available - use fallback
          else {
            console.warn('No AI providers available for image analysis, using fallback response');
            const randomIndex = Math.floor(Math.random() * fallbackResponses.length);
            return fallbackResponses[randomIndex];
          }
        } catch (error) {
          console.error('Error using auto provider for image analysis:', error);
          // If OpenAI failed, try Anthropic
          if (this.providerStatus.anthropic) {
            try {
              return await anthropicAI.analyzeImage(imageBase64, prompt);
            } catch (anthropicError) {
              console.error('Anthropic image analysis fallback failed:', anthropicError);
              const randomIndex = Math.floor(Math.random() * fallbackResponses.length);
              return fallbackResponses[randomIndex];
            }
          }
          const randomIndex = Math.floor(Math.random() * fallbackResponses.length);
          return fallbackResponses[randomIndex];
        }
      } else if (provider === 'openai') {
        try {
          return await openAI.analyzeImage(imageBase64, prompt);
        } catch (error) {
          console.error('OpenAI image analysis failed:', error);
          const randomIndex = Math.floor(Math.random() * fallbackResponses.length);
          return fallbackResponses[randomIndex];
        }
      } else if (provider === 'anthropic') {
        try {
          return await anthropicAI.analyzeImage(imageBase64, prompt);
        } catch (error) {
          console.error('Anthropic image analysis failed:', error);
          const randomIndex = Math.floor(Math.random() * fallbackResponses.length);
          return fallbackResponses[randomIndex];
        }
      }

      const randomIndex = Math.floor(Math.random() * fallbackResponses.length);
      return fallbackResponses[randomIndex];
    } catch (error) {
      console.error('All image analysis providers failed:', error);
      const randomIndex = Math.floor(Math.random() * fallbackResponses.length);
      return fallbackResponses[randomIndex];
    }
  }

  /**
   * Detect emotion from an image using the selected provider
   */
  async detectEmotion(
    imageBase64: string,
    provider: AIProvider = this.preferredProvider
  ): Promise<string> {
    try {
      if (provider === 'auto') {
        try {
          // Try OpenAI first if available
          if (this.providerStatus.openai) {
            return await openAI.detectEmotion(imageBase64);
          } 
          // Fall back to Anthropic if available
          else if (this.providerStatus.anthropic) {
            return await anthropicAI.detectEmotion(imageBase64);
          }
          // No providers available
          else {
            console.warn('No AI providers available for emotion detection, using default');
            return 'neutral';
          }
        } catch (error) {
          console.error('Error using auto provider for emotion detection:', error);
          // If OpenAI failed, try Anthropic
          if (this.providerStatus.anthropic) {
            try {
              return await anthropicAI.detectEmotion(imageBase64);
            } catch (anthropicError) {
              console.error('Anthropic emotion detection fallback failed:', anthropicError);
              return 'neutral'; // Default fallback
            }
          }
          return 'neutral'; // Default fallback
        }
      } else if (provider === 'openai') {
        try {
          return await openAI.detectEmotion(imageBase64);
        } catch (error) {
          console.error('OpenAI emotion detection failed:', error);
          return 'neutral';
        }
      } else if (provider === 'anthropic') {
        try {
          return await anthropicAI.detectEmotion(imageBase64);
        } catch (error) {
          console.error('Anthropic emotion detection failed:', error);
          return 'neutral';
        }
      }
    } catch (error) {
      console.error('All emotion detection providers failed:', error);
    }

    return 'neutral'; // Default fallback
  }

  /**
   * Analyze the environment from an image using the selected provider
   */
  async analyzeEnvironment(
    imageBase64: string,
    provider: AIProvider = this.preferredProvider
  ): Promise<any> {
    // Default environment analysis when APIs are unavailable
    const defaultEnvironment = {
      lighting: 'moderate',
      objects: [],
      scene: 'unknown',
      peopleCount: 0,
      isBusy: false,
      isOutdoors: false,
      hazards: []
    };
    
    try {
      if (provider === 'auto') {
        try {
          // Try OpenAI first if available
          if (this.providerStatus.openai) {
            return await openAI.analyzeEnvironment(imageBase64);
          } 
          // Fall back to Anthropic if available
          else if (this.providerStatus.anthropic) {
            return await anthropicAI.analyzeEnvironment(imageBase64);
          }
          // No providers available
          else {
            console.warn('No AI providers available for environment analysis, using default');
            return defaultEnvironment;
          }
        } catch (error) {
          console.error('Error using auto provider for environment analysis:', error);
          // If OpenAI failed, try Anthropic
          if (this.providerStatus.anthropic) {
            try {
              return await anthropicAI.analyzeEnvironment(imageBase64);
            } catch (anthropicError) {
              console.error('Anthropic environment analysis fallback failed:', anthropicError);
              return defaultEnvironment;
            }
          }
          return defaultEnvironment;
        }
      } else if (provider === 'openai') {
        try {
          return await openAI.analyzeEnvironment(imageBase64);
        } catch (error) {
          console.error('OpenAI environment analysis failed:', error);
          return defaultEnvironment;
        }
      } else if (provider === 'anthropic') {
        try {
          return await anthropicAI.analyzeEnvironment(imageBase64);
        } catch (error) {
          console.error('Anthropic environment analysis failed:', error);
          return defaultEnvironment;
        }
      }
    } catch (error) {
      console.error('All environment analysis providers failed:', error);
    }
    
    // Return default environment analysis
    return defaultEnvironment;
  }

  /**
   * Set the preferred provider for all operations
   */
  setPreferredProvider(provider: AIProvider): void {
    this.preferredProvider = provider;
  }

  /**
   * Get the current status of all providers
   */
  getProviderStatus(): Record<string, boolean> {
    return { ...this.providerStatus };
  }
}

// Export a singleton instance
export const multiAI = new MultiAIService();