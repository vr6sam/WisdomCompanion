import React, { useState, useEffect } from 'react';
import { useScout } from './useScout';
import ScoutPopup from './ScoutPopup';

function App() {
  const { transcript, toggleListening, speak, isListening } = useScout();
  const [popupVisible, setPopupVisible] = useState(false);
  const [popupText, setPopupText] = useState('');

  useEffect(() => {
    if (transcript.toLowerCase().includes('what now')) {
      setPopupText("You're crushing it. Want help with the shop or app?");
      setPopupVisible(true);
      speak("You're crushing it. Want help with the shop or app?");
      setTimeout(() => setPopupVisible(false), 6000);
    }
  }, [transcript]);

  return (
    <div>
      <h1>WisdomCompanion + Scout Mode</h1>
      <button onClick={toggleListening}>
        {isListening ? '🛑 Stop Scout' : '🎙️ Start Scout'}
      </button>
      <ScoutPopup text={popupText} visible={popupVisible} />
    </div>
  );
}

export default App;