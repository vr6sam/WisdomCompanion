import { useState, useEffect, useCallback } from 'react';
import { useToast } from './use-toast';

export interface ConversationMemory {
  topics: {
    name: string;
    mentions: number;
    lastMentioned: Date;
    importance: number; // 0-1 scale
  }[];
  preferences: Record<string, any>;
  facts: {
    content: string;
    confidence: number; // 0-1 scale
    source: 'user' | 'inference';
    timestamp: Date;
  }[];
  emotions: {
    type: string;
    timestamp: Date;
    intensity: number; // 0-1 scale
    trigger?: string;
  }[];
  schedule: {
    event: string;
    date: Date;
    importance: number; // 0-1 scale
  }[];
}

// Initial empty memory structure
const initialMemory: ConversationMemory = {
  topics: [],
  preferences: {},
  facts: [],
  emotions: [],
  schedule: []
};

export function useConversationMemory() {
  const [memory, setMemory] = useState<ConversationMemory>(initialMemory);
  const [memoryLoaded, setMemoryLoaded] = useState(false);
  const { toast } = useToast();

  // Load memory from localStorage on init
  useEffect(() => {
    try {
      const savedMemory = localStorage.getItem('conversation_memory');
      if (savedMemory) {
        const parsedMemory = JSON.parse(savedMemory);
        
        // Convert date strings back to Date objects
        if (parsedMemory.topics) {
          parsedMemory.topics.forEach((topic: any) => {
            topic.lastMentioned = new Date(topic.lastMentioned);
          });
        }
        
        if (parsedMemory.facts) {
          parsedMemory.facts.forEach((fact: any) => {
            fact.timestamp = new Date(fact.timestamp);
          });
        }
        
        if (parsedMemory.emotions) {
          parsedMemory.emotions.forEach((emotion: any) => {
            emotion.timestamp = new Date(emotion.timestamp);
          });
        }
        
        if (parsedMemory.schedule) {
          parsedMemory.schedule.forEach((event: any) => {
            event.date = new Date(event.date);
          });
        }
        
        setMemory(parsedMemory);
      }
      setMemoryLoaded(true);
    } catch (error) {
      console.error('Error loading conversation memory:', error);
      setMemoryLoaded(true);
    }
  }, []);

  // Save memory to localStorage whenever it changes
  useEffect(() => {
    if (memoryLoaded) {
      localStorage.setItem('conversation_memory', JSON.stringify(memory));
    }
  }, [memory, memoryLoaded]);

  // Add or update a topic in memory
  const rememberTopic = useCallback((topic: string, importance: number = 0.5) => {
    setMemory(prev => {
      const existingTopicIndex = prev.topics.findIndex(t => t.name.toLowerCase() === topic.toLowerCase());
      
      if (existingTopicIndex >= 0) {
        // Update existing topic
        const updatedTopics = [...prev.topics];
        updatedTopics[existingTopicIndex] = {
          ...updatedTopics[existingTopicIndex],
          mentions: updatedTopics[existingTopicIndex].mentions + 1,
          lastMentioned: new Date(),
          importance: Math.max(updatedTopics[existingTopicIndex].importance, importance)
        };
        
        return {
          ...prev,
          topics: updatedTopics
        };
      } else {
        // Add new topic
        return {
          ...prev,
          topics: [
            ...prev.topics,
            {
              name: topic,
              mentions: 1,
              lastMentioned: new Date(),
              importance
            }
          ]
        };
      }
    });
  }, []);

  // Remember a user preference
  const rememberPreference = useCallback((key: string, value: any) => {
    setMemory(prev => ({
      ...prev,
      preferences: {
        ...prev.preferences,
        [key]: value
      }
    }));
  }, []);

  // Remember a fact about the user
  const rememberFact = useCallback((content: string, confidence: number = 0.8, source: 'user' | 'inference' = 'user') => {
    setMemory(prev => ({
      ...prev,
      facts: [
        ...prev.facts,
        {
          content,
          confidence,
          source,
          timestamp: new Date()
        }
      ]
    }));
  }, []);

  // Remember an emotion the user expressed
  const rememberEmotion = useCallback((type: string, intensity: number = 0.5, trigger?: string) => {
    setMemory(prev => ({
      ...prev,
      emotions: [
        ...prev.emotions,
        {
          type,
          intensity,
          trigger,
          timestamp: new Date()
        }
      ].slice(-20) // Keep only last 20 emotions
    }));
  }, []);

  // Remember a scheduled event
  const rememberSchedule = useCallback((event: string, date: Date, importance: number = 0.5) => {
    setMemory(prev => ({
      ...prev,
      schedule: [
        ...prev.schedule,
        {
          event,
          date,
          importance
        }
      ]
    }));
  }, []);

  // Get the user's top interests based on topic mentions and importance
  const getTopInterests = useCallback((limit: number = 5) => {
    return [...memory.topics]
      .sort((a, b) => {
        // Combine mentions and importance for sorting
        const scoreA = (a.mentions * 0.7) + (a.importance * 0.3);
        const scoreB = (b.mentions * 0.7) + (b.importance * 0.3);
        return scoreB - scoreA;
      })
      .slice(0, limit);
  }, [memory.topics]);

  // Get recent emotions to understand the user's emotional state
  const getRecentEmotions = useCallback((limit: number = 5) => {
    return [...memory.emotions]
      .sort((a, b) => b.timestamp.getTime() - a.timestamp.getTime())
      .slice(0, limit);
  }, [memory.emotions]);

  // Get upcoming scheduled events
  const getUpcomingEvents = useCallback(() => {
    const now = new Date();
    return [...memory.schedule]
      .filter(event => event.date > now)
      .sort((a, b) => a.date.getTime() - b.date.getTime());
  }, [memory.schedule]);

  // Extract memory summary for context in conversations
  const getMemorySummary = useCallback(() => {
    const topInterests = getTopInterests(3).map(t => t.name).join(', ');
    const recentEmotions = getRecentEmotions(3).map(e => e.type).join(', ');
    const upcomingEvents = getUpcomingEvents().slice(0, 2).map(e => `${e.event} on ${e.date.toLocaleDateString()}`).join(', ');
    
    const preferences = Object.entries(memory.preferences)
      .slice(0, 5)
      .map(([key, value]) => `${key}: ${value}`)
      .join(', ');
    
    const importantFacts = memory.facts
      .filter(f => f.confidence > 0.7)
      .slice(0, 5)
      .map(f => f.content)
      .join('; ');
    
    return {
      topInterests: topInterests || 'No interests recorded yet',
      recentEmotions: recentEmotions || 'No emotions recorded yet',
      upcomingEvents: upcomingEvents || 'No upcoming events',
      preferences: preferences || 'No preferences recorded yet',
      importantFacts: importantFacts || 'No important facts recorded yet'
    };
  }, [memory, getTopInterests, getRecentEmotions, getUpcomingEvents]);

  // Function to extract reminders/events from a conversation
  const extractReminders = useCallback((text: string): {title: string, date: Date, description: string}[] => {
    // Simple extraction - for demo purposes
    const reminderRegex = /remind(?:er)?\s+(?:me\s+)?(?:to\s+)?(.+?)(?:\s+on\s+|\s+at\s+|\s+by\s+)(.+?)(?:$|\.|\?|,)/gi;
    
    const reminders = [];
    let match;
    
    while ((match = reminderRegex.exec(text)) !== null) {
      const title = match[1].trim();
      const dateStr = match[2].trim();
      
      try {
        // Try to parse the date string
        const date = new Date(dateStr);
        
        // Check if date is valid
        if (!isNaN(date.getTime())) {
          reminders.push({
            title,
            date,
            description: `Reminder extracted from conversation: "${title} on ${dateStr}"`
          });
        }
      } catch (e) {
        console.warn('Failed to parse date for reminder:', e);
      }
    }
    
    return reminders;
  }, []);

  // Process and learn from a conversation exchange
  const learnFromConversation = useCallback((userMessage: string, aiResponse: string) => {
    // Extract topics (simple approach - could be more sophisticated with NLP)
    const words = userMessage.toLowerCase().split(/\W+/);
    const commonWords = new Set(['i', 'me', 'my', 'myself', 'we', 'our', 'ours', 'ourselves', 'you', 'your', 'yours', 'yourself', 'yourselves', 'he', 'him', 'his', 'himself', 'she', 'her', 'hers', 'herself', 'it', 'its', 'itself', 'they', 'them', 'their', 'theirs', 'themselves', 'what', 'which', 'who', 'whom', 'this', 'that', 'these', 'those', 'am', 'is', 'are', 'was', 'were', 'be', 'been', 'being', 'have', 'has', 'had', 'having', 'do', 'does', 'did', 'doing', 'a', 'an', 'the', 'and', 'but', 'if', 'or', 'because', 'as', 'until', 'while', 'of', 'at', 'by', 'for', 'with', 'about', 'against', 'between', 'into', 'through', 'during', 'before', 'after', 'above', 'below', 'to', 'from', 'up', 'down', 'in', 'out', 'on', 'off', 'over', 'under', 'again', 'further', 'then', 'once', 'here', 'there', 'when', 'where', 'why', 'how', 'all', 'any', 'both', 'each', 'few', 'more', 'most', 'other', 'some', 'such', 'no', 'nor', 'not', 'only', 'own', 'same', 'so', 'than', 'too', 'very', 's', 't', 'can', 'will', 'just', 'don', 'should', 'now']);
    
    const potentialTopics = words
      .filter(word => word.length > 3 && !commonWords.has(word))
      .reduce((acc, word) => {
        acc[word] = (acc[word] || 0) + 1;
        return acc;
      }, {} as Record<string, number>);
    
    // Find the top 2 potential topics
    const topTopics = Object.entries(potentialTopics)
      .sort((a, b) => b[1] - a[1])
      .slice(0, 2)
      .map(([word]) => word);
    
    // Remember these topics
    topTopics.forEach(topic => rememberTopic(topic, 0.6));
    
    // Extract preferences
    if (userMessage.includes('I like') || userMessage.includes('I love') || userMessage.includes('I enjoy')) {
      const preferenceMatch = userMessage.match(/I (?:like|love|enjoy) (.+?)(?:$|\.|\?|,)/i);
      if (preferenceMatch && preferenceMatch[1]) {
        const preference = preferenceMatch[1].trim();
        rememberPreference('likes', preference);
        
        // Also add as a topic with high importance
        rememberTopic(preference, 0.8);
      }
    }
    
    if (userMessage.includes('I hate') || userMessage.includes('I dislike') || userMessage.includes("I don't like")) {
      const dislikeMatch = userMessage.match(/I (?:hate|dislike|don't like) (.+?)(?:$|\.|\?|,)/i);
      if (dislikeMatch && dislikeMatch[1]) {
        const dislike = dislikeMatch[1].trim();
        rememberPreference('dislikes', dislike);
      }
    }
    
    // Extract facts
    if (userMessage.includes('I am') || userMessage.includes("I'm")) {
      const factMatch = userMessage.match(/I(?:'m| am) (.+?)(?:$|\.|\?|,)/i);
      if (factMatch && factMatch[1]) {
        const fact = factMatch[1].trim();
        if (!fact.startsWith('just') && !fact.startsWith('not sure') && !fact.startsWith('thinking')) {
          rememberFact(fact, 0.9, 'user');
        }
      }
    }
    
    // Extract emotions
    const emotionKeywords = {
      happy: ['happy', 'glad', 'excited', 'thrilled', 'pleased', 'joyful', 'delighted'],
      sad: ['sad', 'upset', 'unhappy', 'depressed', 'blue', 'down', 'miserable'],
      angry: ['angry', 'mad', 'furious', 'annoyed', 'irritated', 'frustrated'],
      anxious: ['anxious', 'worried', 'nervous', 'stressed', 'concerned', 'afraid'],
      confused: ['confused', 'lost', 'unsure', 'uncertain', 'puzzled'],
      tired: ['tired', 'exhausted', 'sleepy', 'drained', 'fatigued']
    };
    
    for (const [emotion, keywords] of Object.entries(emotionKeywords)) {
      for (const keyword of keywords) {
        if (userMessage.toLowerCase().includes(`I'm ${keyword}`) || 
            userMessage.toLowerCase().includes(`I am ${keyword}`) || 
            userMessage.toLowerCase().includes(`I feel ${keyword}`)) {
          rememberEmotion(emotion, 0.8);
          break;
        }
      }
    }
    
    // Extract potential reminders
    const reminders = extractReminders(userMessage);
    reminders.forEach(reminder => {
      rememberSchedule(reminder.title, reminder.date, 0.7);
      
      // Notify the user we extracted a reminder
      toast({
        title: "Reminder Added",
        description: `I'll remind you: ${reminder.title} on ${reminder.date.toLocaleDateString()}`,
      });
    });
    
  }, [rememberTopic, rememberPreference, rememberFact, rememberEmotion, rememberSchedule, extractReminders, toast]);

  return {
    memory,
    rememberTopic,
    rememberPreference,
    rememberFact,
    rememberEmotion,
    rememberSchedule,
    getTopInterests,
    getRecentEmotions,
    getUpcomingEvents,
    getMemorySummary,
    learnFromConversation,
    extractReminders
  };
}