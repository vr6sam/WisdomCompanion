import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { Reminder, InsertReminder } from "@shared/schema";
import { useToast } from "@/hooks/use-toast";

export function useReminders(userId: number) {
  const queryClient = useQueryClient();
  const { toast } = useToast();

  // Fetch reminders
  const { data: reminders = [], isLoading, error } = useQuery<Reminder[]>({
    queryKey: ['/api/reminders'],
    enabled: !!userId,
  });

  // Add a new reminder
  const addMutation = useMutation({
    mutationFn: async (reminder: Omit<InsertReminder, 'userId'>) => {
      const res = await apiRequest('POST', '/api/reminders', {
        ...reminder,
        userId
      });
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/reminders'] });
      toast({
        title: "Reminder created",
        description: "Your reminder has been successfully created.",
      });
    },
    onError: (error) => {
      console.error("Error creating reminder:", error);
      toast({
        title: "Error",
        description: "Failed to create reminder. Please try again.",
        variant: "destructive",
      });
    }
  });

  // Update an existing reminder
  const updateMutation = useMutation({
    mutationFn: async ({ id, reminder }: { id: number, reminder: Partial<InsertReminder> }) => {
      const res = await apiRequest('PUT', `/api/reminders/${id}`, reminder);
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/reminders'] });
      toast({
        title: "Reminder updated",
        description: "Your reminder has been successfully updated.",
      });
    },
    onError: (error) => {
      console.error("Error updating reminder:", error);
      toast({
        title: "Error",
        description: "Failed to update reminder. Please try again.",
        variant: "destructive",
      });
    }
  });

  // Delete a reminder
  const deleteMutation = useMutation({
    mutationFn: async (id: number) => {
      await apiRequest('DELETE', `/api/reminders/${id}`);
      return id;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/reminders'] });
      toast({
        title: "Reminder deleted",
        description: "Your reminder has been successfully deleted.",
      });
    },
    onError: (error) => {
      console.error("Error deleting reminder:", error);
      toast({
        title: "Error",
        description: "Failed to delete reminder. Please try again.",
        variant: "destructive",
      });
    }
  });

  // Add a reminder
  const addReminder = async (reminder: Omit<InsertReminder, 'userId'>) => {
    await addMutation.mutateAsync(reminder);
  };

  // Update a reminder
  const updateReminder = async (id: number, reminder: Partial<InsertReminder>) => {
    await updateMutation.mutateAsync({ id, reminder });
  };

  // Delete a reminder
  const deleteReminder = async (id: number) => {
    await deleteMutation.mutateAsync(id);
  };

  return {
    reminders,
    isLoading,
    error,
    addReminder,
    updateReminder,
    deleteReminder,
    isAdding: addMutation.isPending,
    isUpdating: updateMutation.isPending,
    isDeleting: deleteMutation.isPending
  };
}
