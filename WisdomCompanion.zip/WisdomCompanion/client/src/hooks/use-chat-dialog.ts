import { useState, useCallback, useEffect, useRef } from 'react';
import { useToast } from '@/hooks/use-toast';
import { analyzeTextEmotion, createTypingDelay, extractReminder } from '@/lib/utils';
import { generateResponse as openAIGenerateResponse, analyzeText as openAIAnalyzeText } from '@/lib/openai';
import { multiAI } from '@/lib/multiAI';
import { useConversationMemory } from './use-conversation-memory';

interface Message {
  id: string;
  content: string;
  role: 'user' | 'assistant';
  timestamp: Date;
}

interface ChatDialogOptions {
  initialMessages?: Message[];
  personalityTraits?: {
    wit?: number;
    thoughtfulness?: number;
    empathy?: number;
  };
  typingSpeedFactor?: number; // 1 = normal, <1 = faster, >1 = slower
}

export function useChatDialog(options: ChatDialogOptions = {}) {
  const [messages, setMessages] = useState<Message[]>(options.initialMessages || []);
  const [isTyping, setIsTyping] = useState(false);
  const [typingComplexity, setTypingComplexity] = useState<'simple' | 'moderate' | 'complex'>('moderate');
  const [currentEmotion, setCurrentEmotion] = useState<string>('neutral');
  const [emotionIntensity, setEmotionIntensity] = useState<number>(0.5);
  const [currentIntent, setCurrentIntent] = useState<string | null>(null);
  const [conversationTopics, setConversationTopics] = useState<string[]>([]);
  
  const { toast } = useToast();
  const memory = useConversationMemory();
  const typingTimeoutRef = useRef<NodeJS.Timeout | null>(null);
  
  // Helper to generate a unique ID
  const generateId = () => Math.random().toString(36).substring(2, 11);
  
  // Format messages for API calls
  const formatMessagesForAPI = useCallback(() => {
    return messages.map(msg => ({
      role: msg.role,
      content: msg.content
    }));
  }, [messages]);
  
  // Determine message complexity based on text length and content
  const determineMessageComplexity = useCallback((text: string): 'simple' | 'moderate' | 'complex' => {
    // Check for question marks
    const questionCount = (text.match(/\?/g) || []).length;
    
    // Check for complex words/phrases
    const complexTerms = ['explain', 'analyze', 'compare', 'relationship', 'difference', 'synthesize', 'evaluate', 'describe'];
    const hasComplexTerms = complexTerms.some(term => text.toLowerCase().includes(term));
    
    // Simple length-based complexity
    if (text.length < 20) return 'simple';
    if (text.length > 100 || questionCount > 1 || hasComplexTerms) return 'complex';
    return 'moderate';
  }, []);
  
  // Create a realistic typing delay based on message length and complexity
  const createRealisticDelay = useCallback((text: string, complexity: 'simple' | 'moderate' | 'complex') => {
    const baseDelay = {
      simple: 800,
      moderate: 2000, 
      complex: 4000
    }[complexity];
    
    // Add randomness (±20%)
    const randomFactor = 0.8 + (Math.random() * 0.4);
    
    // Adjust for message length
    const lengthFactor = Math.min(2, 1 + (text.length / 500));
    
    // Apply user speed preference
    const userSpeedFactor = options.typingSpeedFactor || 1;
    
    return baseDelay * randomFactor * lengthFactor * userSpeedFactor;
  }, [options.typingSpeedFactor]);
  
  // Add a new user message
  const addUserMessage = useCallback(async (content: string) => {
    if (!content.trim()) return;
    
    // Create and add the user message
    const userMessage: Message = {
      id: generateId(),
      content,
      role: 'user',
      timestamp: new Date()
    };
    
    setMessages(prev => [...prev, userMessage]);
    
    // Analyze the message for emotion and intent
    const emotionAnalysis = analyzeTextEmotion(content);
    setCurrentEmotion(emotionAnalysis.primaryEmotion);
    setEmotionIntensity(emotionAnalysis.intensity);
    
    // Remember the emotion in conversation memory
    memory.rememberEmotion(
      emotionAnalysis.primaryEmotion, 
      emotionAnalysis.intensity
    );
    
    try {
      // Deeper analysis for longer/more complex messages
      if (content.length > 50) {
        const analysisText = await multiAI.generateResponse(
          content,
          "Analyze this message and extract: 1) The user's intent 2) Main topics mentioned. Respond with JSON: {intent: string, topics: string[]}"
        );
        
        try {
          // Try to parse the response as JSON
          const detailedAnalysis = JSON.parse(analysisText);
          
          if (detailedAnalysis.intent) {
            setCurrentIntent(detailedAnalysis.intent);
          }
          
          if (detailedAnalysis.topics && detailedAnalysis.topics.length > 0) {
            setConversationTopics(detailedAnalysis.topics);
            // Remember topics in memory
            detailedAnalysis.topics.forEach((topic: string) => {
              memory.rememberTopic(topic);
            });
          }
        } catch (e) {
          console.error('Error parsing analysis:', e);
        }
      }
      
      // Extract possible reminders from the text
      const reminderInfo = extractReminder(content);
      if (reminderInfo) {
        // Remember the reminder in memory
        if (reminderInfo.dateTime) {
          memory.rememberSchedule(
            reminderInfo.title,
            reminderInfo.dateTime,
            reminderInfo.priority === 'high' ? 0.9 : 
            reminderInfo.priority === 'medium' ? 0.7 : 0.5
          );
          
          // Notify user that we recognized their reminder
          toast({
            title: "Reminder noted",
            description: `I'll remind you about "${reminderInfo.title}" ${
              reminderInfo.dateTime ? 'on ' + reminderInfo.dateTime.toLocaleDateString() : ''
            }`
          });
        }
      }
      
      // Generate AI response
      await generateAIResponse();
      
    } catch (error) {
      console.error('Error in message processing:', error);
      toast({
        title: "Something went wrong",
        description: "I had trouble processing your message. Please try again.",
        variant: "destructive"
      });
    }
  }, [memory, toast]);
  
  // Generate an AI response
  const generateAIResponse = useCallback(async () => {
    setIsTyping(true);
    
    try {
      // Get the latest message to determine complexity
      const lastMessage = messages[messages.length - 1];
      if (!lastMessage) {
        setIsTyping(false);
        return;
      }
      
      // Set message complexity for typing indicator
      const complexity = determineMessageComplexity(lastMessage.content);
      setTypingComplexity(complexity);
      
      // Get formatted conversation history
      const formattedMessages = formatMessagesForAPI();
      
      // Get memory context
      const memoryContext = memory.getMemorySummary();
      
      // Prepare context for AI
      const contextForAI = {
        currentEmotion,
        emotionIntensity,
        currentIntent,
        conversationTopics,
        memory: memoryContext
      };
      
      // Generate response (with delay for realism)
      const messageLength = lastMessage.content.length;
      const typingDelay = createRealisticDelay(lastMessage.content, complexity);
      
      // Clear any existing typing timeout
      if (typingTimeoutRef.current) {
        clearTimeout(typingTimeoutRef.current);
      }
      
      // Set a timeout to simulate typing
      typingTimeoutRef.current = setTimeout(async () => {
        try {
          const aiResponseText = await multiAI.generateResponse(
            lastMessage.content,
            JSON.stringify(contextForAI)
          );
          
          // Create the AI message
          const aiMessage: Message = {
            id: generateId(),
            content: aiResponseText,
            role: 'assistant',
            timestamp: new Date()
          };
          
          // Add the message after the typing delay
          setMessages(prev => [...prev, aiMessage]);
          
          // Learn from this conversation exchange
          memory.learnFromConversation(lastMessage.content, aiResponseText);
          
        } catch (error) {
          console.error('Error generating AI response:', error);
          toast({
            title: "Couldn't generate a response",
            description: "I had trouble thinking of what to say. Please try again.",
            variant: "destructive"
          });
        } finally {
          setIsTyping(false);
          typingTimeoutRef.current = null;
        }
      }, typingDelay);
      
    } catch (error) {
      console.error('Error in generating AI response:', error);
      setIsTyping(false);
    }
  }, [
    messages, 
    determineMessageComplexity, 
    formatMessagesForAPI, 
    memory, 
    currentEmotion, 
    emotionIntensity, 
    currentIntent,
    conversationTopics,
    createRealisticDelay,
    toast
  ]);
  
  // Clean up any hanging timeouts on unmount
  useEffect(() => {
    return () => {
      if (typingTimeoutRef.current) {
        clearTimeout(typingTimeoutRef.current);
      }
    };
  }, []);
  
  return {
    messages,
    isTyping,
    typingComplexity,
    currentEmotion,
    emotionIntensity,
    currentIntent,
    conversationTopics,
    memoryContext: memory.getMemorySummary(),
    addUserMessage,
    clearMessages: () => setMessages([])
  };
}