import { useState } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { apiRequest, queryClient } from "@/lib/queryClient";
import type { EmergencyContact } from "@shared/schema";

export function useEmergencyContacts(userId: number) {
  const [isCreating, setIsCreating] = useState(false);
  const [isEditing, setIsEditing] = useState<number | null>(null);

  // Fetch emergency contacts
  const {
    data: contacts = [],
    isLoading,
    error,
  } = useQuery({
    queryKey: ["/api/emergency-contacts"],
    enabled: Boolean(userId),
  });

  // Create emergency contact
  const createContactMutation = useMutation({
    mutationFn: async (contactData: Omit<EmergencyContact, "id" | "userId">) => {
      setIsCreating(true);
      try {
        const newContact = await apiRequest("/api/emergency-contacts", {
          method: "POST",
          body: JSON.stringify(contactData),
        });
        return newContact;
      } finally {
        setIsCreating(false);
      }
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/emergency-contacts"] });
    },
  });

  // Update emergency contact
  const updateContactMutation = useMutation({
    mutationFn: async ({
      id,
      data,
    }: {
      id: number;
      data: Partial<Omit<EmergencyContact, "id" | "userId">>;
    }) => {
      setIsEditing(id);
      try {
        const updatedContact = await apiRequest(`/api/emergency-contacts/${id}`, {
          method: "PUT",
          body: JSON.stringify(data),
        });
        return updatedContact;
      } finally {
        setIsEditing(null);
      }
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/emergency-contacts"] });
    },
  });

  // Delete emergency contact
  const deleteContactMutation = useMutation({
    mutationFn: async (id: number) => {
      await apiRequest(`/api/emergency-contacts/${id}`, {
        method: "DELETE",
      });
      return id;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/emergency-contacts"] });
    },
  });

  // Set contact as default
  const setDefaultContactMutation = useMutation({
    mutationFn: async (id: number) => {
      const updatedContact = await apiRequest(`/api/emergency-contacts/${id}`, {
        method: "PUT",
        body: JSON.stringify({ isDefault: true }),
      });
      return updatedContact;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/emergency-contacts"] });
    },
  });

  const addContact = async (contact: Omit<EmergencyContact, "id" | "userId">) => {
    return createContactMutation.mutateAsync(contact);
  };

  const updateContact = async (id: number, data: Partial<Omit<EmergencyContact, "id" | "userId">>) => {
    return updateContactMutation.mutateAsync({ id, data });
  };

  const deleteContact = async (id: number) => {
    return deleteContactMutation.mutateAsync(id);
  };

  const setDefaultContact = async (id: number) => {
    return setDefaultContactMutation.mutateAsync(id);
  };

  return {
    contacts,
    isLoading: isLoading || isCreating || isEditing !== null,
    error,
    addContact,
    updateContact,
    deleteContact,
    setDefaultContact,
  };
}