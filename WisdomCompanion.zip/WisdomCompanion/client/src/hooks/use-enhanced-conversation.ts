import { useState, useCallback, useEffect } from 'react';
import { v4 as uuidv4 } from 'uuid';

// Define types for conversation
export interface Message {
  id: string;
  content: string;
  role: 'user' | 'assistant';
  timestamp: Date;
}

export type ConversationStage = 'greeting' | 'discussion' | 'clarification' | 'conclusion' | 'idle';

interface MemoryContext {
  topInterests: string[];
  recentEmotions: string[];
  upcomingEvents: string[];
  userPreferences: Record<string, any>;
}

interface ConversationContext {
  recentMessages: Message[];
  userEmotion?: string;
  environmentContext?: string;
  memoryContext?: MemoryContext;
}

interface DialogueOptions {
  responseStyle?: 'concise' | 'detailed' | 'empathetic';
  emotionalTone?: 'neutral' | 'positive' | 'enthusiastic' | 'concerned';
  formality?: 'casual' | 'professional' | 'friendly';
}

// Options for the enhanced conversation hook
interface EnhancedConversationOptions {
  initialMessages?: Message[];
  personalityTraits?: {
    wit?: number; // 0-10 scale, default 5
    thoughtfulness?: number; // 0-10 scale, default 5
    empathy?: number; // 0-10 scale, default 5
  };
  typingSpeedFactor?: number; // 1 = normal, <1 = faster, >1 = slower
  memoryDepth?: number; // Number of messages to keep in context
}

// The hook implementation
export function useEnhancedConversation(options: EnhancedConversationOptions = {}) {
  // Default options
  const {
    initialMessages = [],
    personalityTraits = { wit: 5, thoughtfulness: 5, empathy: 5 },
    typingSpeedFactor = 1,
    memoryDepth = 10
  } = options;

  // States
  const [messages, setMessages] = useState<Message[]>(initialMessages);
  const [isTyping, setIsTyping] = useState(false);
  const [conversationStage, setConversationStage] = useState<ConversationStage>('idle');
  const [userEmotion, setUserEmotion] = useState<string | undefined>(undefined);
  const [inMaintenanceMode, setInMaintenanceMode] = useState(false);
  const [memoryContext, setMemoryContext] = useState<MemoryContext | undefined>({
    topInterests: ['technology', 'well-being', 'productivity'],
    recentEmotions: ['neutral'],
    upcomingEvents: [],
    userPreferences: {}
  });
  
  // Build context for the conversation
  const buildConversationContext = useCallback((): ConversationContext => {
    return {
      recentMessages: messages.slice(-memoryDepth),
      userEmotion,
      memoryContext
    };
  }, [messages, userEmotion, memoryContext, memoryDepth]);
  
  // Build dialogue options based on user emotion and personality traits
  const buildDialogOptions = useCallback((): DialogueOptions => {
    const options: DialogueOptions = {
      responseStyle: 'detailed',
      emotionalTone: 'neutral',
      formality: 'friendly'
    };
    
    // Adjust based on user emotion
    if (userEmotion) {
      if (['sad', 'depressed', 'anxious'].includes(userEmotion)) {
        options.emotionalTone = 'concerned';
        options.responseStyle = 'empathetic';
      } else if (['happy', 'excited', 'joyful'].includes(userEmotion)) {
        options.emotionalTone = 'enthusiastic';
      }
    }
    
    // Adjust based on personality traits
    if (personalityTraits) {
      if (personalityTraits.empathy && personalityTraits.empathy > 7) {
        options.responseStyle = 'empathetic';
      } else if (personalityTraits.thoughtfulness && personalityTraits.thoughtfulness > 7) {
        options.responseStyle = 'detailed';
      }
    }
    
    return options;
  }, [userEmotion, personalityTraits]);
  
  // Mock response generation (in real implementation, this would call an AI service)
  const generateResponse = useCallback(
    async (context: ConversationContext, options: DialogueOptions): Promise<string> => {
      // Simulate network delay and thinking time
      await new Promise(resolve => setTimeout(resolve, 500 + Math.random() * 1000));
      
      // If no AI services are available, generate a fallback response
      if (inMaintenanceMode) {
        return "I'm currently running in limited mode. My responses are pre-programmed and I can't access my full capabilities. Would you like to try again later when my services are restored?";
      }
      
      // This is just a placeholder. In a real implementation, 
      // we would use actual AI services to generate responses
      const lastUserMessage = context.recentMessages
        .filter(m => m.role === 'user')
        .pop()?.content || '';
      
      if (lastUserMessage.toLowerCase().includes('hello') || lastUserMessage.toLowerCase().includes('hi')) {
        return "Hello! I'm your enhanced AI assistant. How can I help you today?";
      } else if (lastUserMessage.toLowerCase().includes('how are you')) {
        return "I'm functioning well, thank you for asking! How are you feeling today?";
      } else if (lastUserMessage.toLowerCase().includes('help')) {
        return "I'd be happy to help. I can assist with a variety of tasks, including answering questions, providing information, helping with decisions, or just chatting. What specifically would you like help with?";
      } else if (lastUserMessage.toLowerCase().includes('weather')) {
        return "I'm sorry, I don't have access to real-time weather data at the moment. Would you like me to help you with something else?";
      } else {
        return "I understand you're saying: \"" + lastUserMessage + "\". Could you tell me more about what you're looking for?";
      }
    },
    [inMaintenanceMode]
  );
  
  // Add a user message to the conversation
  const addUserMessage = useCallback(
    async (content: string) => {
      if (!content.trim()) return;
      
      // Create the message object
      const userMessage: Message = {
        id: uuidv4(),
        content: content.trim(),
        role: 'user',
        timestamp: new Date()
      };
      
      // Add it to the messages
      setMessages(prev => [...prev, userMessage]);
      
      // Update conversation stage
      if (messages.length === 0) {
        setConversationStage('greeting');
      } else {
        setConversationStage('discussion');
      }
      
      // Generate a response
      setIsTyping(true);
      
      try {
        // Build context and options
        const context = buildConversationContext();
        const options = buildDialogOptions();
        
        // Generate a response
        const responseContent = await generateResponse(context, options);
        
        // Add typing delay based on message length and typing speed factor
        const typingDelay = Math.min(
          2000,
          responseContent.length * 10 * typingSpeedFactor
        );
        
        // Simulate typing delay
        await new Promise(resolve => setTimeout(resolve, typingDelay));
        
        // Create assistant message
        const assistantMessage: Message = {
          id: uuidv4(),
          content: responseContent,
          role: 'assistant',
          timestamp: new Date()
        };
        
        // Add it to the messages
        setMessages(prev => [...prev, assistantMessage]);
        
        // Update conversation stage
        setConversationStage('idle');
      } catch (error) {
        console.error('Error generating response:', error);
        
        // Add error message
        const errorMessage: Message = {
          id: uuidv4(),
          content: "I'm sorry, I'm having trouble responding right now. Please try again later.",
          role: 'assistant',
          timestamp: new Date()
        };
        
        // Add it to the messages
        setMessages(prev => [...prev, errorMessage]);
        
        // Update conversation stage
        setConversationStage('idle');
        
        // Enter maintenance mode
        setInMaintenanceMode(true);
      } finally {
        setIsTyping(false);
      }
    },
    [
      messages, 
      buildConversationContext, 
      buildDialogOptions, 
      generateResponse, 
      typingSpeedFactor
    ]
  );
  
  // Update emotion detection from external source
  const updateUserEmotion = useCallback((emotion: string) => {
    setUserEmotion(emotion);
    
    // Update memory context with the new emotion
    setMemoryContext(prev => {
      if (!prev) return undefined;
      
      const recentEmotions = [...prev.recentEmotions];
      if (recentEmotions.length >= 5) {
        recentEmotions.shift(); // Remove oldest emotion
      }
      recentEmotions.push(emotion);
      
      return {
        ...prev,
        recentEmotions
      };
    });
  }, []);
  
  // Provide a way to clear the conversation
  const clearConversation = useCallback(() => {
    setMessages([]);
    setConversationStage('idle');
  }, []);
  
  // Check for AI service availability
  useEffect(() => {
    const checkAIServiceStatus = async () => {
      try {
        const response = await fetch('/api/ai-status');
        const data = await response.json();
        
        // If no providers are available, enter maintenance mode
        if (data && data.providers) {
          const anyAvailable = Object.values(data.providers).some(Boolean);
          setInMaintenanceMode(!anyAvailable);
        }
      } catch (error) {
        console.error('Error checking AI service status:', error);
        setInMaintenanceMode(true);
      }
    };
    
    checkAIServiceStatus();
    
    // Check status periodically
    const intervalId = setInterval(checkAIServiceStatus, 60000); // Every minute
    
    return () => {
      clearInterval(intervalId);
    };
  }, []);
  
  return {
    messages,
    isTyping,
    conversationStage,
    userEmotion,
    inMaintenanceMode,
    memoryContext,
    addUserMessage,
    updateUserEmotion,
    clearConversation
  };
}