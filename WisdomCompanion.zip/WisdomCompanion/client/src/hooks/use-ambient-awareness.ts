import { useState, useCallback, useRef, useEffect } from 'react';
import { useCamera } from '@/hooks/use-camera';
import { useEmotionDetection } from '@/hooks/use-emotion-detection';
import { useToast } from '@/hooks/use-toast';

// Types
interface AmbientAwarenessSettings {
  ambientEmotionDetection: boolean;
  ambientSoundDetection: boolean;
  environmentalAnalysis: boolean;
  idleResponses: boolean;
  proactiveReminders: boolean;
  autoWakeOnActivity: boolean;
}

// Default settings
const defaultSettings: AmbientAwarenessSettings = {
  ambientEmotionDetection: true,
  ambientSoundDetection: true,
  environmentalAnalysis: true,
  idleResponses: true,
  proactiveReminders: true,
  autoWakeOnActivity: true,
};

export function useAmbientAwareness() {
  // Core state
  const [isActive, setIsActive] = useState(false);
  const [autoMode, setAutoMode] = useState(false);
  const [settings, setSettings] = useState<AmbientAwarenessSettings>(defaultSettings);
  
  // Environment data
  const [detectedEmotion, setDetectedEmotion] = useState<string | null>(null);
  const [environmentContext, setEnvironmentContext] = useState<any>(null);
  const [idleTime, setIdleTime] = useState(0);
  const [lastActivity, setLastActivity] = useState(Date.now());
  
  // Dependencies
  const camera = useCamera();
  const emotionDetection = useEmotionDetection();
  const { toast } = useToast();
  
  // References
  const idleTimerRef = useRef<NodeJS.Timeout | null>(null);
  const environmentAnalysisTimerRef = useRef<NodeJS.Timeout | null>(null);
  const idleTimeoutMs = 60000; // 1 minute
  
  // Initialize ambient awareness
  const initialize = useCallback(async () => {
    if (isActive) return;
    
    try {
      // Start camera if emotion detection is enabled
      if (settings.ambientEmotionDetection && !camera.cameraEnabled) {
        await camera.toggleCamera();
      }
      
      // Start environment analysis timer
      if (settings.environmentalAnalysis) {
        analyzeEnvironment();
        environmentAnalysisTimerRef.current = setInterval(analyzeEnvironment, 30000); // every 30 seconds
      }
      
      // Start idle timer
      resetIdleTimer();
      
      setIsActive(true);
      
      toast({
        title: 'Ambient Awareness Activated',
        description: 'I\'ll keep track of your environment to provide better assistance.',
      });
      
    } catch (error) {
      console.error('Error initializing ambient awareness:', error);
      toast({
        title: 'Ambient Awareness Error',
        description: 'Could not initialize ambient awareness features.',
        variant: 'destructive'
      });
    }
  }, [isActive, settings, camera, toast]);
  
  // Shut down ambient awareness
  const shutdown = useCallback(() => {
    if (!isActive) return;
    
    // Stop camera if we started it
    if (camera.cameraEnabled && settings.ambientEmotionDetection) {
      camera.toggleCamera();
    }
    
    // Clear timers
    if (environmentAnalysisTimerRef.current) {
      clearInterval(environmentAnalysisTimerRef.current);
      environmentAnalysisTimerRef.current = null;
    }
    
    if (idleTimerRef.current) {
      clearInterval(idleTimerRef.current);
      idleTimerRef.current = null;
    }
    
    setIsActive(false);
    
    toast({
      title: 'Ambient Awareness Deactivated',
      description: 'Environmental monitoring has been turned off.',
    });
  }, [isActive, settings, camera, toast]);
  
  // Toggle ambient awareness
  const toggleAmbientAwareness = useCallback(() => {
    if (isActive) {
      shutdown();
    } else {
      initialize();
    }
  }, [isActive, initialize, shutdown]);
  
  // Toggle auto mode
  const toggleAutoMode = useCallback(() => {
    setAutoMode(prev => !prev);
    
    // If turning on auto mode, make sure ambient awareness is on
    if (!autoMode && !isActive) {
      initialize();
    }
    
    toast({
      title: autoMode ? 'Auto Mode Deactivated' : 'Auto Mode Activated',
      description: autoMode 
        ? 'I\'ll wait for your commands before responding.' 
        : 'I\'ll proactively respond to changes in your environment.',
    });
  }, [autoMode, isActive, initialize, toast]);
  
  // Update a single setting
  const updateSetting = useCallback((key: keyof AmbientAwarenessSettings, value: boolean) => {
    setSettings(prev => ({
      ...prev,
      [key]: value
    }));
    
    // If enabling a feature that requires ambient awareness, turn it on
    if (value && !isActive && 
        (key === 'ambientEmotionDetection' || 
         key === 'ambientSoundDetection' || 
         key === 'environmentalAnalysis')) {
      initialize();
    }
  }, [isActive, initialize]);
  
  // Reset the idle timer
  const resetIdleTimer = useCallback(() => {
    setIdleTime(0);
    setLastActivity(Date.now());
    
    if (idleTimerRef.current) {
      clearInterval(idleTimerRef.current);
    }
    
    idleTimerRef.current = setInterval(() => {
      setIdleTime(prev => prev + 1000);
    }, 1000);
  }, []);
  
  // Analyze the user's environment
  const analyzeEnvironment = useCallback(async () => {
    if (!isActive || !settings.environmentalAnalysis) return;
    
    try {
      // Capture image from camera
      if (camera.cameraEnabled) {
        const imageData = await camera.captureImage();
        
        if (imageData && settings.ambientEmotionDetection) {
          // Detect emotion from image
          const emotion = await emotionDetection.detectEmotion(imageData);
          setDetectedEmotion(emotion);
        }
        
        // Here we would do more environment analysis like:
        // - Room brightness detection
        // - Object recognition
        // - Activity detection
        // For now, just set some basic data
        setEnvironmentContext({
          time: new Date().toLocaleTimeString(),
          lightLevel: 'moderate',
          activity: idleTime > idleTimeoutMs ? 'idle' : 'active',
          detectedObjects: []
        });
      }
    } catch (error) {
      console.error('Error analyzing environment:', error);
    }
  }, [isActive, settings, camera, emotionDetection, idleTime, idleTimeoutMs]);
  
  // Process text from user input for emotional content, intent and context
  const processText = useCallback((text: string) => {
    if (!text || text.trim() === '') return;
    
    // Reset idle timer on user interaction
    resetIdleTimer();
    
    console.log('Processing text input:', text);
    
    // Simple emotion detection based on keywords
    if (settings.ambientEmotionDetection) {
      const lowercaseText = text.toLowerCase();
      const emotions = {
        happy: ['happy', 'glad', 'joy', 'excited', 'fantastic', 'great', 'wonderful', 'awesome'],
        sad: ['sad', 'unhappy', 'depressed', 'down', 'miserable', 'upset', 'disappointing'],
        angry: ['angry', 'mad', 'furious', 'annoyed', 'irritated', 'frustrated', 'upset'],
        anxious: ['anxious', 'worried', 'nervous', 'scared', 'afraid', 'stressed', 'frightened'],
        tired: ['tired', 'exhausted', 'sleepy', 'fatigued', 'drained'],
        neutral: ['ok', 'fine', 'alright', 'neutral', 'normal']
      };
      
      let detectedEmotion = null;
      let highestCount = 0;
      
      // Count emotion keywords and find the most prevalent
      for (const [emotion, keywords] of Object.entries(emotions)) {
        const count = keywords.filter(keyword => lowercaseText.includes(keyword)).length;
        if (count > highestCount) {
          highestCount = count;
          detectedEmotion = emotion;
        }
      }
      
      if (highestCount > 0) {
        setDetectedEmotion(detectedEmotion);
      }
    }
    
    // Intent detection - look for common requests and needs
    if (autoMode) {
      const lowercaseText = text.toLowerCase();
      
      // Define keyword groups for different intents
      const intents = {
        emergency_assistance: ['help', 'emergency', 'urgent', 'danger', 'hurt', 'pain', 'accident'],
        create_reminder: ['remind', 'remember', 'appointment', 'schedule', 'don\'t forget', 'calendar'],
        weather_inquiry: ['weather', 'temperature', 'forecast', 'rain', 'sunny', 'cold', 'hot'],
        time_inquiry: ['time', 'date', 'day', 'today', 'tomorrow', 'schedule'],
        navigation: ['directions', 'map', 'navigate', 'location', 'address', 'route'],
        search_request: ['search', 'find', 'look up', 'google', 'information', 'about']
      };
      
      // Check for each intent
      let detectedIntent = null;
      for (const [intent, keywords] of Object.entries(intents)) {
        if (keywords.some(keyword => lowercaseText.includes(keyword))) {
          detectedIntent = intent;
          break;
        }
      }
      
      if (detectedIntent) {
        setEnvironmentContext(prev => ({
          ...prev,
          detectedIntent,
          lastIntentDetectedAt: new Date()
        }));
      }
    }
  }, [resetIdleTimer, settings.ambientEmotionDetection, autoMode]);
  
  // Generate a proactive response based on environment and context
  const generateProactiveResponse = useCallback((): string | null => {
    if (!autoMode || !isActive) return null;
    
    // Only generate response if user has been idle for a while
    if (idleTime < idleTimeoutMs || !settings.idleResponses) return null;
    
    // Based on detected emotion, environment, and time, generate an appropriate message
    if (detectedEmotion) {
      if (detectedEmotion === 'happy') {
        return "You seem happy today! That's great to see.";
      } else if (detectedEmotion === 'sad') {
        return "I notice you might be feeling down. Is there anything I can help with?";
      } else if (detectedEmotion === 'tired') {
        return "You look a bit tired. Would you like me to suggest a quick energy-boosting activity?";
      }
    }
    
    // Default responses if no specific emotion detected
    const timeOfDay = new Date().getHours();
    if (timeOfDay < 12) {
      return "Good morning! I notice you've been quiet for a bit. Anything I can help you with today?";
    } else if (timeOfDay < 18) {
      return "Hope your afternoon is going well! Just checking in to see if you need anything.";
    } else {
      return "Evening already! Let me know if there's anything I can help you with before the day ends.";
    }
  }, [autoMode, isActive, idleTime, idleTimeoutMs, settings, detectedEmotion]);
  
  // Clean up on unmount
  useEffect(() => {
    return () => {
      if (environmentAnalysisTimerRef.current) {
        clearInterval(environmentAnalysisTimerRef.current);
      }
      
      if (idleTimerRef.current) {
        clearInterval(idleTimerRef.current);
      }
    };
  }, []);
  
  return {
    isActive,
    autoMode,
    settings,
    detectedEmotion,
    environmentContext,
    idleTime,
    lastActivity,
    initialize,
    shutdown,
    toggleAmbientAwareness,
    toggleAutoMode,
    updateSetting,
    resetIdleTimer,
    analyzeEnvironment,
    processText,
    generateProactiveResponse
  };
}