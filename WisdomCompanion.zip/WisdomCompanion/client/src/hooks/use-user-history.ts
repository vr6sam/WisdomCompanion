import { useState, useEffect, useCallback } from 'react';
import { apiRequest } from '@/lib/queryClient';
import { usePhoneIntegration } from './use-phone-integration';
import { useWebSearch } from './use-web-search';

// Types
export interface UserHistoryItem {
  type: 'search' | 'app' | 'website' | 'message' | 'reminder' | 'location';
  content: string;
  timestamp: Date;
  metadata?: Record<string, any>;
}

export interface UserPreference {
  category: string;
  subcategory?: string;
  value: string | number | boolean;
  confidence: number; // 0-1 scale
  lastUpdated: Date;
}

export interface UserPattern {
  type: 'temporal' | 'behavioral' | 'content' | 'location';
  description: string;
  frequency: number; // times per day/week
  examples: string[];
  confidence: number; // 0-1 scale
  lastUpdated: Date;
}

export interface UserIntent {
  intent: string;
  probability: number; // 0-1 scale
  evidenceStrength: number; // 0-10 scale
  suggestedActions: string[];
  relatedPatterns: string[];
}

export interface UserNeed {
  need: string;
  urgency: number; // 0-10 scale
  importance: number; // 0-10 scale
  lastDetected: Date;
  suggestedResponses: string[];
}

// Main hook for user history and pattern analysis
export function useUserHistory() {
  // State
  const [userHistory, setUserHistory] = useState<UserHistoryItem[]>([]);
  const [userPreferences, setUserPreferences] = useState<UserPreference[]>([]);
  const [userPatterns, setUserPatterns] = useState<UserPattern[]>([]);
  const [currentIntents, setCurrentIntents] = useState<UserIntent[]>([]);
  const [currentNeeds, setCurrentNeeds] = useState<UserNeed[]>([]);
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  
  // Dependencies
  const phoneIntegration = usePhoneIntegration();
  const webSearch = useWebSearch();
  
  // Fetch user history from server
  const fetchUserHistory = useCallback(async () => {
    setIsLoading(true);
    setError(null);
    
    try {
      const response = await apiRequest('/api/user-history');
      
      if (!response.ok) {
        throw new Error('Failed to fetch user history');
      }
      
      const data = await response.json();
      
      // Convert timestamp strings to Date objects
      const historyWithDates = data.history.map((item: any) => ({
        ...item,
        timestamp: new Date(item.timestamp)
      }));
      
      setUserHistory(historyWithDates);
      
      // Also update preferences and patterns if available
      if (data.preferences) {
        const preferencesWithDates = data.preferences.map((pref: any) => ({
          ...pref,
          lastUpdated: new Date(pref.lastUpdated)
        }));
        setUserPreferences(preferencesWithDates);
      }
      
      if (data.patterns) {
        const patternsWithDates = data.patterns.map((pattern: any) => ({
          ...pattern,
          lastUpdated: new Date(pattern.lastUpdated)
        }));
        setUserPatterns(patternsWithDates);
      }
    } catch (err) {
      console.error('Error fetching user history:', err);
      setError('Could not load user history. Please try again later.');
    } finally {
      setIsLoading(false);
    }
  }, []);
  
  // Record a new history item
  const recordHistoryItem = useCallback(async (item: Omit<UserHistoryItem, 'timestamp'>) => {
    try {
      const historyItem = {
        ...item,
        timestamp: new Date()
      };
      
      // Record locally first
      setUserHistory(prev => [historyItem, ...prev]);
      
      // Send to server
      await apiRequest('/api/user-history', {
        method: 'POST',
        body: JSON.stringify(historyItem)
      });
      
      // Trigger pattern analysis after recording new data
      analyzePatterns();
      
      return true;
    } catch (err) {
      console.error('Error recording history item:', err);
      return false;
    }
  }, []);
  
  // Analyze patterns in user history
  const analyzePatterns = useCallback(async () => {
    if (userHistory.length === 0) return;
    
    setIsLoading(true);
    
    try {
      // Build pattern analysis request with all available data
      const analysisData = {
        history: userHistory,
        phoneData: {
          apps: phoneIntegration.recentApps,
          browserHistory: phoneIntegration.browserHistory,
          usageStats: phoneIntegration.usageStats
        },
        currentContext: {
          time: new Date(),
          dayOfWeek: new Date().getDay(),
          timeOfDay: new Date().getHours()
        }
      };
      
      // Send data for server-side analysis
      const response = await apiRequest('/api/analyze-patterns', {
        method: 'POST',
        body: JSON.stringify(analysisData)
      });
      
      if (!response.ok) {
        throw new Error('Pattern analysis failed');
      }
      
      const results = await response.json();
      
      // Update patterns and preferences
      if (results.patterns) {
        const patternsWithDates = results.patterns.map((pattern: any) => ({
          ...pattern,
          lastUpdated: new Date(pattern.lastUpdated)
        }));
        setUserPatterns(patternsWithDates);
      }
      
      if (results.preferences) {
        const preferencesWithDates = results.preferences.map((pref: any) => ({
          ...pref,
          lastUpdated: new Date(pref.lastUpdated)
        }));
        setUserPreferences(preferencesWithDates);
      }
      
      // Update current intents and needs
      if (results.currentIntents) {
        setCurrentIntents(results.currentIntents);
      }
      
      if (results.currentNeeds) {
        const needsWithDates = results.currentNeeds.map((need: any) => ({
          ...need,
          lastDetected: new Date(need.lastDetected)
        }));
        setCurrentNeeds(needsWithDates);
      }
    } catch (err) {
      console.error('Error analyzing patterns:', err);
    } finally {
      setIsLoading(false);
    }
  }, [userHistory, phoneIntegration.recentApps, phoneIntegration.browserHistory, phoneIntegration.usageStats]);
  
  // Predict user's next likely actions
  const predictNextActions = useCallback(async (count: number = 3): Promise<string[]> => {
    if (userHistory.length === 0) return [];
    
    try {
      const response = await apiRequest('/api/predict-actions', {
        method: 'POST',
        body: JSON.stringify({
          currentTime: new Date(),
          currentIntents,
          userPatterns,
          recentHistory: userHistory.slice(0, 20)
        })
      });
      
      if (!response.ok) {
        throw new Error('Action prediction failed');
      }
      
      const result = await response.json();
      return result.predictedActions.slice(0, count);
    } catch (err) {
      console.error('Error predicting next actions:', err);
      return [];
    }
  }, [userHistory, currentIntents, userPatterns]);
  
  // Get the most likely current user intent
  const getMostLikelyIntent = useCallback((): UserIntent | null => {
    if (currentIntents.length === 0) return null;
    
    // Sort by probability and return the highest
    const sortedIntents = [...currentIntents].sort((a, b) => b.probability - a.probability);
    return sortedIntents[0];
  }, [currentIntents]);
  
  // Get the most urgent user need
  const getMostUrgentNeed = useCallback((): UserNeed | null => {
    if (currentNeeds.length === 0) return null;
    
    // Calculate priority score based on urgency and importance
    const withPriority = currentNeeds.map(need => ({
      ...need,
      priorityScore: need.urgency * need.importance
    }));
    
    // Sort by priority score and return the highest
    const sortedNeeds = withPriority.sort((a, b) => b.priorityScore - a.priorityScore);
    return sortedNeeds[0];
  }, [currentNeeds]);
  
  // Get user preference for a specific category
  const getUserPreference = useCallback((category: string, subcategory?: string): UserPreference | null => {
    const matchingPreferences = userPreferences.filter(pref => 
      pref.category === category && 
      (!subcategory || pref.subcategory === subcategory)
    );
    
    if (matchingPreferences.length === 0) return null;
    
    // Sort by confidence and return the highest
    const sortedPreferences = matchingPreferences.sort((a, b) => b.confidence - a.confidence);
    return sortedPreferences[0];
  }, [userPreferences]);
  
  // Generate personalized suggestion based on history and patterns
  const generateSuggestion = useCallback(async (): Promise<{
    suggestion: string;
    reasoning: string;
    confidence: number;
  }> => {
    try {
      // Get most likely intent and most urgent need
      const intent = getMostLikelyIntent();
      const need = getMostUrgentNeed();
      
      // Combine with relevant patterns and preferences
      const suggestionsData = {
        currentTime: new Date(),
        currentIntent: intent,
        currentNeed: need,
        relevantPatterns: userPatterns.slice(0, 5),
        keyPreferences: userPreferences.slice(0, 5),
        recentHistory: userHistory.slice(0, 10)
      };
      
      const response = await apiRequest('/api/generate-suggestion', {
        method: 'POST',
        body: JSON.stringify(suggestionsData)
      });
      
      if (!response.ok) {
        throw new Error('Failed to generate suggestion');
      }
      
      const result = await response.json();
      return result;
    } catch (err) {
      console.error('Error generating suggestion:', err);
      return {
        suggestion: 'I don\'t have enough information to make a suggestion right now.',
        reasoning: 'Not enough user history or patterns detected.',
        confidence: 0.1
      };
    }
  }, [userHistory, userPatterns, userPreferences, getMostLikelyIntent, getMostUrgentNeed]);
  
  // Initialize by loading data
  useEffect(() => {
    fetchUserHistory();
  }, [fetchUserHistory]);
  
  return {
    userHistory,
    userPreferences,
    userPatterns,
    currentIntents,
    currentNeeds,
    isLoading,
    error,
    fetchUserHistory,
    recordHistoryItem,
    analyzePatterns,
    predictNextActions,
    getMostLikelyIntent,
    getMostUrgentNeed,
    getUserPreference,
    generateSuggestion
  };
}