import { useState, useCallback } from 'react';
import { apiRequest } from '@/lib/queryClient';

export interface SearchResult {
  title: string;
  url: string;
  snippet: string;
  source: string;
  date?: string;
}

export interface WikipediaResult {
  title: string;
  extract: string;
  url: string;
}

export interface NewsResult {
  title: string;
  description: string;
  url: string;
  source: string;
  publishedAt: string;
  imageUrl?: string;
}

export interface WebSearchOptions {
  maxResults?: number;
  safeSearch?: boolean;
  timeRange?: 'day' | 'week' | 'month' | 'year' | 'all';
  region?: string;
}

export function useWebSearch() {
  const [isSearching, setIsSearching] = useState(false);
  const [searchResults, setSearchResults] = useState<SearchResult[]>([]);
  const [error, setError] = useState<string | null>(null);
  
  // General web search
  const search = useCallback(async (query: string, options: WebSearchOptions = {}) => {
    if (!query) return [];
    
    setIsSearching(true);
    setError(null);
    
    try {
      const response = await apiRequest('/api/search', {
        method: 'POST',
        body: JSON.stringify({ query, options })
      });
      
      if (!response.ok) {
        throw new Error('Search request failed');
      }
      
      const results: SearchResult[] = await response.json();
      setSearchResults(results);
      return results;
    } catch (err) {
      console.error('Error performing web search:', err);
      setError('Could not complete web search. Please check your internet connection.');
      return [];
    } finally {
      setIsSearching(false);
    }
  }, []);
  
  // Wikipedia specific search
  const searchWikipedia = useCallback(async (query: string): Promise<WikipediaResult | null> => {
    if (!query) return null;
    
    setIsSearching(true);
    setError(null);
    
    try {
      const response = await apiRequest('/api/search/wikipedia', {
        method: 'POST',
        body: JSON.stringify({ query })
      });
      
      if (!response.ok) {
        throw new Error('Wikipedia search failed');
      }
      
      const result: WikipediaResult = await response.json();
      return result;
    } catch (err) {
      console.error('Error searching Wikipedia:', err);
      setError('Could not retrieve Wikipedia information.');
      return null;
    } finally {
      setIsSearching(false);
    }
  }, []);
  
  // News search
  const searchNews = useCallback(async (query: string, count: number = 5): Promise<NewsResult[]> => {
    if (!query) return [];
    
    setIsSearching(true);
    setError(null);
    
    try {
      const response = await apiRequest('/api/search/news', {
        method: 'POST',
        body: JSON.stringify({ query, count })
      });
      
      if (!response.ok) {
        throw new Error('News search failed');
      }
      
      const results: NewsResult[] = await response.json();
      return results;
    } catch (err) {
      console.error('Error searching news:', err);
      setError('Could not retrieve news articles.');
      return [];
    } finally {
      setIsSearching(false);
    }
  }, []);
  
  // Direct API call to ChatGPT for information
  const askChatGPT = useCallback(async (question: string): Promise<string> => {
    if (!question) return '';
    
    setIsSearching(true);
    setError(null);
    
    try {
      const response = await apiRequest('/api/openai/chat', {
        method: 'POST',
        body: JSON.stringify({
          messages: [
            { role: 'system', content: 'You are an AI assistant that provides accurate, concise, and helpful information.' },
            { role: 'user', content: question }
          ]
        })
      });
      
      if (!response.ok) {
        throw new Error('ChatGPT query failed');
      }
      
      const result = await response.json();
      return result.text || '';
    } catch (err) {
      console.error('Error querying ChatGPT:', err);
      setError('Could not retrieve information from ChatGPT.');
      return '';
    } finally {
      setIsSearching(false);
    }
  }, []);
  
  // Get real-time weather information
  const getWeather = useCallback(async (location: string): Promise<any> => {
    if (!location) return null;
    
    setIsSearching(true);
    setError(null);
    
    try {
      const response = await apiRequest('/api/weather', {
        method: 'POST',
        body: JSON.stringify({ location })
      });
      
      if (!response.ok) {
        throw new Error('Weather data retrieval failed');
      }
      
      const weatherData = await response.json();
      return weatherData;
    } catch (err) {
      console.error('Error getting weather data:', err);
      setError('Could not retrieve weather information.');
      return null;
    } finally {
      setIsSearching(false);
    }
  }, []);
  
  // Research and summarize a topic
  const researchTopic = useCallback(async (topic: string): Promise<{
    summary: string;
    keyPoints: string[];
    sources: string[];
  }> => {
    if (!topic) return { summary: '', keyPoints: [], sources: [] };
    
    setIsSearching(true);
    setError(null);
    
    try {
      // First, perform a general web search for the topic
      const searchResults = await search(topic, { maxResults: 5 });
      
      // Then, get Wikipedia information
      const wikiResult = await searchWikipedia(topic);
      
      // Finally, get news results
      const newsResults = await searchNews(topic, 3);
      
      // Combine all results and ask ChatGPT to summarize
      const sources = [
        ...(searchResults.map(r => r.url) || []),
        ...(wikiResult ? [wikiResult.url] : []),
        ...(newsResults.map(n => n.url) || [])
      ];
      
      const context = `
        Search results: ${JSON.stringify(searchResults)}
        Wikipedia information: ${JSON.stringify(wikiResult)}
        News articles: ${JSON.stringify(newsResults)}
      `;
      
      const prompt = `Please research and summarize the topic "${topic}" based on the following information:\n\n${context}\n\nProvide a concise summary, 3-5 key points, and list relevant sources.`;
      
      const summaryResponse = await askChatGPT(prompt);
      
      // Parse the response to extract summary, key points, and sources
      // This is a simplified parsing logic, in reality we would use OpenAI's structured outputs
      const summaryMatch = summaryResponse.match(/Summary:(.*?)(?=Key Points:|$)/s);
      const keyPointsMatch = summaryResponse.match(/Key Points:(.*?)(?=Sources:|$)/s);
      const sourcesMatch = summaryResponse.match(/Sources:(.*?)$/s);
      
      return {
        summary: summaryMatch ? summaryMatch[1].trim() : 'No summary available',
        keyPoints: keyPointsMatch 
          ? keyPointsMatch[1].split('\n').map(p => p.replace(/^[•\-*]\s*/, '').trim()).filter(p => p)
          : [],
        sources: sourcesMatch 
          ? sourcesMatch[1].split('\n').map(s => s.replace(/^[•\-*]\s*/, '').trim()).filter(s => s)
          : sources
      };
    } catch (err) {
      console.error('Error researching topic:', err);
      setError('Could not complete research on the topic.');
      return { summary: '', keyPoints: [], sources: [] };
    } finally {
      setIsSearching(false);
    }
  }, [search, searchWikipedia, searchNews, askChatGPT]);
  
  return {
    isSearching,
    searchResults,
    error,
    search,
    searchWikipedia,
    searchNews,
    askChatGPT,
    getWeather,
    researchTopic
  };
}