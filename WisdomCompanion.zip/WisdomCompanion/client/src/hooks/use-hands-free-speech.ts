import { useState, useEffect, useCallback, useRef } from 'react';

type EmergencyKeywordCallback = (keyword: string, fullTranscript: string) => void;

interface SpeechRecognitionOptions {
  continuous?: boolean;
  autoRestart?: boolean;
  onEmergencyKeywordDetected?: EmergencyKeywordCallback;
  enableWakeWord?: boolean;
}

export function useHandsFreeSpeech(options: SpeechRecognitionOptions = {}) {
  const {
    continuous = true,
    autoRestart = true,
    onEmergencyKeywordDetected,
    enableWakeWord = true
  } = options;
  
  const [isListening, setIsListening] = useState(false);
  const [transcript, setTranscript] = useState("");
  const [recognition, setRecognition] = useState<any>(null);
  const [error, setError] = useState<string | null>(null);
  const [wakeWordDetected, setWakeWordDetected] = useState(false);
  
  // Track if we're in passive listening mode (for wake word detection)
  const isPassiveListeningRef = useRef(false);
  
  // Reference to the latest transcript for use in callbacks
  const latestTranscriptRef = useRef("");
  
  // Check if browser supports speech recognition
  const hasRecognitionSupport = 'webkitSpeechRecognition' in window || 'SpeechRecognition' in window;
  
  // Initialize speech recognition
  useEffect(() => {
    if (!hasRecognitionSupport) return;
    
    // @ts-ignore - TypeScript doesn't have types for webkitSpeechRecognition
    const SpeechRecognition = window.SpeechRecognition || window.webkitSpeechRecognition;
    const recognitionInstance = new SpeechRecognition();
    
    recognitionInstance.continuous = continuous;
    recognitionInstance.interimResults = true;
    recognitionInstance.lang = 'en-US';
    
    // To prevent overlapping recognitions
    let isRecognitionRunning = false;
    let isRestarting = false;
    
    // For better transcript processing
    let finalTranscript = '';
    let lastProcessedIndex = 0;
    
    recognitionInstance.onresult = (event: any) => {
      const results = event.results;
      
      // Process new results only
      for (let i = lastProcessedIndex; i < results.length; i++) {
        const result = results[i];
        
        if (result.isFinal) {
          // Use final result for accuracy
          finalTranscript = result[0].transcript.trim();
          lastProcessedIndex = i + 1;
          
          if (finalTranscript.length > 1) {
            console.log("Hands-free speech captured:", finalTranscript);
            latestTranscriptRef.current = finalTranscript;
            setTranscript(finalTranscript);
            
            // Process wake words in passive mode
            if (isPassiveListeningRef.current && enableWakeWord) {
              processWakeWords(finalTranscript);
            }
            
            // Reset for next segment
            finalTranscript = '';
          }
        }
      }
    };
    
    // Safe start function to prevent errors
    const safeStart = (passive = false) => {
      if (!isRecognitionRunning && !isRestarting) {
        isRestarting = true;
        
        try {
          recognitionInstance.start();
          isRecognitionRunning = true;
          setIsListening(true);
          setError(null);
          isPassiveListeningRef.current = passive;
          console.log(passive ? 'Passive listening started' : 'Active listening started');
        } catch (err) {
          console.error('Error starting speech recognition:', err);
        } finally {
          isRestarting = false;
        }
      } else {
        console.log('Recognition already running, skipping start');
      }
    };
    
    recognitionInstance.onstart = () => {
      isRecognitionRunning = true;
      setIsListening(true);
    };
    
    recognitionInstance.onerror = (event: any) => {
      console.error('Speech recognition error:', event.error);
      setError(event.error);
      setIsListening(false);
      isRecognitionRunning = false;
      
      // Auto-restart if needed (except for permission denials)
      if (autoRestart && event.error !== 'not-allowed' && event.error !== 'service-not-allowed') {
        setTimeout(() => {
          if (isPassiveListeningRef.current) {
            safeStart(true);
          }
        }, 1000);
      }
    };
    
    recognitionInstance.onend = () => {
      console.log('Speech recognition ended');
      setIsListening(false);
      isRecognitionRunning = false;
      
      // Auto-restart if in passive mode
      if (autoRestart && isPassiveListeningRef.current) {
        setTimeout(() => safeStart(true), 500);
      }
    };
    
    setRecognition(recognitionInstance);
    
    // Start passive listening automatically if wake word is enabled
    if (enableWakeWord) {
      startPassiveListening();
    }
    
    return () => {
      if (recognitionInstance) {
        recognitionInstance.stop();
      }
      isPassiveListeningRef.current = false;
    };
  }, [hasRecognitionSupport, continuous, autoRestart, enableWakeWord]);
  
  // Process transcript for wake words
  const processWakeWords = useCallback((transcript: string) => {
    if (!transcript) return;
    
    const lowercaseText = transcript.toLowerCase();
    
    // Check for wake words
    const wakeWords = [
      'hey assistant', 'hello assistant', 'assistant', 
      'hey ai', 'hello ai', 'ai', 
      'hey computer', 'computer',
      'wake up', 'hey there'
    ];
    
    const foundWakeWord = wakeWords.some(word => lowercaseText.includes(word));
    
    if (foundWakeWord && !wakeWordDetected) {
      console.log("Wake word detected:", lowercaseText);
      setWakeWordDetected(true);
      
      // Switch to active listening
      isPassiveListeningRef.current = false;
      
      // Reset recognition to get a clean transcript
      if (recognition) {
        recognition.stop();
        setTimeout(() => startListening(), 300);
      }
    }
  }, [recognition, wakeWordDetected]);
  
  // Detect emergency keywords
  useEffect(() => {
    if (transcript) {
      const lowercaseText = transcript.toLowerCase();
      
      // Check for emergency keywords
      const emergencyKeywords = ['help', 'emergency', 'urgent', 'danger', 'accident', 'hurt', 'pain'];
      const foundKeyword = emergencyKeywords.find(keyword => lowercaseText.includes(keyword));
      
      if (foundKeyword && onEmergencyKeywordDetected) {
        onEmergencyKeywordDetected(foundKeyword, transcript);
      }
    }
  }, [transcript, onEmergencyKeywordDetected]);
  
  // Start passive listening for wake words
  const startPassiveListening = useCallback(() => {
    if (!recognition || !hasRecognitionSupport) return;
    
    try {
      isPassiveListeningRef.current = true;
      recognition.start();
      setIsListening(true);
      setError(null);
    } catch (err) {
      console.error('Error starting passive listening:', err);
      isPassiveListeningRef.current = false;
    }
  }, [recognition, hasRecognitionSupport]);
  
  // Start active listening (after wake word or manual trigger)
  const startListening = useCallback(() => {
    if (!recognition || !hasRecognitionSupport) return;
    
    try {
      isPassiveListeningRef.current = false;
      recognition.start();
      setIsListening(true);
      setError(null);
      setTranscript("");
    } catch (err) {
      console.error('Error starting speech recognition:', err);
      setError('Failed to start speech recognition');
    }
  }, [recognition, hasRecognitionSupport]);
  
  // Stop listening
  const stopListening = useCallback(() => {
    if (!recognition) return;
    
    try {
      recognition.stop();
      setIsListening(false);
      isPassiveListeningRef.current = false;
      setWakeWordDetected(false);
    } catch (err) {
      console.error('Error stopping speech recognition:', err);
    }
  }, [recognition]);
  
  // Reset wake word detection
  const resetWakeWordDetection = useCallback(() => {
    setWakeWordDetected(false);
    
    // Restart passive listening if wake word is enabled
    if (enableWakeWord && !isPassiveListeningRef.current) {
      startPassiveListening();
    }
  }, [enableWakeWord, startPassiveListening]);
  
  return {
    isListening,
    transcript,
    startListening,
    stopListening,
    hasRecognitionSupport,
    error,
    wakeWordDetected,
    resetWakeWordDetection,
    startPassiveListening
  };
}