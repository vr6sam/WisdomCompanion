import { useState, useCallback } from 'react';
import { apiRequest } from '@/lib/queryClient';

export interface EnvironmentContext {
  lighting: string;
  objects: string[];
  scene: string;
  peopleCount: number;
  isBusy: boolean;
  isOutdoors: boolean;
  hazards: string[];
  lastUpdated: Date;
}

export interface EnvironmentAnalysisOptions {
  /**
   * Automatically analyze at set intervals
   */
  autoAnalyze?: boolean;
  
  /**
   * Seconds between auto analyses
   */
  interval?: number;
  
  /**
   * Only analyze when there's significant visual change
   */
  onlyOnChange?: boolean;
  
  /**
   * Threshold for visual change detection (0-1)
   */
  changeThreshold?: number;
}

/**
 * Hook to analyze the environment through camera input
 */
export function useEnvironmentAnalysis(options: EnvironmentAnalysisOptions = {}) {
  const [environmentContext, setEnvironmentContext] = useState<EnvironmentContext>({
    lighting: 'unknown',
    objects: [],
    scene: 'unknown',
    peopleCount: 0,
    isBusy: false,
    isOutdoors: false,
    hazards: [],
    lastUpdated: new Date()
  });
  
  const [isAnalyzing, setIsAnalyzing] = useState(false);
  const [error, setError] = useState<string | null>(null);
  
  // Analyze environment using camera image
  const analyzeFromImage = useCallback(async (imageBase64: string): Promise<EnvironmentContext> => {
    try {
      setIsAnalyzing(true);
      setError(null);
      
      // Call the backend API
      const response = await apiRequest('/api/vision/environment', {
        method: 'POST',
        body: JSON.stringify({ image: imageBase64 })
      });
      
      // Check for API errors
      if (!response.ok) {
        const errorData = await response.json();
        throw new Error(errorData.error || 'Failed to analyze environment');
      }
      
      // Get the environmental data
      const environmentData = await response.json();
      
      // Create environment context from analysis
      const newContext: EnvironmentContext = {
        lighting: environmentData.lighting || 'unknown',
        objects: environmentData.objects || [],
        scene: environmentData.scene || 'unknown',
        peopleCount: environmentData.peopleCount || 0,
        isBusy: environmentData.isBusy || false, 
        isOutdoors: environmentData.isOutdoors || false,
        hazards: environmentData.hazards || [],
        lastUpdated: new Date()
      };
      
      // Update state
      setEnvironmentContext(newContext);
      setIsAnalyzing(false);
      
      return newContext;
    } catch (error) {
      const errorMessage = error instanceof Error ? error.message : 'Unknown error';
      setError(errorMessage);
      setIsAnalyzing(false);
      
      // Return current context on error
      return environmentContext;
    }
  }, [environmentContext]);
  
  /**
   * Analyze for safety risks in the environment
   */
  const analyzeSafety = useCallback(async (imageBase64: string): Promise<string[]> => {
    try {
      // Custom analysis specifically for safety concerns
      const prompt = `
        Analyze this environment for safety concerns or hazards.
        Focus only on potential dangers, risks, or hazardous conditions.
        Respond with a JSON array of strings describing each hazard found.
        If no hazards are found, respond with an empty array.
        Examples of hazards include trip hazards, sharp objects, fire risks, etc.
      `;
      
      const response = await apiRequest('/api/vision/describe', {
        method: 'POST',
        body: JSON.stringify({ 
          image: imageBase64,
          prompt
        })
      });
      
      if (!response.ok) {
        const errorData = await response.json();
        throw new Error(errorData.error || 'Failed to analyze safety');
      }
      
      const data = await response.json();
      
      // Try to parse the response as JSON
      try {
        const hazards = JSON.parse(data.description);
        return Array.isArray(hazards) ? hazards : [];
      } catch (error) {
        // If it's not valid JSON, try to extract hazards from text
        const hazardMatches = data.description.match(/[•\-\*]\s*([\w\s]+)|\d+\.\s*([\w\s]+)/g);
        if (hazardMatches) {
          return hazardMatches
            .map((item: string) => item.replace(/[•\-\*]\s*|\d+\.\s*/, '').trim())
            .filter((item: string) => item.length > 0);
        }
        
        return [];
      }
    } catch (error) {
      console.error('Error analyzing safety:', error);
      return [];
    }
  }, []);
  
  /**
   * Check if a person is present in the environment
   */
  const detectPersonPresence = useCallback(async (imageBase64: string): Promise<boolean> => {
    try {
      const prompt = 'Is there a person visible in this image? Answer only with "yes" or "no".';
      
      const response = await apiRequest('/api/vision/describe', {
        method: 'POST',
        body: JSON.stringify({ 
          image: imageBase64,
          prompt
        })
      });
      
      if (!response.ok) {
        throw new Error('Failed to detect person presence');
      }
      
      const data = await response.json();
      
      // Check if description contains "yes"
      return data.description.toLowerCase().includes('yes');
    } catch (error) {
      console.error('Error detecting person presence:', error);
      return false;
    }
  }, []);
  
  return {
    environmentContext,
    isAnalyzing,
    error,
    analyzeFromImage,
    analyzeSafety,
    detectPersonPresence
  };
}