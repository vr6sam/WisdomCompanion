import { useState, useCallback, useRef, useEffect } from 'react';

export interface CameraOptions {
  width?: number;
  height?: number;
  facingMode?: 'user' | 'environment';
  autoStart?: boolean;
  captureInterval?: number;
  frameQuality?: number; // 0-1 scale, affects JPEG quality
}

export interface CameraState {
  isActive: boolean;
  isFrontCamera: boolean;
  hasPermission: boolean | null;
  error: string | null;
}

/**
 * Enhanced camera hook with support for continuous capture and image processing
 */
export function useCameraEnhanced(options: CameraOptions = {}) {
  // Default options
  const {
    width = 1280,
    height = 720,
    facingMode = 'user',
    autoStart = false,
    captureInterval = 0, // 0 means no automatic capture
    frameQuality = 0.8
  } = options;
  
  // Refs for DOM elements and timers
  const videoRef = useRef<HTMLVideoElement | null>(null);
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const streamRef = useRef<MediaStream | null>(null);
  const intervalRef = useRef<NodeJS.Timeout | null>(null);
  
  // State for camera status
  const [cameraState, setCameraState] = useState<CameraState>({
    isActive: false,
    isFrontCamera: facingMode === 'user',
    hasPermission: null,
    error: null
  });
  
  // Base64 image from latest capture
  const [latestImage, setLatestImage] = useState<string | null>(null);
  
  // Callback for automatic image processing
  const [processingCallback, setProcessingCallback] = useState<((imageBase64: string) => void) | null>(null);
  
  /**
   * Initialize the camera
   */
  const initCamera = useCallback(async () => {
    try {
      // Clear any previous error
      setCameraState(prev => ({ ...prev, error: null }));
      
      // Stop any existing stream
      if (streamRef.current) {
        streamRef.current.getTracks().forEach(track => track.stop());
        streamRef.current = null;
      }
      
      // Request camera access
      const stream = await navigator.mediaDevices.getUserMedia({
        video: {
          width: { ideal: width },
          height: { ideal: height },
          facingMode
        },
        audio: false
      });
      
      // Save the stream reference
      streamRef.current = stream;
      
      // If we have a video element, connect the stream
      if (videoRef.current) {
        videoRef.current.srcObject = stream;
        await videoRef.current.play();
      }
      
      // Setup canvas for capturing if we don't have one yet
      if (!canvasRef.current) {
        const canvas = document.createElement('canvas');
        canvas.width = width;
        canvas.height = height;
        canvasRef.current = canvas;
      }
      
      // Update state
      setCameraState(prev => ({ 
        ...prev, 
        isActive: true,
        hasPermission: true,
        isFrontCamera: facingMode === 'user'
      }));
      
      // Start automatic capture if requested
      if (captureInterval > 0) {
        startAutomaticCapture();
      }
      
      return true;
    } catch (error) {
      console.error('Camera initialization error:', error);
      
      // Determine if this is a permission error
      const errorMessage = error instanceof Error ? error.message : 'Unknown camera error';
      const isPermissionError = errorMessage.toLowerCase().includes('permission');
      
      setCameraState(prev => ({ 
        ...prev, 
        isActive: false,
        hasPermission: isPermissionError ? false : prev.hasPermission,
        error: errorMessage
      }));
      
      return false;
    }
  }, [width, height, facingMode, captureInterval]);
  
  /**
   * Start the camera
   */
  const startCamera = useCallback(async () => {
    return initCamera();
  }, [initCamera]);
  
  /**
   * Stop the camera
   */
  const stopCamera = useCallback(() => {
    // Stop any running interval
    if (intervalRef.current) {
      clearInterval(intervalRef.current);
      intervalRef.current = null;
    }
    
    // Stop all tracks in the stream
    if (streamRef.current) {
      streamRef.current.getTracks().forEach(track => track.stop());
      streamRef.current = null;
    }
    
    // Clear video source
    if (videoRef.current) {
      videoRef.current.srcObject = null;
    }
    
    // Update state
    setCameraState(prev => ({ ...prev, isActive: false }));
  }, []);
  
  /**
   * Toggle the camera on/off
   */
  const toggleCamera = useCallback(() => {
    if (cameraState.isActive) {
      stopCamera();
    } else {
      startCamera();
    }
  }, [cameraState.isActive, startCamera, stopCamera]);
  
  /**
   * Switch between front and back cameras
   */
  const switchCamera = useCallback(async () => {
    const newFacingMode = cameraState.isFrontCamera ? 'environment' : 'user';
    
    // Update options
    options.facingMode = newFacingMode;
    
    // Restart camera with new facing mode
    if (cameraState.isActive) {
      stopCamera();
      await initCamera();
    }
    
    setCameraState(prev => ({ ...prev, isFrontCamera: !prev.isFrontCamera }));
  }, [cameraState.isActive, cameraState.isFrontCamera, initCamera, options, stopCamera]);
  
  /**
   * Capture a single frame from the video
   */
  const captureFrame = useCallback((): string | null => {
    const video = videoRef.current;
    const canvas = canvasRef.current;
    
    if (!video || !canvas || !streamRef.current) {
      return null;
    }
    
    const context = canvas.getContext('2d');
    if (!context) {
      return null;
    }
    
    // Match canvas dimensions to video
    canvas.width = video.videoWidth;
    canvas.height = video.videoHeight;
    
    // Draw the current video frame to the canvas
    context.drawImage(video, 0, 0, canvas.width, canvas.height);
    
    // Convert to base64
    const base64Image = canvas.toDataURL('image/jpeg', frameQuality).split(',')[1];
    
    // Update latest image
    setLatestImage(base64Image);
    
    // If there's a processing callback, execute it
    if (processingCallback) {
      processingCallback(base64Image);
    }
    
    return base64Image;
  }, [frameQuality, processingCallback]);
  
  /**
   * Start automatic frame capture at the specified interval
   */
  const startAutomaticCapture = useCallback(() => {
    // Clear any existing interval
    if (intervalRef.current) {
      clearInterval(intervalRef.current);
    }
    
    // Set up a new interval
    intervalRef.current = setInterval(() => {
      captureFrame();
    }, captureInterval);
  }, [captureFrame, captureInterval]);
  
  /**
   * Stop automatic capture
   */
  const stopAutomaticCapture = useCallback(() => {
    if (intervalRef.current) {
      clearInterval(intervalRef.current);
      intervalRef.current = null;
    }
  }, []);
  
  /**
   * Set a callback function to process each captured frame
   */
  const setFrameProcessor = useCallback((callback: (imageBase64: string) => void) => {
    setProcessingCallback(() => callback);
  }, []);
  
  /**
   * Clear the frame processor
   */
  const clearFrameProcessor = useCallback(() => {
    setProcessingCallback(null);
  }, []);
  
  // Autostart camera if requested
  useEffect(() => {
    if (autoStart) {
      startCamera();
    }
    
    // Cleanup on unmount
    return () => {
      stopCamera();
    };
  }, [autoStart, startCamera, stopCamera]);
  
  return {
    // Refs
    videoRef,
    canvasRef,
    
    // State
    cameraState,
    latestImage,
    
    // Controls
    startCamera,
    stopCamera,
    toggleCamera,
    switchCamera,
    captureFrame,
    
    // Automatic capture
    startAutomaticCapture,
    stopAutomaticCapture,
    
    // Frame processing
    setFrameProcessor,
    clearFrameProcessor
  };
}