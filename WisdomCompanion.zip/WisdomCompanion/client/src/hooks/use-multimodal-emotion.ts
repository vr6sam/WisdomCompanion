import { useState, useEffect, useMemo } from 'react';
import { analyzeTextEmotion } from '@/lib/utils';
import { multiAI } from '@/lib/multiAI';
import * as faceapi from 'face-api.js';

// Emotion types
export type FacialEmotion = 'happy' | 'sad' | 'angry' | 'surprised' | 'disgusted' | 'fearful' | 'neutral' | 'unknown';
export type VoiceEmotion = 'excited' | 'calm' | 'anxious' | 'bored' | 'sad' | 'happy' | 'angry' | 'neutral' | 'unknown';
export type TextEmotion = 'joy' | 'sadness' | 'anger' | 'fear' | 'disgust' | 'surprise' | 'neutral' | 'unknown';

export interface EmotionAnalysis {
  facial: {
    primaryEmotion: FacialEmotion;
    confidence: number;
    allEmotions: Record<FacialEmotion, number>;
  };
  voice: {
    primaryEmotion: VoiceEmotion;
    confidence: number;
    allEmotions: Record<VoiceEmotion, number>;
  };
  text: {
    primaryEmotion: TextEmotion;
    intensity: number;
    allEmotions: Record<TextEmotion, number>;
  };
  combined: {
    primaryEmotion: string;
    intensity: number;
    confidence: number;
    conflictLevel: number; // 0-1 scale of how conflicting the emotions are across modalities
  };
}

// Default emotion analysis state
const defaultEmotionAnalysis: EmotionAnalysis = {
  facial: {
    primaryEmotion: 'unknown',
    confidence: 0,
    allEmotions: {
      happy: 0, sad: 0, angry: 0, surprised: 0, 
      disgusted: 0, fearful: 0, neutral: 0, unknown: 1
    }
  },
  voice: {
    primaryEmotion: 'unknown',
    confidence: 0,
    allEmotions: {
      excited: 0, calm: 0, anxious: 0, bored: 0, 
      sad: 0, happy: 0, angry: 0, neutral: 0, unknown: 1
    }
  },
  text: {
    primaryEmotion: 'unknown',
    intensity: 0,
    allEmotions: {
      joy: 0, sadness: 0, anger: 0, fear: 0, 
      disgust: 0, surprise: 0, neutral: 0, unknown: 1
    }
  },
  combined: {
    primaryEmotion: 'neutral',
    intensity: 0,
    confidence: 0,
    conflictLevel: 0
  }
};

// Emotion mapping between different modalities for normalization
const emotionMappings = {
  // Facial to normalized
  facial: {
    'happy': 'joy',
    'sad': 'sadness',
    'angry': 'anger',
    'surprised': 'surprise',
    'disgusted': 'disgust',
    'fearful': 'fear',
    'neutral': 'neutral',
    'unknown': 'unknown'
  },
  // Voice to normalized
  voice: {
    'excited': 'joy',
    'calm': 'neutral',
    'anxious': 'fear',
    'bored': 'neutral',
    'sad': 'sadness',
    'happy': 'joy',
    'angry': 'anger',
    'neutral': 'neutral',
    'unknown': 'unknown'
  },
  // Text to normalized
  text: {
    'joy': 'joy',
    'sadness': 'sadness',
    'anger': 'anger',
    'fear': 'fear',
    'disgust': 'disgust',
    'surprise': 'surprise',
    'neutral': 'neutral',
    'unknown': 'unknown'
  }
};

interface MultimodalEmotionOptions {
  includeFacial?: boolean;
  includeVoice?: boolean;
  includeText?: boolean;
  modalityWeights?: {
    facial: number;
    voice: number;
    text: number;
  };
}

export function useMultimodalEmotion(options: MultimodalEmotionOptions = {}) {
  const [emotionAnalysis, setEmotionAnalysis] = useState<EmotionAnalysis>(defaultEmotionAnalysis);
  const [faceApiLoaded, setFaceApiLoaded] = useState(false);
  const [faceApiError, setFaceApiError] = useState<Error | null>(null);
  
  const modalityWeights = useMemo(() => ({
    facial: options.modalityWeights?.facial ?? 0.4,
    voice: options.modalityWeights?.voice ?? 0.3,
    text: options.modalityWeights?.text ?? 0.3
  }), [options.modalityWeights]);
  
  const useFacial = options.includeFacial !== false;
  const useVoice = options.includeVoice !== false;
  const useText = options.includeText !== false;
  
  // Load Face-API models
  useEffect(() => {
    if (!useFacial) return;
    
    async function loadModels() {
      try {
        // Use absolute URLs to ensure consistent loading
        const modelPath = window.location.origin + '/models';
        console.log("Loading face-api models from:", modelPath);
        
        // Check if models are already loaded to avoid reloading
        if (!faceapi.nets.tinyFaceDetector.isLoaded) {
          await faceapi.nets.tinyFaceDetector.loadFromUri(modelPath);
        }
        if (!faceapi.nets.faceLandmark68Net.isLoaded) {
          await faceapi.nets.faceLandmark68Net.loadFromUri(modelPath);
        }
        if (!faceapi.nets.faceRecognitionNet.isLoaded) {
          await faceapi.nets.faceRecognitionNet.loadFromUri(modelPath);
        }
        if (!faceapi.nets.faceExpressionNet.isLoaded) {
          await faceapi.nets.faceExpressionNet.loadFromUri(modelPath);
        }
        
        console.log("Face-API models loaded successfully");
        setFaceApiLoaded(true);
      } catch (error) {
        console.error("Error loading face-api models:", error);
        setFaceApiError(error as Error);
      }
    }
    
    loadModels();
  }, [useFacial]);
  
  // Analyze facial emotion from image
  const analyzeFacialEmotion = async (
    imageData: HTMLImageElement | HTMLCanvasElement | HTMLVideoElement | ImageData
  ): Promise<{
    primaryEmotion: FacialEmotion,
    confidence: number,
    allEmotions: Record<FacialEmotion, number>
  }> => {
    if (!faceApiLoaded) {
      return {
        primaryEmotion: 'unknown',
        confidence: 0,
        allEmotions: defaultEmotionAnalysis.facial.allEmotions
      };
    }
    
    try {
      // Convert ImageData to a canvas if needed for compatibility
      let input: HTMLImageElement | HTMLCanvasElement | HTMLVideoElement;
      
      if (imageData instanceof ImageData) {
        const canvas = document.createElement('canvas');
        canvas.width = imageData.width;
        canvas.height = imageData.height;
        const ctx = canvas.getContext('2d');
        if (ctx) {
          ctx.putImageData(imageData, 0, 0);
          input = canvas;
        } else {
          throw new Error('Failed to create canvas context');
        }
      } else {
        input = imageData;
      }
      
      const detectionsWithExpressions = await faceapi
        .detectSingleFace(input, new faceapi.TinyFaceDetectorOptions())
        .withFaceExpressions();
      
      if (!detectionsWithExpressions) {
        return {
          primaryEmotion: 'unknown',
          confidence: 0,
          allEmotions: defaultEmotionAnalysis.facial.allEmotions
        };
      }
      
      const expressions = detectionsWithExpressions.expressions;
      
      // Convert faceapi expressions to our format
      const allEmotions: Record<FacialEmotion, number> = {
        happy: expressions.happy,
        sad: expressions.sad,
        angry: expressions.angry,
        surprised: expressions.surprised,
        disgusted: expressions.disgusted,
        fearful: expressions.fearful,
        neutral: expressions.neutral,
        unknown: 0
      };
      
      // Find the emotion with the highest score
      let maxEmotion: FacialEmotion = 'neutral';
      let maxScore = 0;
      
      Object.entries(allEmotions).forEach(([emotion, score]) => {
        if (score > maxScore) {
          maxScore = score;
          maxEmotion = emotion as FacialEmotion;
        }
      });
      
      return {
        primaryEmotion: maxEmotion,
        confidence: maxScore,
        allEmotions
      };
    } catch (error) {
      console.error("Error analyzing facial emotion:", error);
      return {
        primaryEmotion: 'unknown',
        confidence: 0,
        allEmotions: defaultEmotionAnalysis.facial.allEmotions
      };
    }
  };
  
  // Analyze voice emotion from audio data
  const analyzeVoiceEmotion = async (audioData: Float32Array, sampleRate: number): Promise<{
    primaryEmotion: VoiceEmotion,
    confidence: number,
    allEmotions: Record<VoiceEmotion, number>
  }> => {
    try {
      // Convert audio data to a format that can be sent to server
      // This is a simplified version, in reality you'd need to encode the audio
      // properly for transmission
      const base64Audio = "dummy-audio-data"; // Placeholder
      
      // In a real implementation, we'd send this to our multiAI service
      // For now, we'll simulate with a random emotion while APIs are down
      const emotions: VoiceEmotion[] = ['excited', 'calm', 'anxious', 'bored', 'sad', 'happy', 'angry', 'neutral'];
      const primaryEmotion = emotions[Math.floor(Math.random() * emotions.length)];
      const confidence = 0.5 + Math.random() * 0.5; // Between 0.5 and 1.0
      
      // Generate randomized emotion scores where the primary emotion has the highest score
      const allEmotions: Record<VoiceEmotion, number> = {
        excited: 0.1 + Math.random() * 0.2,
        calm: 0.1 + Math.random() * 0.2,
        anxious: 0.1 + Math.random() * 0.2,
        bored: 0.1 + Math.random() * 0.2,
        sad: 0.1 + Math.random() * 0.2,
        happy: 0.1 + Math.random() * 0.2,
        angry: 0.1 + Math.random() * 0.2,
        neutral: 0.1 + Math.random() * 0.2,
        unknown: 0.1
      };
      
      // Ensure primary emotion has highest score
      allEmotions[primaryEmotion] = confidence;
      
      return {
        primaryEmotion,
        confidence,
        allEmotions
      };
    } catch (error) {
      console.error("Error analyzing voice emotion:", error);
      return {
        primaryEmotion: 'unknown',
        confidence: 0,
        allEmotions: defaultEmotionAnalysis.voice.allEmotions
      };
    }
  };
  
  // Analyze text emotion from string
  const analyzeTextEmotionExtended = (text: string): {
    primaryEmotion: TextEmotion,
    intensity: number,
    allEmotions: Record<TextEmotion, number>
  } => {
    if (!text.trim()) {
      return {
        primaryEmotion: 'neutral',
        intensity: 0,
        allEmotions: defaultEmotionAnalysis.text.allEmotions
      };
    }
    
    try {
      // Use the existing text emotion analysis function
      const basicAnalysis = analyzeTextEmotion(text);
      
      // Convert to our extended format
      const primaryTextEmotion = mapBasicToTextEmotion(basicAnalysis.primaryEmotion);
      const intensity = basicAnalysis.intensity;
      
      // Generate other emotion scores where primary has highest
      const allEmotions: Record<TextEmotion, number> = {
        joy: 0.1 + Math.random() * 0.2,
        sadness: 0.1 + Math.random() * 0.2,
        anger: 0.1 + Math.random() * 0.2,
        fear: 0.1 + Math.random() * 0.2,
        disgust: 0.1 + Math.random() * 0.2,
        surprise: 0.1 + Math.random() * 0.2,
        neutral: 0.1 + Math.random() * 0.2,
        unknown: 0
      };
      
      // Ensure primary emotion has highest score
      allEmotions[primaryTextEmotion] = Math.max(0.6, intensity);
      
      return {
        primaryEmotion: primaryTextEmotion,
        intensity,
        allEmotions
      };
    } catch (error) {
      console.error("Error analyzing text emotion:", error);
      return {
        primaryEmotion: 'neutral',
        intensity: 0,
        allEmotions: defaultEmotionAnalysis.text.allEmotions
      };
    }
  };
  
  // Helper to map basic emotion to text emotion
  const mapBasicToTextEmotion = (basicEmotion: string): TextEmotion => {
    const mapping: Record<string, TextEmotion> = {
      'happy': 'joy',
      'sad': 'sadness',
      'angry': 'anger',
      'afraid': 'fear',
      'disgusted': 'disgust',
      'surprised': 'surprise',
      'neutral': 'neutral'
    };
    
    return mapping[basicEmotion.toLowerCase()] || 'neutral';
  };
  
  // Combine emotions from different modalities
  const combineEmotions = (
    facialEmotion: { primaryEmotion: FacialEmotion, confidence: number },
    voiceEmotion: { primaryEmotion: VoiceEmotion, confidence: number },
    textEmotion: { primaryEmotion: TextEmotion, intensity: number }
  ): {
    primaryEmotion: string,
    intensity: number,
    confidence: number,
    conflictLevel: number
  } => {
    // Normalize emotions to same scale
    const normalizedEmotions = {
      facial: emotionMappings.facial[facialEmotion.primaryEmotion] || 'unknown',
      voice: emotionMappings.voice[voiceEmotion.primaryEmotion] || 'unknown',
      text: emotionMappings.text[textEmotion.primaryEmotion] || 'unknown'
    };
    
    // Calculate weights based on confidence
    let weights = {
      facial: modalityWeights.facial * (useFacial ? facialEmotion.confidence : 0),
      voice: modalityWeights.voice * (useVoice ? voiceEmotion.confidence : 0),
      text: modalityWeights.text * (useText ? textEmotion.intensity : 0)
    };
    
    // Normalize weights
    const totalWeight = weights.facial + weights.voice + weights.text;
    if (totalWeight > 0) {
      weights = {
        facial: weights.facial / totalWeight,
        voice: weights.voice / totalWeight,
        text: weights.text / totalWeight
      };
    } else {
      // Default weights if all confidences are 0
      weights = {
        facial: useFacial ? 0.4 : 0,
        voice: useVoice ? 0.3 : 0,
        text: useText ? 0.3 : 0
      };
      
      // Re-normalize if some modalities are disabled
      const newTotal = weights.facial + weights.voice + weights.text;
      if (newTotal > 0) {
        weights = {
          facial: weights.facial / newTotal,
          voice: weights.voice / newTotal,
          text: weights.text / newTotal
        };
      }
    }
    
    // Count votes for each emotion
    const emotionVotes: Record<string, number> = {};
    
    if (useFacial && normalizedEmotions.facial !== 'unknown') {
      emotionVotes[normalizedEmotions.facial] = 
        (emotionVotes[normalizedEmotions.facial] || 0) + weights.facial;
    }
    
    if (useVoice && normalizedEmotions.voice !== 'unknown') {
      emotionVotes[normalizedEmotions.voice] = 
        (emotionVotes[normalizedEmotions.voice] || 0) + weights.voice;
    }
    
    if (useText && normalizedEmotions.text !== 'unknown') {
      emotionVotes[normalizedEmotions.text] = 
        (emotionVotes[normalizedEmotions.text] || 0) + weights.text;
    }
    
    // Find emotion with highest vote
    let primaryEmotion = 'neutral';
    let highestVote = 0;
    
    Object.entries(emotionVotes).forEach(([emotion, vote]) => {
      if (vote > highestVote) {
        highestVote = vote;
        primaryEmotion = emotion;
      }
    });
    
    // Calculate conflict level - how much disagreement is there?
    // If all emotions are the same, conflict is 0
    // If all emotions are different, conflict is high
    let conflictLevel = 0;
    const uniqueEmotions = new Set(
      [normalizedEmotions.facial, normalizedEmotions.voice, normalizedEmotions.text]
        .filter(e => e !== 'unknown')
    );
    
    if (uniqueEmotions.size > 1) {
      // Normalize to 0-1 scale
      conflictLevel = (uniqueEmotions.size - 1) / 2;
    }
    
    // Calculate overall confidence and intensity
    const emotionConfidence = highestVote;
    const emotionIntensity = (
      (useFacial ? facialEmotion.confidence : 0) * weights.facial +
      (useVoice ? voiceEmotion.confidence : 0) * weights.voice +
      (useText ? textEmotion.intensity : 0) * weights.text
    );
    
    return {
      primaryEmotion,
      intensity: emotionIntensity,
      confidence: emotionConfidence,
      conflictLevel
    };
  };
  
  // Main function to analyze emotions from all modalities
  const analyzeEmotions = async (
    faceImage?: ImageData | HTMLImageElement | HTMLCanvasElement | HTMLVideoElement,
    audioData?: { data: Float32Array, sampleRate: number },
    text?: string
  ): Promise<EmotionAnalysis> => {
    // Initialize with current analysis
    const newAnalysis = { ...emotionAnalysis };
    
    // Analyze facial emotion if provided
    if (useFacial && faceImage) {
      const facialResult = await analyzeFacialEmotion(faceImage);
      newAnalysis.facial = facialResult;
    }
    
    // Analyze voice emotion if provided
    if (useVoice && audioData) {
      const voiceResult = await analyzeVoiceEmotion(audioData.data, audioData.sampleRate);
      newAnalysis.voice = voiceResult;
    }
    
    // Analyze text emotion if provided
    if (useText && text) {
      const textResult = analyzeTextEmotionExtended(text);
      newAnalysis.text = textResult;
    }
    
    // Combine all modalities
    newAnalysis.combined = combineEmotions(
      newAnalysis.facial,
      newAnalysis.voice,
      newAnalysis.text
    );
    
    // Update state and return result
    setEmotionAnalysis(newAnalysis);
    return newAnalysis;
  };
  
  return {
    emotionAnalysis,
    analyzeEmotions,
    analyzeFacialEmotion,
    analyzeVoiceEmotion,
    analyzeTextEmotion: analyzeTextEmotionExtended,
    faceApiLoaded,
    faceApiError
  };
}