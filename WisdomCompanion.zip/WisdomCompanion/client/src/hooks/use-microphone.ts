import { useState, useCallback, useRef } from 'react';

export function useMicrophone() {
  const [isRecording, setIsRecording] = useState(false);
  const [recordedAudio, setRecordedAudio] = useState<string | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [permissionGranted, setPermissionGranted] = useState(false);
  
  const mediaRecorderRef = useRef<MediaRecorder | null>(null);
  const audioChunksRef = useRef<Blob[]>([]);
  
  // Check if microphone is available and request permission
  const requestMicrophonePermission = useCallback(async (): Promise<boolean> => {
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
      
      // Stop the stream immediately since we're just checking permission
      stream.getTracks().forEach(track => track.stop());
      
      setPermissionGranted(true);
      setError(null);
      return true;
    } catch (err) {
      console.error('Error accessing microphone:', err);
      setError('Microphone permission denied. Please allow microphone access.');
      setPermissionGranted(false);
      return false;
    }
  }, []);
  
  // Start recording audio
  const startRecording = useCallback(async () => {
    if (isRecording) return;
    
    // Reset any previous recordings
    audioChunksRef.current = [];
    setRecordedAudio(null);
    
    try {
      // Request permission if not already granted
      if (!permissionGranted) {
        const hasPermission = await requestMicrophonePermission();
        if (!hasPermission) return;
      }
      
      const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
      
      // Create media recorder
      const mediaRecorder = new MediaRecorder(stream);
      mediaRecorderRef.current = mediaRecorder;
      
      // Handle data available event
      mediaRecorder.ondataavailable = (event) => {
        if (event.data.size > 0) {
          audioChunksRef.current.push(event.data);
        }
      };
      
      // Handle recording stop
      mediaRecorder.onstop = async () => {
        const audioBlob = new Blob(audioChunksRef.current, { type: 'audio/wav' });
        
        // Convert blob to base64
        const reader = new FileReader();
        reader.readAsDataURL(audioBlob);
        reader.onloadend = () => {
          const base64data = reader.result as string;
          // Extract the base64 part without the data URL prefix
          const base64Audio = base64data.split(',')[1];
          setRecordedAudio(base64Audio);
        };
        
        // Clean up the stream
        stream.getTracks().forEach(track => track.stop());
        setIsRecording(false);
      };
      
      // Start recording
      mediaRecorder.start();
      setIsRecording(true);
      setError(null);
    } catch (err) {
      console.error('Error starting audio recording:', err);
      setError('Could not start recording. Please check your microphone permissions.');
      setIsRecording(false);
    }
  }, [isRecording, permissionGranted, requestMicrophonePermission]);
  
  // Stop recording
  const stopRecording = useCallback(() => {
    if (!isRecording || !mediaRecorderRef.current) return;
    
    try {
      mediaRecorderRef.current.stop();
      // Note: setIsRecording(false) is called in the onstop handler
    } catch (err) {
      console.error('Error stopping recording:', err);
      setError('Error stopping recording');
      setIsRecording(false);
    }
  }, [isRecording]);
  
  // Clear recorded audio
  const clearRecording = useCallback(() => {
    setRecordedAudio(null);
    audioChunksRef.current = [];
  }, []);
  
  // Return the current amplitude level (for visualization)
  const getCurrentAmplitude = useCallback(async (): Promise<number> => {
    if (!isRecording || !mediaRecorderRef.current) return 0;
    
    try {
      // This is a simplified version - real-time audio analysis would require
      // more sophisticated setup with AudioContext and analyzer nodes
      return Math.random(); // Placeholder for actual amplitude analysis
    } catch (err) {
      console.error('Error analyzing audio:', err);
      return 0;
    }
  }, [isRecording]);
  
  return {
    isRecording,
    recordedAudio,
    error,
    permissionGranted,
    startRecording,
    stopRecording,
    clearRecording,
    requestMicrophonePermission,
    getCurrentAmplitude
  };
}