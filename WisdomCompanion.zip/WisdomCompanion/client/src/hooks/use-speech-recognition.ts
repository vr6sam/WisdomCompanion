import { useState, useEffect, useCallback, useRef } from "react";

export function useSpeechRecognition() {
  const [isListening, setIsListening] = useState(false);
  const [transcript, setTranscript] = useState("");
  const [error, setError] = useState<string | null>(null);
  
  // Store recognition instance in a ref to maintain access across renders
  const recognitionRef = useRef<any>(null);
  
  // Use refs to track internal state for the recognition
  const isRunningRef = useRef(false);
  const isRestartingRef = useRef(false);
  const lastProcessedIndexRef = useRef(0);
  
  // Check if browser supports speech recognition
  const hasRecognitionSupport = 'webkitSpeechRecognition' in window || 'SpeechRecognition' in window;
  
  // Function to safely start recognition
  const safeStartRecognition = useCallback(() => {
    // Don't try to start if we don't have the recognition object
    if (!recognitionRef.current) {
      console.log('Recognition not initialized yet');
      return;
    }
    
    // Force reset the state if we're stuck
    if (isRestartingRef.current) {
      console.log('Recognition was stuck in restarting state, resetting');
      isRestartingRef.current = false;
    }
    
    // If already running, stop first to reset
    if (isRunningRef.current) {
      try {
        console.log('Recognition was already running, stopping first');
        recognitionRef.current.stop();
        isRunningRef.current = false;
        
        // Give a brief pause before starting again
        setTimeout(() => {
          startRecognitionAfterReset();
        }, 50);
        return;
      } catch (err) {
        console.error('Error stopping previous recognition:', err);
        // Continue with restart attempt anyway
      }
    }
    
    // Start fresh
    startRecognitionAfterReset();
  }, []);
  
  // Helper to start recognition after reset
  const startRecognitionAfterReset = useCallback(() => {
    if (!recognitionRef.current) return;
    
    isRestartingRef.current = true;
    
    try {
      recognitionRef.current.start();
      console.log('Speech recognition started successfully');
    } catch (err) {
      console.error('Error starting speech recognition:', err);
      setError('Failed to start speech recognition');
      isRestartingRef.current = false;
      isRunningRef.current = false;
      setIsListening(false);
    }
  }, []);
  
  // Initialize speech recognition
  useEffect(() => {
    if (!hasRecognitionSupport) {
      setError("Browser doesn't support speech recognition");
      return;
    }
    
    try {
      // @ts-ignore - TypeScript doesn't have types for webkitSpeechRecognition
      const SpeechRecognition = window.SpeechRecognition || window.webkitSpeechRecognition;
      const recognitionInstance = new SpeechRecognition();
      
      // Configure basic settings
      recognitionInstance.continuous = true;
      recognitionInstance.interimResults = false; // Only final results for more stability
      recognitionInstance.lang = 'en-US';
      
      // Handle results
      recognitionInstance.onresult = (event: any) => {
        try {
          // Get the latest final result
          for (let i = lastProcessedIndexRef.current; i < event.results.length; i++) {
            const result = event.results[i];
            
            if (result.isFinal) {
              const text = result[0].transcript.trim();
              lastProcessedIndexRef.current = i + 1;
              
              if (text.length > 0) {
                console.log("Speech recognition captured:", text);
                setTranscript(text);
              }
            }
          }
        } catch (err) {
          console.error("Error processing speech results:", err);
        }
      };
      
      // Handle start
      recognitionInstance.onstart = () => {
        console.log('Speech recognition started');
        isRunningRef.current = true;
        isRestartingRef.current = false;
        setIsListening(true);
      };
      
      // Handle errors
      recognitionInstance.onerror = (event: any) => {
        console.error('Speech recognition error:', event.error);
        setError(event.error);
        isRunningRef.current = false;
        setIsListening(false);
        
        // Auto-restart after non-critical errors
        if (event.error !== 'not-allowed' && event.error !== 'service-not-allowed') {
          setTimeout(() => {
            safeStartRecognition();
          }, 1000);
        }
      };
      
      // Handle end
      recognitionInstance.onend = () => {
        console.log('Speech recognition ended');
        isRunningRef.current = false;
        setIsListening(false);
        
        // Only auto-restart in specific circumstances
        // @ts-ignore - We add this property in the component
        if (window.shouldAutoRestart === true) {
          console.log('Auto-restarting speech recognition');
          setTimeout(() => {
            safeStartRecognition();
          }, 300);
        } else {
          console.log('Not auto-restarting speech recognition');
        }
      };
      
      // Store the instance
      recognitionRef.current = recognitionInstance;
    } catch (err) {
      console.error("Error initializing speech recognition:", err);
      setError("Failed to initialize speech recognition");
    }
    
    // Clean up on unmount
    return () => {
      try {
        if (recognitionRef.current) {
          recognitionRef.current.stop();
        }
      } catch (err) {
        console.error("Error cleaning up speech recognition:", err);
      }
    };
  }, [hasRecognitionSupport, safeStartRecognition]);
  
  // Start listening
  const startListening = useCallback(() => {
    // Clear any previous transcript
    setTranscript("");
    
    // Reset error state
    setError(null);
    
    // Start recognition safely
    safeStartRecognition();
  }, [safeStartRecognition]);
  
  // Stop listening
  const stopListening = useCallback(() => {
    if (!recognitionRef.current) return;
    
    try {
      recognitionRef.current.stop();
      isRunningRef.current = false;
      setIsListening(false);
    } catch (err) {
      console.error('Error stopping speech recognition:', err);
    }
  }, []);
  
  // Clear transcript
  const clearTranscript = useCallback(() => {
    setTranscript("");
  }, []);
  
  return {
    isListening,
    transcript,
    startListening,
    stopListening,
    clearTranscript,
    resetTranscript: clearTranscript, // Alias for compatibility
    hasRecognitionSupport,
    error
  };
}
