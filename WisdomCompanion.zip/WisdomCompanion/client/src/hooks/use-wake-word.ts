import { useState, useEffect, useCallback, useRef } from 'react';
import { useMicrophone } from './use-microphone';
import { transcribeAudio } from '@/lib/openai';

// Keywords and phrases to listen for
const HELP_PHRASES = [
  'help',
  'emergency',
  'i need',
  'i want',
  'assist',
  'urgent',
  'problem',
  'issue',
  'stuck',
  'trouble',
  'crisis',
  'danger',
  'medical',
  'health'
];

export function useWakeWord() {
  const [isListening, setIsListening] = useState(false);
  const [detectedKeywords, setDetectedKeywords] = useState<string[]>([]);
  const [detectedIntent, setDetectedIntent] = useState<string | null>(null);
  const [lastTranscript, setLastTranscript] = useState('');
  const [isProcessing, setIsProcessing] = useState(false);
  
  const { 
    isRecording, 
    startRecording, 
    stopRecording, 
    recordedAudio,
    clearRecording
  } = useMicrophone();
  
  const processingTimerRef = useRef<NodeJS.Timeout | null>(null);
  const continuousTimerRef = useRef<NodeJS.Timeout | null>(null);
  
  // Start continuous listening for wake words
  const startListening = useCallback(() => {
    if (isListening) return;
    
    setIsListening(true);
    startContinuousListening();
    
    console.log('Started listening for wake words and help phrases');
  }, [isListening]);
  
  // Stop listening for wake words
  const stopListening = useCallback(() => {
    if (!isListening) return;
    
    if (continuousTimerRef.current) {
      clearInterval(continuousTimerRef.current);
      continuousTimerRef.current = null;
    }
    
    if (isRecording) {
      stopRecording();
    }
    
    setIsListening(false);
    console.log('Stopped listening for wake words');
  }, [isListening, isRecording, stopRecording]);
  
  // Process recorded audio for intent recognition
  const processAudio = useCallback(async (audioData: string) => {
    if (!audioData || isProcessing) return;
    
    setIsProcessing(true);
    
    try {
      // Transcribe the audio to text
      const transcript = await transcribeAudio(audioData);
      
      if (transcript) {
        setLastTranscript(transcript);
        
        // Check for help phrases
        const foundKeywords: string[] = [];
        const lowercaseTranscript = transcript.toLowerCase();
        
        for (const phrase of HELP_PHRASES) {
          if (lowercaseTranscript.includes(phrase)) {
            foundKeywords.push(phrase);
          }
        }
        
        if (foundKeywords.length > 0) {
          setDetectedKeywords(foundKeywords);
          
          // Determine intent from transcript
          let intent = null;
          
          if (lowercaseTranscript.includes('i need')) {
            intent = 'need';
          } else if (lowercaseTranscript.includes('i want')) {
            intent = 'want';
          } else if (lowercaseTranscript.includes('help')) {
            intent = 'help';
          } else if (
            lowercaseTranscript.includes('emergency') || 
            lowercaseTranscript.includes('urgent') ||
            lowercaseTranscript.includes('crisis') ||
            lowercaseTranscript.includes('danger')
          ) {
            intent = 'emergency';
          }
          
          if (intent) {
            setDetectedIntent(intent);
            console.log(`Detected intent: ${intent}`);
          }
        }
      }
    } catch (error) {
      console.error('Error processing audio for wake words:', error);
    } finally {
      clearRecording();
      setIsProcessing(false);
    }
  }, [isProcessing, clearRecording]);
  
  // Start continuous listening cycle
  const startContinuousListening = useCallback(() => {
    if (continuousTimerRef.current) {
      clearInterval(continuousTimerRef.current);
    }
    
    // Start recording immediately
    if (!isRecording) {
      startRecording();
    }
    
    // Set up interval to repeatedly record and process audio
    continuousTimerRef.current = setInterval(() => {
      if (isRecording) {
        stopRecording();
        
        // Set a timer to start recording again after processing
        processingTimerRef.current = setTimeout(() => {
          startRecording();
        }, 1000); // Give 1 second pause between recordings
      }
    }, 5000); // Record in 5-second chunks
  }, [isRecording, startRecording, stopRecording]);
  
  // Process recorded audio when it becomes available
  useEffect(() => {
    if (recordedAudio && !isProcessing && isListening) {
      processAudio(recordedAudio);
    }
  }, [recordedAudio, isProcessing, isListening, processAudio]);
  
  // Clean up on unmount
  useEffect(() => {
    return () => {
      if (continuousTimerRef.current) {
        clearInterval(continuousTimerRef.current);
      }
      
      if (processingTimerRef.current) {
        clearTimeout(processingTimerRef.current);
      }
    };
  }, []);
  
  // Reset detected keywords and intent
  const resetDetections = useCallback(() => {
    setDetectedKeywords([]);
    setDetectedIntent(null);
  }, []);
  
  return {
    isListening,
    startListening,
    stopListening,
    detectedKeywords,
    detectedIntent,
    lastTranscript,
    isProcessing,
    resetDetections
  };
}