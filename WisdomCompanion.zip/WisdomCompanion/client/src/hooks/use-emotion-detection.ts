import { useState, useEffect, useCallback } from 'react';
import * as faceapi from 'face-api.js';

interface EmotionDetectionOptions {
  onEmotionDetected?: (emotion: string, confidence: number) => void;
  autoLoadModels?: boolean;
}

export function useEmotionDetection(options: EmotionDetectionOptions = {}) {
  const { onEmotionDetected, autoLoadModels = true } = options;
  
  const [currentEmotion, setCurrentEmotion] = useState<string | null>(null);
  const [currentConfidence, setCurrentConfidence] = useState<number>(0);
  const [isLoading, setIsLoading] = useState<boolean>(false);
  const [error, setError] = useState<string | null>(null);
  const [modelsLoaded, setModelsLoaded] = useState<boolean>(false);

  // Load face-api models
  const loadModels = useCallback(async () => {
    try {
      setIsLoading(true);
      setError(null);
      
      // Try different model paths to handle different environments
      const possibleModelPaths = [
        '/models',
        `${window.location.origin}/models`,
        '/public/models',
        `${window.location.origin}/public/models`,
        './models',
        '../models',
      ];

      let modelsLoadedSuccessfully = false;
      const loadErrors = [];

      for (const modelPath of possibleModelPaths) {
        try {
          console.log('Attempting to load face-api models from:', modelPath);
          
          // Set the model path
          faceapi.env.monkeyPatch({
            Canvas: HTMLCanvasElement,
            Image: HTMLImageElement,
            ImageData: ImageData,
            Video: HTMLVideoElement,
            createCanvasElement: () => document.createElement('canvas'),
            createImageElement: () => document.createElement('img')
          });

          // Load the models
          await Promise.all([
            faceapi.nets.tinyFaceDetector.loadFromUri(modelPath),
            faceapi.nets.faceExpressionNet.loadFromUri(modelPath)
          ]);
          
          modelsLoadedSuccessfully = true;
          break;
        } catch (err) {
          loadErrors.push(err);
          console.warn(`Failed to load face-api models from ${modelPath}:`, err);
        }
      }

      if (!modelsLoadedSuccessfully) {
        console.error('Failed to load face-api models from any path');
        throw new Error('Could not load face detection models from any path');
      }

      setModelsLoaded(true);
    } catch (err) {
      console.error('Error loading face-api models:', err);
      setError('Failed to load emotion detection models. Emotion detection will not be available.');
      setModelsLoaded(false);
    } finally {
      setIsLoading(false);
    }
  }, []);

  // Detect emotion from base64 image
  const detectEmotion = useCallback(async (base64Image: string) => {
    if (!modelsLoaded) {
      console.warn('Models not loaded, cannot detect emotion');
      return;
    }
    
    try {
      // Create an image element from the base64 string
      const img = document.createElement('img');
      img.src = `data:image/jpeg;base64,${base64Image}`;
      
      // Wait for the image to load
      await new Promise((resolve) => {
        img.onload = resolve;
      });
      
      // Detect faces and expressions
      const detections = await faceapi
        .detectAllFaces(img, new faceapi.TinyFaceDetectorOptions())
        .withFaceExpressions();
      
      if (detections.length === 0) {
        console.log('No faces detected');
        return;
      }
      
      // Get the face with the highest confidence
      const face = detections[0];
      const expressions = face.expressions;
      
      // Find the emotion with the highest confidence
      let highestConfidence = 0;
      let highestEmotionName = '';
      
      for (const [emotion, confidence] of Object.entries(expressions)) {
        if (confidence > highestConfidence) {
          highestConfidence = confidence;
          highestEmotionName = emotion;
        }
      }
      
      // Only update if confidence is reasonable
      if (highestConfidence > 0.4) {
        setCurrentEmotion(highestEmotionName);
        setCurrentConfidence(highestConfidence);
        
        // Call the callback if provided
        if (onEmotionDetected) {
          onEmotionDetected(highestEmotionName, highestConfidence);
        }
      }
    } catch (err) {
      console.error('Error detecting emotion:', err);
    }
  }, [modelsLoaded, onEmotionDetected]);

  // Load models on mount if autoLoadModels is true
  useEffect(() => {
    if (autoLoadModels) {
      loadModels();
    }
    
    // Cleanup
    return () => {
      setCurrentEmotion(null);
      setCurrentConfidence(0);
    };
  }, [autoLoadModels, loadModels]);

  return {
    currentEmotion,
    currentConfidence,
    isLoading,
    error,
    modelsLoaded,
    loadModels,
    detectEmotion
  };
}