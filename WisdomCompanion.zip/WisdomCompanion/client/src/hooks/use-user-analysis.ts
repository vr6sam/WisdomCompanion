import { useState, useCallback, useRef, useEffect } from 'react';
import { apiRequest } from '@/lib/queryClient';

export interface UserAnalysisResult {
  emotion: string;
  attentionLevel: number; // 0-1 scale
  engagement: number; // 0-1 scale
  posture: 'good' | 'slouching' | 'unsure';
  eyeContact: boolean;
  gesture: string | null;
  timestamp: Date;
}

export interface UserAnalysisOptions {
  /** Analyze emotions continuously */
  trackEmotions?: boolean;
  
  /** Analyze attention level continuously */
  trackAttention?: boolean;
  
  /** Analyze at specified interval (ms) */
  interval?: number;
  
  /** Only analyze when significant changes detected */
  onlyOnChange?: boolean;
}

/**
 * Hook to analyze user state from camera feed
 */
export function useUserAnalysis(options: UserAnalysisOptions = {}) {
  // Default options
  const {
    trackEmotions = false,
    trackAttention = false,
    interval = 5000,
    onlyOnChange = true
  } = options;
  
  // Analysis results state
  const [currentEmotion, setCurrentEmotion] = useState<string>('neutral');
  const [attentionLevel, setAttentionLevel] = useState<number>(0.5);
  const [engagement, setEngagement] = useState<number>(0.5);
  const [posture, setPosture] = useState<'good' | 'slouching' | 'unsure'>('unsure');
  const [eyeContact, setEyeContact] = useState<boolean>(false);
  const [gesture, setGesture] = useState<string | null>(null);
  
  // Processing state
  const [isAnalyzing, setIsAnalyzing] = useState<boolean>(false);
  const [error, setError] = useState<string | null>(null);
  const [lastAnalysisTime, setLastAnalysisTime] = useState<Date | null>(null);
  
  // Store historical data
  const emotionHistoryRef = useRef<Array<{emotion: string, timestamp: Date}>>([]);
  const attentionHistoryRef = useRef<Array<{level: number, timestamp: Date}>>([]);
  
  // Track if continuous analysis is active
  const trackingActiveRef = useRef<boolean>(false);
  
  // Add to emotion history
  const addEmotionToHistory = useCallback((emotion: string) => {
    emotionHistoryRef.current.push({
      emotion,
      timestamp: new Date()
    });
    
    // Limit history size
    if (emotionHistoryRef.current.length > 20) {
      emotionHistoryRef.current.shift();
    }
  }, []);
  
  // Add to attention history
  const addAttentionToHistory = useCallback((level: number) => {
    attentionHistoryRef.current.push({
      level,
      timestamp: new Date()
    });
    
    // Limit history size
    if (attentionHistoryRef.current.length > 20) {
      attentionHistoryRef.current.shift();
    }
  }, []);
  
  /**
   * Analyze user emotion from image
   */
  const analyzeEmotion = useCallback(async (imageBase64: string): Promise<string> => {
    try {
      // Call the vision API to analyze emotion
      const prompt = "What emotion is this person showing? Respond with a single emotion word like 'happy', 'sad', 'angry', 'surprised', 'fearful', 'disgusted', or 'neutral'. Only respond with a single word.";
      
      const response = await apiRequest('/api/vision/describe', {
        method: 'POST',
        body: JSON.stringify({ 
          image: imageBase64,
          prompt
        })
      });
      
      if (!response.ok) {
        throw new Error('Failed to analyze emotion');
      }
      
      const data = await response.json();
      
      // Extract just the emotion word
      const emotion = data.description.trim().toLowerCase().replace(/[^a-z]/g, '');
      
      // Update state
      setCurrentEmotion(emotion);
      addEmotionToHistory(emotion);
      
      return emotion;
    } catch (error) {
      console.error('Error analyzing emotion:', error);
      return 'neutral';
    }
  }, [addEmotionToHistory]);
  
  /**
   * Analyze user's attention level from image
   */
  const analyzeAttention = useCallback(async (imageBase64: string): Promise<number> => {
    try {
      // Call the vision API to analyze attention
      const prompt = "On a scale of 0 to 10, how attentive does this person appear to be? Consider factors like eye gaze, facial expression, and posture. Respond only with a single number.";
      
      const response = await apiRequest('/api/vision/describe', {
        method: 'POST',
        body: JSON.stringify({ 
          image: imageBase64,
          prompt
        })
      });
      
      if (!response.ok) {
        throw new Error('Failed to analyze attention');
      }
      
      const data = await response.json();
      
      // Extract the numeric rating
      const attentionText = data.description.trim();
      const attentionMatch = attentionText.match(/\d+/);
      const attentionScore = attentionMatch ? parseInt(attentionMatch[0], 10) : 5;
      
      // Convert to 0-1 scale
      const normalizedAttention = Math.min(Math.max(attentionScore / 10, 0), 1);
      
      // Update state
      setAttentionLevel(normalizedAttention);
      addAttentionToHistory(normalizedAttention);
      
      return normalizedAttention;
    } catch (error) {
      console.error('Error analyzing attention:', error);
      return 0.5;
    }
  }, [addAttentionToHistory]);
  
  /**
   * Analyze user's posture from image
   */
  const analyzePosture = useCallback(async (imageBase64: string): Promise<'good' | 'slouching' | 'unsure'> => {
    try {
      const prompt = "Analyze this person's posture. Is it 'good' (upright, shoulders back) or 'slouching' (hunched, leaning forward)? Respond only with either 'good' or 'slouching'.";
      
      const response = await apiRequest('/api/vision/describe', {
        method: 'POST',
        body: JSON.stringify({ 
          image: imageBase64,
          prompt
        })
      });
      
      if (!response.ok) {
        throw new Error('Failed to analyze posture');
      }
      
      const data = await response.json();
      
      // Determine posture type
      const postureText = data.description.toLowerCase().trim();
      let postureType: 'good' | 'slouching' | 'unsure' = 'unsure';
      
      if (postureText.includes('good')) {
        postureType = 'good';
      } else if (postureText.includes('slouch')) {
        postureType = 'slouching';
      }
      
      // Update state
      setPosture(postureType);
      
      return postureType;
    } catch (error) {
      console.error('Error analyzing posture:', error);
      return 'unsure';
    }
  }, []);
  
  /**
   * Check if user is making eye contact
   */
  const checkEyeContact = useCallback(async (imageBase64: string): Promise<boolean> => {
    try {
      const prompt = "Is this person looking directly at the camera (making eye contact)? Answer only with 'yes' or 'no'.";
      
      const response = await apiRequest('/api/vision/describe', {
        method: 'POST',
        body: JSON.stringify({ 
          image: imageBase64,
          prompt
        })
      });
      
      if (!response.ok) {
        throw new Error('Failed to check eye contact');
      }
      
      const data = await response.json();
      
      // Check if making eye contact
      const isEyeContact = data.description.toLowerCase().includes('yes');
      
      // Update state
      setEyeContact(isEyeContact);
      
      return isEyeContact;
    } catch (error) {
      console.error('Error checking eye contact:', error);
      return false;
    }
  }, []);
  
  /**
   * Perform a comprehensive analysis of the user
   */
  const analyzeUser = useCallback(async (imageBase64: string): Promise<UserAnalysisResult> => {
    try {
      setIsAnalyzing(true);
      setError(null);
      
      // Perform all analyses in parallel
      const [emotion, attentionScore, postureResult, eyeContactResult] = await Promise.all([
        analyzeEmotion(imageBase64),
        analyzeAttention(imageBase64),
        analyzePosture(imageBase64),
        checkEyeContact(imageBase64)
      ]);
      
      // Calculate engagement based on attention and eye contact
      const engagementScore = eyeContactResult ? 
        (attentionScore * 0.7) + 0.3 : 
        attentionScore * 0.7;
      
      setEngagement(engagementScore);
      setLastAnalysisTime(new Date());
      setIsAnalyzing(false);
      
      // Return comprehensive result
      const result: UserAnalysisResult = {
        emotion,
        attentionLevel: attentionScore,
        engagement: engagementScore,
        posture: postureResult,
        eyeContact: eyeContactResult,
        gesture: null, // Gesture detection not implemented yet
        timestamp: new Date()
      };
      
      return result;
    } catch (error) {
      const errorMessage = error instanceof Error ? error.message : 'Unknown error';
      setError(errorMessage);
      setIsAnalyzing(false);
      
      // Return default values
      return {
        emotion: 'neutral',
        attentionLevel: 0.5,
        engagement: 0.5,
        posture: 'unsure',
        eyeContact: false,
        gesture: null,
        timestamp: new Date()
      };
    }
  }, [analyzeEmotion, analyzeAttention, analyzePosture, checkEyeContact]);
  
  /**
   * Start continuous tracking of user state
   */
  const startTracking = useCallback(() => {
    trackingActiveRef.current = true;
  }, []);
  
  /**
   * Stop continuous tracking
   */
  const stopTracking = useCallback(() => {
    trackingActiveRef.current = false;
  }, []);
  
  /**
   * Get emotion history data
   */
  const getEmotionHistory = useCallback(() => {
    return [...emotionHistoryRef.current];
  }, []);
  
  /**
   * Get attention history data
   */
  const getAttentionHistory = useCallback(() => {
    return [...attentionHistoryRef.current];
  }, []);
  
  /**
   * Get dominant emotion over recent history
   */
  const getDominantEmotion = useCallback((): string => {
    if (emotionHistoryRef.current.length === 0) {
      return 'neutral';
    }
    
    const emotionCounts: Record<string, number> = {};
    
    // Count occurrences of each emotion
    emotionHistoryRef.current.forEach(entry => {
      emotionCounts[entry.emotion] = (emotionCounts[entry.emotion] || 0) + 1;
    });
    
    // Find the emotion with the highest count
    let maxCount = 0;
    let dominantEmotion = 'neutral';
    
    Object.entries(emotionCounts).forEach(([emotion, count]) => {
      if (count > maxCount) {
        maxCount = count;
        dominantEmotion = emotion;
      }
    });
    
    return dominantEmotion;
  }, []);
  
  // Clean up on unmount
  useEffect(() => {
    return () => {
      trackingActiveRef.current = false;
    };
  }, []);
  
  return {
    // Current state
    currentEmotion,
    attentionLevel,
    engagement,
    posture,
    eyeContact,
    gesture,
    
    // Processing state
    isAnalyzing,
    error,
    lastAnalysisTime,
    
    // Analysis methods
    analyzeUser,
    analyzeEmotion,
    analyzeAttention,
    analyzePosture,
    checkEyeContact,
    
    // Tracking control
    startTracking,
    stopTracking,
    
    // History access
    getEmotionHistory,
    getAttentionHistory,
    getDominantEmotion
  };
}