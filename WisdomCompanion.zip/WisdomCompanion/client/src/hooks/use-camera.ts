import { useState, useEffect, useCallback, useRef } from "react";

export function useCamera() {
  const [cameraEnabled, setCameraEnabled] = useState(false);
  const [cameraStream, setCameraStream] = useState<MediaStream | null>(null);
  const [isCameraLoading, setIsCameraLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [imageData, setImageData] = useState<string | null>(null);
  const videoRef = useRef<HTMLVideoElement | null>(null);
  
  // Start camera
  const startCamera = useCallback(async () => {
    if (cameraStream) return; // Already started
    
    setIsCameraLoading(true);
    try {
      const stream = await navigator.mediaDevices.getUserMedia({
        video: {
          width: { ideal: 640 },
          height: { ideal: 480 },
          facingMode: "user"
        }
      });
      
      setCameraStream(stream);
      setCameraEnabled(true);
      setError(null);
      
      // Set video ref stream if available
      if (videoRef.current) {
        videoRef.current.srcObject = stream;
      }
    } catch (err) {
      console.error("Error accessing camera:", err);
      setError("Could not access camera. Please check permissions.");
      setCameraEnabled(false);
    } finally {
      setIsCameraLoading(false);
    }
  }, [cameraStream, videoRef]);
  
  // Stop camera
  const stopCamera = useCallback(() => {
    if (cameraStream) {
      // Turn off camera
      cameraStream.getTracks().forEach(track => track.stop());
      setCameraStream(null);
      setCameraEnabled(false);
      setImageData(null);
      
      // Clear video ref
      if (videoRef.current) {
        videoRef.current.srcObject = null;
      }
    }
  }, [cameraStream, videoRef]);

  // Toggle camera on/off
  const toggleCamera = useCallback(async () => {
    if (cameraStream) {
      stopCamera();
      return;
    }

    // Turn on camera
    setIsCameraLoading(true);
    try {
      const stream = await navigator.mediaDevices.getUserMedia({
        video: {
          width: { ideal: 640 },
          height: { ideal: 480 },
          facingMode: "user"
        }
      });
      
      setCameraStream(stream);
      setCameraEnabled(true);
      setError(null);
    } catch (err) {
      console.error("Error accessing camera:", err);
      setError("Could not access camera. Please check permissions.");
      setCameraEnabled(false);
    } finally {
      setIsCameraLoading(false);
    }
  }, [cameraStream]);

  // Capture a snapshot from the camera
  const captureImage = useCallback(async (): Promise<string | null> => {
    if (!cameraStream) return null;

    try {
      // Use video ref if available, otherwise create a new video element
      let video: HTMLVideoElement;
      if (videoRef.current && videoRef.current.srcObject === cameraStream) {
        video = videoRef.current;
      } else {
        // Create a video element to display the stream
        video = document.createElement("video");
        video.srcObject = cameraStream;
        video.play();

        // Wait for video to be ready
        await new Promise((resolve) => {
          video.onloadedmetadata = () => {
            video.play();
            resolve(null);
          };
        });
      }

      // Create a canvas to capture the image
      const canvas = document.createElement("canvas");
      canvas.width = video.videoWidth || 640;
      canvas.height = video.videoHeight || 480;
      const ctx = canvas.getContext("2d");
      
      if (!ctx) return null;
      
      // Draw the current video frame to the canvas
      ctx.drawImage(video, 0, 0, canvas.width, canvas.height);
      
      // Convert to base64
      const imageBase64 = canvas.toDataURL("image/jpeg");
      
      // Store the image data and return it
      const base64Data = imageBase64;
      setImageData(base64Data);
      
      return base64Data.split(",")[1]; // Remove data URL prefix
    } catch (err) {
      console.error("Error capturing image:", err);
      return null;
    }
  }, [cameraStream, videoRef]);

  // Take snapshot at regular intervals when camera is active
  useEffect(() => {
    let intervalId: NodeJS.Timeout | null = null;
    
    if (cameraEnabled && cameraStream) {
      // Capture an image every 3 seconds
      intervalId = setInterval(async () => {
        await captureImage();
      }, 3000);
    }
    
    return () => {
      if (intervalId) {
        clearInterval(intervalId);
      }
    };
  }, [cameraEnabled, cameraStream, captureImage]);

  // Clean up on unmount
  useEffect(() => {
    return () => {
      if (cameraStream) {
        cameraStream.getTracks().forEach(track => track.stop());
      }
    };
  }, [cameraStream]);

  return {
    cameraEnabled,
    cameraStream,
    isCameraLoading,
    error,
    toggleCamera,
    startCamera,
    stopCamera,
    captureImage,
    imageData,
    videoRef
  };
}
