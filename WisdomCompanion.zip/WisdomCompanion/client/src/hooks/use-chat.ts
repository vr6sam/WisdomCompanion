import { useState, useEffect } from "react";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { Message } from "@shared/schema";
import { sendChatMessage } from "@/lib/openai";
import { useToast } from "@/hooks/use-toast";

export function useChat(userId: number) {
  const [messages, setMessages] = useState<Message[]>([]);
  const [isLoading, setIsLoading] = useState(false);
  const queryClient = useQueryClient();
  const { toast } = useToast();

  // Fetch messages on component mount
  const { data, isLoading: isLoadingMessages } = useQuery({
    queryKey: ['/api/messages'],
    enabled: !!userId
  });

  // Initialize the messages state when data is fetched
  useEffect(() => {
    if (data) {
      setMessages(data);
    }
  }, [data]);

  // If no messages exist, provide a welcome message
  useEffect(() => {
    if (!isLoadingMessages && (!messages || messages.length === 0)) {
      const welcomeMessage: Message = {
        id: 0,
        userId,
        content: "Hello! I'm your intuitive AI assistant. I can help you with information, reminders, advice, or just chat about what's on your mind. I can also recognize visual and audio context if you enable your camera and microphone.",
        role: "assistant",
        timestamp: new Date(),
      };
      
      setMessages([welcomeMessage]);
    }
  }, [messages, isLoadingMessages, userId]);

  // Send a message and get AI response
  const sendMessage = async (content: string) => {
    if (!content.trim() || isLoading) return;
    
    try {
      setIsLoading(true);
      
      // Add user message to local state immediately for better UX
      const userMessage: Message = {
        id: Date.now(),
        userId,
        content,
        role: "user",
        timestamp: new Date(),
      };
      
      setMessages(prev => [...prev, userMessage]);
      
      // Send to server
      const response = await sendChatMessage(content);
      
      // Update messages with the server response
      setMessages(prev => {
        // Find and replace the temporary message
        const filtered = prev.filter(m => m.id !== userMessage.id);
        return [...filtered, response.userMessage, response.aiMessage];
      });
      
      // Invalidate query cache to update any components using the messages
      queryClient.invalidateQueries({ queryKey: ['/api/messages'] });
      
      return response;
    } catch (error) {
      console.error("Error sending message:", error);
      toast({
        title: "Error",
        description: "Failed to send message. Please try again.",
        variant: "destructive",
      });
      
      // Remove the temporary message if there was an error
      setMessages(prev => prev.filter(m => m.id !== Date.now()));
    } finally {
      setIsLoading(false);
    }
  };

  return {
    messages,
    isLoading: isLoading || isLoadingMessages,
    sendMessage,
  };
}
