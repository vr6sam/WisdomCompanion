import { useState, useCallback, useRef } from 'react';
import { apiRequest } from '@/lib/queryClient';

export interface RecognizedObject {
  name: string;
  confidence: number;
  location?: {
    x: number;
    y: number;
    width: number;
    height: number;
  };
}

export interface ObjectRecognitionResult {
  objects: RecognizedObject[];
  sceneDescription: string;
  timestamp: Date;
}

/**
 * Hook for object recognition using the camera
 */
export function useObjectRecognition() {
  const [objects, setObjects] = useState<RecognizedObject[]>([]);
  const [sceneDescription, setSceneDescription] = useState<string>('');
  const [isProcessing, setIsProcessing] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const lastResultRef = useRef<ObjectRecognitionResult | null>(null);
  
  /**
   * Recognize objects in an image using OpenAI vision
   */
  const recognizeObjects = useCallback(async (imageBase64: string): Promise<ObjectRecognitionResult> => {
    try {
      setIsProcessing(true);
      setError(null);
      
      // Call the backend API
      const response = await apiRequest('/api/vision/analyze', {
        method: 'POST',
        body: JSON.stringify({ 
          image: imageBase64,
          prompt: "Analyze this image and identify all distinct objects. Provide a clear scene description."
        })
      });
      
      if (!response.ok) {
        const errorData = await response.json();
        throw new Error(errorData.error || 'Failed to recognize objects');
      }
      
      const data = await response.json();
      
      // Convert the raw objects into RecognizedObject format
      const recognizedObjects: RecognizedObject[] = data.objects.map((name: string) => ({
        name,
        confidence: 0.9, // OpenAI doesn't provide confidence scores, using a default
      }));
      
      // Update state
      setObjects(recognizedObjects);
      setSceneDescription(data.sceneDescription || '');
      setIsProcessing(false);
      
      // Store result
      const result = {
        objects: recognizedObjects,
        sceneDescription: data.sceneDescription || '',
        timestamp: new Date()
      };
      
      lastResultRef.current = result;
      return result;
    } catch (error) {
      const errorMessage = error instanceof Error ? error.message : 'Unknown error';
      setError(errorMessage);
      setIsProcessing(false);
      
      // Return empty result on error
      return {
        objects: [],
        sceneDescription: '',
        timestamp: new Date()
      };
    }
  }, []);
  
  /**
   * Find objects of a specific type in the scene
   */
  const findObjectsOfType = useCallback(async (
    imageBase64: string, 
    objectType: string
  ): Promise<RecognizedObject[]> => {
    try {
      const prompt = `Identify all ${objectType} in this image. Respond with a JSON array of strings with only the names of the ${objectType} found. If none are found, respond with an empty array.`;
      
      const response = await apiRequest('/api/vision/describe', {
        method: 'POST',
        body: JSON.stringify({ 
          image: imageBase64,
          prompt
        })
      });
      
      if (!response.ok) {
        throw new Error(`Failed to find ${objectType}`);
      }
      
      const data = await response.json();
      
      // Try to parse as JSON array
      try {
        const objectNames = JSON.parse(data.description);
        if (Array.isArray(objectNames)) {
          return objectNames.map(name => ({
            name: String(name),
            confidence: 0.9
          }));
        }
      } catch (error) {
        // If not valid JSON, try to extract objects from text
        const objectMatches = data.description.match(/[•\-\*]\s*([\w\s]+)|\d+\.\s*([\w\s]+)/g);
        if (objectMatches) {
          return objectMatches
            .map((item: string) => ({
              name: item.replace(/[•\-\*]\s*|\d+\.\s*/, '').trim(),
              confidence: 0.8
            }))
            .filter((obj: RecognizedObject) => obj.name.length > 0);
        }
      }
      
      return [];
    } catch (error) {
      console.error(`Error finding ${objectType}:`, error);
      return [];
    }
  }, []);
  
  /**
   * Check if a specific object is present in the image
   */
  const isObjectPresent = useCallback(async (
    imageBase64: string, 
    objectName: string
  ): Promise<boolean> => {
    try {
      const prompt = `Is there a ${objectName} in this image? Answer only with "yes" or "no".`;
      
      const response = await apiRequest('/api/vision/describe', {
        method: 'POST',
        body: JSON.stringify({ 
          image: imageBase64,
          prompt
        })
      });
      
      if (!response.ok) {
        throw new Error(`Failed to check for ${objectName}`);
      }
      
      const data = await response.json();
      return data.description.toLowerCase().includes('yes');
    } catch (error) {
      console.error(`Error checking for ${objectName}:`, error);
      return false;
    }
  }, []);
  
  /**
   * Extract text from an image (OCR)
   */
  const extractText = useCallback(async (imageBase64: string): Promise<string[]> => {
    try {
      const response = await apiRequest('/api/vision/ocr', {
        method: 'POST',
        body: JSON.stringify({ 
          image: imageBase64
        })
      });
      
      if (!response.ok) {
        throw new Error('Failed to extract text from image');
      }
      
      const data = await response.json();
      return data.textBlocks || [];
    } catch (error) {
      console.error('Error extracting text:', error);
      return [];
    }
  }, []);
  
  return {
    objects,
    sceneDescription,
    isProcessing,
    error,
    lastResult: lastResultRef.current,
    recognizeObjects,
    findObjectsOfType,
    isObjectPresent,
    extractText
  };
}