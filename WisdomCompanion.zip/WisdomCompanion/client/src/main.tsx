import { createRoot } from "react-dom/client";
import App from "./App";
import "./index.css";
import * as faceapi from 'face-api.js';
import * as tf from '@tensorflow/tfjs';

// Load TensorFlow.js
const loadTf = async () => {
  try {
    await tf.ready();
    console.log('TensorFlow.js loaded successfully');
  } catch (error) {
    console.error('Failed to load TensorFlow.js:', error);
  }
};

// Import face detection utility
import { loadFaceApiModels } from './lib/faceDetection';

// Load face-api.js models
const loadFaceApi = async () => {
  try {
    await loadFaceApiModels();
  } catch (error) {
    console.error('Failed to load face-api models:', error);
  }
};

// Initialize resources then render app
const initApp = async () => {
  // Load models in parallel
  await Promise.all([loadTf(), loadFaceApi()]);
  createRoot(document.getElementById("root")!).render(<App />);
};

initApp();
