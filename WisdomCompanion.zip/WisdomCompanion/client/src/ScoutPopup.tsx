import React from 'react';

type Props = {
  text: string;
  visible: boolean;
};

export default function ScoutPopup({ text, visible }: Props) {
  if (!visible) return null;

  return (
    <div style={{
      position: 'fixed',
      bottom: '20px',
      right: '20px',
      background: '#222',
      color: '#fff',
      padding: '12px 20px',
      borderRadius: '12px',
      fontSize: '16px',
      zIndex: 9999,
    }}>
      {text}
    </div>
  );
}