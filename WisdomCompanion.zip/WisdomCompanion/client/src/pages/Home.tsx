import { useState, useEffect } from "react";
import Header from "@/components/Header";
import IntelligentAssistant from "@/components/IntelligentAssistant";
import EnhancedConversationAssistant from "@/components/EnhancedConversationAssistant";
import KnowledgePanel from "@/components/KnowledgePanel";
import PermissionModal from "@/components/modals/PermissionModal";
import ReminderModal from "@/components/modals/ReminderModal";
import APIKeyConfigModal from "@/components/APIKeyConfigModal";
import { AIProviderStatus } from "@/components/AIProviderStatus";
import { useReminders } from "@/hooks/use-reminders";
import { useWakeWord } from "@/hooks/use-wake-word";
import { useToast } from "@/hooks/use-toast";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Button } from "@/components/ui/button";
import { Alert, AlertTitle, AlertDescription } from "@/components/ui/alert";
import { AlertCircle, KeyRound } from "lucide-react";
import { useQuery } from "@tanstack/react-query";

export default function Home() {
  // State for modals
  const [showPermissionModal, setShowPermissionModal] = useState(false);
  const [showReminderModal, setShowReminderModal] = useState(false);
  const [showAPIKeyModal, setShowAPIKeyModal] = useState(false);
  const [assistantActive, setAssistantActive] = useState(true);

  // User state
  const [userId, setUserId] = useState(1); // Default user ID
  
  // Get API provider status
  const { data: apiStatus } = useQuery({
    queryKey: ['ai-status'],
    queryFn: async () => {
      const response = await fetch('/api/ai-status');
      if (!response.ok) {
        throw new Error('Failed to fetch AI status');
      }
      return response.json();
    },
  });
  
  // Show API key modal if needed
  useEffect(() => {
    if (apiStatus && !apiStatus.providers.openai && !apiStatus.providers.anthropic) {
      setShowAPIKeyModal(true);
    }
  }, [apiStatus]);
  
  // Check if any AI provider is available
  const needsApiKeys = apiStatus && (!apiStatus.providers.openai && !apiStatus.providers.anthropic);

  // Initialize hooks
  const {
    reminders,
    addReminder,
    updateReminder,
    deleteReminder,
    isLoading: isRemindersLoading
  } = useReminders(userId);
  
  const { toast } = useToast();
  
  // Set up wake word detection to activate assistant
  const { isListening: isWakeWordActive } = useWakeWord({
    wakeWords: ['assistant', 'hey assistant', 'ai', 'hey ai'],
    autoStart: assistantActive,
    onWakeWordDetected: (word: string) => {
      setAssistantActive(true);
      toast({
        title: "Assistant activated",
        description: `I heard "${word}". How can I help you?`,
      });
    }
  });

  return (
    <div className="flex flex-col h-screen">
      <Header 
        onReminderClick={() => setShowReminderModal(true)} 
      />
      
      {/* API Key Alert Banner */}
      {needsApiKeys && (
        <Alert variant="destructive" className="mx-4 mt-2">
          <AlertCircle className="h-4 w-4" />
          <AlertTitle>API Keys Required</AlertTitle>
          <AlertDescription className="flex items-center justify-between">
            <span>Both OpenAI and Anthropic API keys are missing. The assistant requires at least one to function properly.</span>
            <Button 
              size="sm" 
              onClick={() => setShowAPIKeyModal(true)}
              className="ml-2 bg-destructive/10 hover:bg-destructive/20 text-destructive"
            >
              <KeyRound className="mr-2 h-4 w-4" />
              Configure API Keys
            </Button>
          </AlertDescription>
        </Alert>
      )}

      <div className="flex flex-1 overflow-hidden">
        <main className="flex flex-1 flex-col md:flex-row h-full overflow-hidden">
          <div className="flex flex-col w-full md:w-3/5 lg:w-2/3 h-full border-r border-neutral-200">
            {/* Assistant tabs to switch between models */}
            <Tabs defaultValue="enhanced" className="h-full flex flex-col">
              <div className="px-4 pt-2 border-b">
                <TabsList className="grid w-full grid-cols-2">
                  <TabsTrigger value="standard">Standard Assistant</TabsTrigger>
                  <TabsTrigger value="enhanced">Enhanced Conversation</TabsTrigger>
                </TabsList>
              </div>
              
              <TabsContent value="standard" className="flex-1 overflow-hidden data-[state=inactive]:hidden">
                <IntelligentAssistant 
                  initialWelcomeMessage="Hi there! I'm your hands-free AI assistant. I can respond to voice commands and help with anything you need."
                  className="h-full"
                />
              </TabsContent>
              
              <TabsContent value="enhanced" className="flex-1 overflow-hidden data-[state=inactive]:hidden">
                <EnhancedConversationAssistant />
              </TabsContent>
            </Tabs>
          </div>

          <div className="hidden md:flex md:w-2/5 lg:w-1/3 flex-col bg-neutral-50 overflow-auto">
            {/* Show AI Provider Status */}
            <div className="p-4 space-y-4">
              <AIProviderStatus />
              <Button 
                onClick={() => setShowAPIKeyModal(true)}
                variant="secondary"
                className="w-full"
              >
                Configure API Keys
              </Button>
            </div>
            
            <KnowledgePanel
              reminders={reminders}
              environmentData={{
                lighting: "Good",
                noiseLevel: "Low",
                expression: "neutral" // Default value
              }}
              cameraEnabled={true}
              microphoneEnabled={true}
              currentTopic={null}
            />
          </div>
        </main>
      </div>

      {/* Modals */}
      <PermissionModal
        isOpen={showPermissionModal}
        onClose={() => setShowPermissionModal(false)}
        onPermissionGranted={() => {
          setShowPermissionModal(false);
          setAssistantActive(true);
        }}
      />

      <ReminderModal
        isOpen={showReminderModal}
        onClose={() => setShowReminderModal(false)}
        reminders={reminders}
        addReminder={addReminder}
        updateReminder={updateReminder}
        deleteReminder={deleteReminder}
        isLoading={isRemindersLoading}
      />
      
      <APIKeyConfigModal
        isOpen={showAPIKeyModal}
        onClose={() => setShowAPIKeyModal(false)}
      />
    </div>
  );
}
