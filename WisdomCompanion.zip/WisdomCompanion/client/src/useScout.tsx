import { useEffect, useState } from 'react';

export function useScout() {
  const [isListening, setIsListening] = useState(false);
  const [transcript, setTranscript] = useState('');

  useEffect(() => {
    const SpeechRecognition = window.SpeechRecognition || window.webkitSpeechRecognition;
    if (!SpeechRecognition) return;

    const recognition = new SpeechRecognition();
    recognition.continuous = true;
    recognition.interimResults = false;
    recognition.lang = 'en-US';

    recognition.onresult = (event) => {
      const last = event.results.length - 1;
      const text = event.results[last][0].transcript.trim();
      setTranscript(text);
      console.log('Heard:', text);

      if (text.toLowerCase().includes('hey scout') || text.toLowerCase().includes('what now')) {
        speak('Listening, Sam. What’s next?');
        // Add more commands here later
      }
    };

    if (isListening) recognition.start();
    return () => recognition.stop();
  }, [isListening]);

  const speak = (text: string) => {
    const synth = window.speechSynthesis;
    const utter = new SpeechSynthesisUtterance(text);
    synth.speak(utter);
  };

  return {
    transcript,
    toggleListening: () => setIsListening(!isListening),
    speak,
    isListening,
  };
}