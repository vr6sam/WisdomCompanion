import { useState } from "react";

interface HeaderProps {
  onReminderClick: () => void;
}

export default function Header({ onReminderClick }: HeaderProps) {
  const [showSettingsMenu, setShowSettingsMenu] = useState(false);
  
  // Toggle settings menu
  const toggleSettingsMenu = () => {
    setShowSettingsMenu(!showSettingsMenu);
  };
  
  return (
    <header className="bg-white border-b border-neutral-200 py-3 px-4 md:px-6 flex items-center justify-between shadow-sm">
      <div className="flex items-center space-x-3">
        <div className="flex items-center justify-center bg-gradient-to-r from-primary to-accent w-10 h-10 rounded-lg">
          <i className="ri-brain-line text-xl text-white"></i>
        </div>
        <h1 className="text-xl font-sans font-semibold">Intuitive AI</h1>
      </div>
      
      <div className="flex items-center space-x-2 md:space-x-4">
        <button 
          type="button" 
          className="p-2 text-neutral-500 hover:bg-neutral-100 rounded-full transition-colors" 
          aria-label="Reminders"
          onClick={onReminderClick}
        >
          <i className="ri-notification-3-line text-xl"></i>
        </button>
        
        <div className="relative">
          <button 
            type="button" 
            className="p-2 text-neutral-500 hover:bg-neutral-100 rounded-full transition-colors" 
            aria-label="Settings"
            onClick={toggleSettingsMenu}
          >
            <i className="ri-settings-4-line text-xl"></i>
          </button>
          
          {/* Settings dropdown menu */}
          {showSettingsMenu && (
            <div className="absolute right-0 top-full mt-1 w-48 bg-white border border-neutral-200 rounded-lg shadow-lg z-50">
              <div className="py-1">
                <button 
                  className="w-full text-left px-4 py-2 text-sm text-neutral-700 hover:bg-neutral-100"
                  onClick={() => {
                    // Clear localStorage data
                    localStorage.clear();
                    setShowSettingsMenu(false);
                  }}
                >
                  <i className="ri-delete-bin-line mr-2"></i>
                  Clear conversation
                </button>
                
                <button 
                  className="w-full text-left px-4 py-2 text-sm text-neutral-700 hover:bg-neutral-100"
                  onClick={() => {
                    // Open help info
                    setShowSettingsMenu(false);
                  }}
                >
                  <i className="ri-information-line mr-2"></i>
                  About Intuitive AI
                </button>
                
                <button 
                  className="w-full text-left px-4 py-2 text-sm text-neutral-700 hover:bg-neutral-100"
                  onClick={() => {
                    // Toggle theme (implementation would be added later)
                    setShowSettingsMenu(false);
                  }}
                >
                  <i className="ri-contrast-2-line mr-2"></i>
                  Toggle theme
                </button>
              </div>
            </div>
          )}
        </div>
        
        <div className="hidden md:flex items-center space-x-2 pl-2 border-l border-neutral-200">
          <div className="w-8 h-8 rounded-full bg-neutral-200 overflow-hidden">
            <div className="w-full h-full flex items-center justify-center text-neutral-600">
              <i className="ri-user-line text-lg"></i>
            </div>
          </div>
          <span className="text-sm font-medium hidden lg:inline">User</span>
        </div>
      </div>
    </header>
  );
}
