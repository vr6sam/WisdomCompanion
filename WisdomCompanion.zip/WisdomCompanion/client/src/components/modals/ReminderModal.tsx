import { useState } from "react";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Reminder } from "@shared/schema";
import { formatDateTime, getReminderIconByTitle } from "@/lib/utils";
import { zodResolver } from "@hookform/resolvers/zod";
import { useForm } from "react-hook-form";
import { z } from "zod";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";

interface ReminderModalProps {
  isOpen: boolean;
  onClose: () => void;
  reminders: Reminder[];
  addReminder: (reminder: any) => Promise<void>;
  updateReminder: (id: number, reminder: any) => Promise<void>;
  deleteReminder: (id: number) => Promise<void>;
  isLoading: boolean;
}

// Form schema for creating/editing reminders
const reminderFormSchema = z.object({
  title: z.string().min(1, { message: "Title is required" }),
  description: z.string().optional(),
  dueDate: z.string().min(1, { message: "Due date is required" }),
  dueTime: z.string().min(1, { message: "Due time is required" })
});

type ReminderFormValues = z.infer<typeof reminderFormSchema>;

export default function ReminderModal({
  isOpen,
  onClose,
  reminders,
  addReminder,
  updateReminder,
  deleteReminder,
  isLoading
}: ReminderModalProps) {
  const [showForm, setShowForm] = useState(false);
  const [editingReminder, setEditingReminder] = useState<Reminder | null>(null);

  // Initialize form
  const form = useForm<ReminderFormValues>({
    resolver: zodResolver(reminderFormSchema),
    defaultValues: {
      title: "",
      description: "",
      dueDate: new Date().toISOString().split("T")[0],
      dueTime: "09:00"
    }
  });

  // Handle creating/editing a reminder
  const onSubmit = async (values: ReminderFormValues) => {
    try {
      const dueDateObj = new Date(`${values.dueDate}T${values.dueTime}`);
      
      if (editingReminder) {
        // Update existing reminder
        await updateReminder(editingReminder.id, {
          userId: 1,
          title: values.title,
          description: values.description || "",
          dueDate: dueDateObj,
          completed: editingReminder.completed
        });
      } else {
        // Create new reminder
        await addReminder({
          userId: 1,
          title: values.title,
          description: values.description || "",
          dueDate: dueDateObj,
          completed: false
        });
      }
      
      // Reset form and close
      form.reset();
      setShowForm(false);
      setEditingReminder(null);
    } catch (error) {
      console.error("Error saving reminder:", error);
    }
  };

  // Handle editing a reminder
  const handleEdit = (reminder: Reminder) => {
    setEditingReminder(reminder);
    
    const dueDate = new Date(reminder.dueDate);
    const dateStr = dueDate.toISOString().split("T")[0];
    const hours = dueDate.getHours().toString().padStart(2, "0");
    const minutes = dueDate.getMinutes().toString().padStart(2, "0");
    
    form.reset({
      title: reminder.title,
      description: reminder.description || "",
      dueDate: dateStr,
      dueTime: `${hours}:${minutes}`
    });
    
    setShowForm(true);
  };

  // Handle toggling completion status
  const handleToggleComplete = async (reminder: Reminder) => {
    try {
      await updateReminder(reminder.id, {
        ...reminder,
        completed: !reminder.completed
      });
    } catch (error) {
      console.error("Error toggling reminder completion:", error);
    }
  };

  // Handle deleting a reminder
  const handleDelete = async (id: number) => {
    if (confirm("Are you sure you want to delete this reminder?")) {
      try {
        await deleteReminder(id);
      } catch (error) {
        console.error("Error deleting reminder:", error);
      }
    }
  };

  const sortedReminders = [...reminders].sort((a, b) => {
    // Sort by completion status first (incomplete first)
    if (a.completed !== b.completed) {
      return a.completed ? 1 : -1;
    }
    // Then sort by due date
    return new Date(a.dueDate).getTime() - new Date(b.dueDate).getTime();
  });

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="sm:max-w-lg">
        <DialogHeader>
          <DialogTitle className="text-lg font-medium flex items-center justify-between">
            <span>Your Reminders</span>
            <Button 
              variant="ghost" 
              size="icon" 
              onClick={onClose}
              className="h-8 w-8 rounded-full"
            >
              <i className="ri-close-line text-xl"></i>
            </Button>
          </DialogTitle>
        </DialogHeader>
        
        <div className="max-h-[60vh] overflow-y-auto">
          {showForm ? (
            <Form {...form}>
              <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4 p-4">
                <FormField
                  control={form.control}
                  name="title"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Reminder title</FormLabel>
                      <FormControl>
                        <Input placeholder="E.g., Go for a run" {...field} />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                
                <FormField
                  control={form.control}
                  name="description"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Description (optional)</FormLabel>
                      <FormControl>
                        <Input placeholder="Add details..." {...field} />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                
                <div className="grid grid-cols-2 gap-4">
                  <FormField
                    control={form.control}
                    name="dueDate"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Date</FormLabel>
                        <FormControl>
                          <Input type="date" {...field} />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  
                  <FormField
                    control={form.control}
                    name="dueTime"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Time</FormLabel>
                        <FormControl>
                          <Input type="time" {...field} />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                </div>
                
                <div className="flex justify-end space-x-2 pt-2">
                  <Button
                    type="button"
                    variant="outline"
                    onClick={() => {
                      setShowForm(false);
                      setEditingReminder(null);
                      form.reset();
                    }}
                  >
                    Cancel
                  </Button>
                  <Button type="submit" disabled={isLoading}>
                    {editingReminder ? "Update" : "Create"} Reminder
                  </Button>
                </div>
              </form>
            </Form>
          ) : (
            <div className="p-4 space-y-3">
              {sortedReminders.length === 0 ? (
                <div className="text-center py-8">
                  <div className="bg-neutral-100 p-4 inline-block rounded-full mb-3">
                    <i className="ri-notification-3-line text-2xl text-neutral-500"></i>
                  </div>
                  <p className="text-neutral-600 mb-4">You don't have any reminders yet</p>
                </div>
              ) : (
                sortedReminders.map((reminder) => (
                  <div
                    key={reminder.id}
                    className={`flex items-center space-x-3 p-3 border border-neutral-200 rounded-lg hover:bg-neutral-50 ${
                      reminder.completed ? "opacity-60" : ""
                    }`}
                  >
                    <div 
                      className={`p-2 rounded-full flex-shrink-0 ${
                        reminder.completed 
                          ? "bg-neutral-100 text-neutral-500" 
                          : "bg-primary-100 text-primary-500"
                      }`}
                    >
                      <i className={getReminderIconByTitle(reminder.title)}></i>
                    </div>
                    <div className="flex-1" onClick={() => handleToggleComplete(reminder)}>
                      <p className={`font-medium ${reminder.completed ? "line-through" : ""}`}>
                        {reminder.title}
                      </p>
                      <p className="text-sm text-neutral-500">{formatDateTime(reminder.dueDate)}</p>
                    </div>
                    <div className="flex space-x-2">
                      <button
                        className="p-2 text-neutral-500 hover:text-primary transition-colors"
                        onClick={() => handleEdit(reminder)}
                      >
                        <i className="ri-edit-line"></i>
                      </button>
                      <button
                        className="p-2 text-neutral-500 hover:text-red-500 transition-colors"
                        onClick={() => handleDelete(reminder.id)}
                      >
                        <i className="ri-delete-bin-line"></i>
                      </button>
                    </div>
                  </div>
                ))
              )}
              
              <div className="mt-5 pt-5 border-t border-neutral-200">
                <Button
                  className="w-full"
                  variant="outline"
                  onClick={() => {
                    setShowForm(true);
                    form.reset();
                  }}
                >
                  <i className="ri-add-line mr-2"></i> Create new reminder
                </Button>
              </div>
            </div>
          )}
        </div>
      </DialogContent>
    </Dialog>
  );
}
