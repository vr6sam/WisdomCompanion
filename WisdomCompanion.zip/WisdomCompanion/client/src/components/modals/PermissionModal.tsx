import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";

interface PermissionModalProps {
  isOpen: boolean;
  onClose: () => void;
  onPermissionGranted: () => void;
}

export default function PermissionModal({ isOpen, onClose, onPermissionGranted }: PermissionModalProps) {
  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="sm:max-w-lg">
        <DialogHeader>
          <DialogTitle className="text-lg font-medium">Enable Sensing Capabilities</DialogTitle>
        </DialogHeader>
        
        <div className="py-4">
          <p className="mb-4 text-neutral-700">
            To provide personalized responses based on your environment, Intuitive AI needs permission to access your:
          </p>
          
          <div className="space-y-3 mb-5">
            <div className="flex items-start space-x-3">
              <div className="bg-primary-100 text-primary p-2 rounded-full mt-0.5">
                <i className="ri-camera-line"></i>
              </div>
              <div>
                <h3 className="font-medium">Camera</h3>
                <p className="text-sm text-neutral-600">For visual context and expression analysis</p>
              </div>
            </div>
            
            <div className="flex items-start space-x-3">
              <div className="bg-primary-100 text-primary p-2 rounded-full mt-0.5">
                <i className="ri-mic-line"></i>
              </div>
              <div>
                <h3 className="font-medium">Microphone</h3>
                <p className="text-sm text-neutral-600">For audio context and voice analysis</p>
              </div>
            </div>
          </div>
          
          <div className="bg-neutral-50 p-3 rounded-lg border border-neutral-200 mb-5">
            <p className="text-sm text-neutral-600 flex items-start">
              <i className="ri-information-line text-neutral-500 mr-2 mt-0.5"></i>
              All processing happens on your device. No audio or video is stored or sent to our servers.
            </p>
          </div>
        </div>
        
        <DialogFooter className="bg-neutral-50 sm:justify-end">
          <Button variant="outline" onClick={onClose}>
            Not now
          </Button>
          <Button onClick={onPermissionGranted}>
            Allow access
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}
