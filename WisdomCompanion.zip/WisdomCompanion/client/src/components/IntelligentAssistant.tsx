import React, { useState, useEffect, useRef } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Mic, MicOff, Camera, CameraOff, BrainCircuit, Settings, Eye, EyeOff } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Switch } from '@/components/ui/switch';
import { Label } from '@/components/ui/label';
import { Card, CardHeader, CardTitle, CardDescription, CardContent, CardFooter } from '@/components/ui/card';
import { useChatDialog } from '@/hooks/use-chat-dialog';
import { useAmbientAwareness } from '@/hooks/use-ambient-awareness';
import { useCamera } from '@/hooks/use-camera';
import { useMicrophone } from '@/hooks/use-microphone';
import { useSpeechRecognition } from '@/hooks/use-speech-recognition';
import AnimatedResponse from '@/components/AnimatedResponse';
import { TypingIndicator } from '@/components/ui/typing-indicator';
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from '@/components/ui/tooltip';

interface IntelligentAssistantProps {
  initialWelcomeMessage?: string;
  className?: string;
}

export default function IntelligentAssistant({
  initialWelcomeMessage = "Hi there! I'm your AI assistant. I can help with reminders, answer questions, or just chat. How can I assist you today?",
  className = ''
}: IntelligentAssistantProps) {
  // Chat and awareness state
  const chatDialog = useChatDialog();
  const ambientAwareness = useAmbientAwareness();
  const camera = useCamera();
  const microphone = useMicrophone();
  const { isListening, transcript, startListening, stopListening, clearTranscript, hasRecognitionSupport } = useSpeechRecognition();
  
  // UI state
  const [userInput, setUserInput] = useState('');
  const [showSettings, setShowSettings] = useState(false);
  const [isInitialized, setIsInitialized] = useState(false);
  const messagesEndRef = useRef<HTMLDivElement>(null);
  
  // Set up the speech recognition auto-restart control
  useEffect(() => {
    // @ts-ignore - Add our control variable to the window
    window.shouldAutoRestart = true;
    
    return () => {
      // @ts-ignore - Clean up on unmount
      window.shouldAutoRestart = false;
    };
  }, []);
  
  // Initialize with welcome message and activate automatic mode
  useEffect(() => {
    if (!isInitialized && initialWelcomeMessage) {
      // Start in auto mode
      if (!ambientAwareness.autoMode) {
        ambientAwareness.toggleAutoMode();
      }
      
      // Activate ambient awareness
      if (!ambientAwareness.isActive) {
        ambientAwareness.toggleAmbientAwareness();
      }
      
      // Initialize camera if available
      if (!camera.cameraEnabled) {
        camera.toggleCamera();
      }
      
      // Set up auto-restart for speech
      // @ts-ignore - Control variable for speech recognition
      window.shouldAutoRestart = true;
      
      // Give a moment for things to initialize before starting speech
      setTimeout(() => {
        // Start listening
        if (!isListening && hasRecognitionSupport) {
          startListening();
        }
        
        // Add initial welcome message 
        chatDialog.addUserMessage("Hello");
      }, 600);
      
      setIsInitialized(true);
    }
  }, [isInitialized, initialWelcomeMessage, chatDialog, ambientAwareness, 
      isListening, hasRecognitionSupport, startListening, camera]);
  
  // Submit user input
  const handleSubmit = async () => {
    if (!userInput.trim()) return;
    
    // Reset idle timer on user interaction
    ambientAwareness.resetIdleTimer();
    
    // Submit the message
    await chatDialog.addUserMessage(userInput);
    setUserInput('');
  };
  
  // Handle speech transcript when it changes - completely rewritten for stability
  useEffect(() => {
    // Skip empty transcripts
    if (!transcript || transcript.trim() === '') {
      return;
    }
    
    console.log("Processing transcript:", transcript);
    
    // Set the input field for display
    setUserInput(transcript);
    
    // Process text for emotion detection
    ambientAwareness.processText(transcript);
    
    // In auto mode, submit automatically after a short delay
    if (ambientAwareness.autoMode) {
      const timeoutId = setTimeout(() => {
        handleSubmit();
        // Clear the transcript after processing to prevent repeats
        clearTranscript();
      }, 1000);
      
      return () => clearTimeout(timeoutId);
    }
  }, [transcript, ambientAwareness, handleSubmit, clearTranscript]);
  
  // Check for periodic proactive responses
  useEffect(() => {
    if (!ambientAwareness.autoMode) return;
    
    const proactiveInterval = setInterval(() => {
      const proactiveMessage = ambientAwareness.generateProactiveResponse();
      
      if (proactiveMessage && !chatDialog.isTyping) {
        // Send the proactive message as if it's from the assistant
        chatDialog.addUserMessage("What's on your mind?");
      }
    }, 60000); // Check once per minute
    
    return () => clearInterval(proactiveInterval);
  }, [ambientAwareness, chatDialog]);
  
  // Auto-scroll to bottom when messages change
  useEffect(() => {
    if (messagesEndRef.current) {
      messagesEndRef.current.scrollIntoView({ behavior: 'smooth' });
    }
  }, [chatDialog.messages]);
  
  // Handle camera/microphone UI
  const handleCameraToggle = () => {
    camera.toggleCamera();
  };
  
  const handleMicrophoneToggle = () => {
    // First turn off auto-restart while we toggle
    // @ts-ignore - Control speech recognition behavior
    window.shouldAutoRestart = false;
    
    // Always stop first to reset any state
    stopListening();
    
    // If we were not listening, start after a brief delay
    if (!isListening) {
      setTimeout(() => {
        // Enable auto-restart again
        // @ts-ignore - Control speech recognition behavior
        window.shouldAutoRestart = true;
        
        // Start fresh
        startListening();
      }, 100);
    }
  };
  
  // Handle key press (Enter to submit)
  const handleKeyPress = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      handleSubmit();
    }
  };
  
  return (
    <div className={`flex flex-col h-full ${className}`}>
      {/* Assistant Header */}
      <header className="bg-primary/10 px-4 py-3 border-b flex items-center justify-between">
        <div className="flex items-center space-x-3">
          <div className="bg-primary/20 p-2 rounded-full">
            <BrainCircuit className="w-6 h-6 text-primary" />
          </div>
          <div>
            <h2 className="font-semibold">AI Assistant</h2>
            <p className="text-xs text-muted-foreground">
              {ambientAwareness.autoMode ? 'Auto Mode' : 'Manual Mode'} • 
              {ambientAwareness.isActive ? ' Ambient Aware' : ' Standard Mode'}
            </p>
          </div>
        </div>
        
        <div className="flex items-center space-x-2">
          <TooltipProvider>
            <Tooltip>
              <TooltipTrigger asChild>
                <Button 
                  variant="ghost" 
                  size="icon"
                  className={`${ambientAwareness.autoMode ? 'bg-primary/20' : ''}`}
                  onClick={() => ambientAwareness.toggleAutoMode()}
                >
                  <Eye className={`w-5 h-5 ${ambientAwareness.autoMode ? 'text-primary' : 'text-muted-foreground'}`} />
                </Button>
              </TooltipTrigger>
              <TooltipContent>
                <p>{ambientAwareness.autoMode ? 'Disable' : 'Enable'} Automatic Mode</p>
              </TooltipContent>
            </Tooltip>
          </TooltipProvider>
          
          <TooltipProvider>
            <Tooltip>
              <TooltipTrigger asChild>
                <Button 
                  variant="ghost" 
                  size="icon"
                  className={`${camera.cameraEnabled ? 'bg-primary/20' : ''}`}
                  onClick={handleCameraToggle}
                >
                  {camera.cameraEnabled ? (
                    <Camera className="w-5 h-5 text-primary" />
                  ) : (
                    <CameraOff className="w-5 h-5 text-muted-foreground" />
                  )}
                </Button>
              </TooltipTrigger>
              <TooltipContent>
                <p>{camera.cameraEnabled ? 'Disable' : 'Enable'} Camera</p>
              </TooltipContent>
            </Tooltip>
          </TooltipProvider>
          
          <TooltipProvider>
            <Tooltip>
              <TooltipTrigger asChild>
                <Button 
                  variant="ghost" 
                  size="icon"
                  className={`${isListening ? 'bg-primary/20' : ''}`}
                  onClick={handleMicrophoneToggle}
                >
                  {isListening ? (
                    <Mic className="w-5 h-5 text-primary" />
                  ) : (
                    <MicOff className="w-5 h-5 text-muted-foreground" />
                  )}
                </Button>
              </TooltipTrigger>
              <TooltipContent>
                <p>{isListening ? 'Stop' : 'Start'} Listening</p>
              </TooltipContent>
            </Tooltip>
          </TooltipProvider>
          
          <TooltipProvider>
            <Tooltip>
              <TooltipTrigger asChild>
                <Button 
                  variant="ghost" 
                  size="icon"
                  onClick={() => setShowSettings(!showSettings)}
                >
                  <Settings className="w-5 h-5 text-muted-foreground" />
                </Button>
              </TooltipTrigger>
              <TooltipContent>
                <p>Assistant Settings</p>
              </TooltipContent>
            </Tooltip>
          </TooltipProvider>
        </div>
      </header>
      
      {/* Settings Panel */}
      <AnimatePresence>
        {showSettings && (
          <motion.div
            initial={{ height: 0, opacity: 0 }}
            animate={{ height: 'auto', opacity: 1 }}
            exit={{ height: 0, opacity: 0 }}
            transition={{ duration: 0.2 }}
            className="overflow-hidden"
          >
            <Card className="m-4 border rounded-lg shadow-sm">
              <CardHeader className="pb-2">
                <CardTitle>Assistant Settings</CardTitle>
                <CardDescription>Configure how your AI assistant works</CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div className="flex items-center justify-between">
                    <div className="space-y-0.5">
                      <Label htmlFor="auto-mode">Automatic Mode</Label>
                      <p className="text-xs text-muted-foreground">Assistant will respond proactively</p>
                    </div>
                    <Switch 
                      id="auto-mode" 
                      checked={ambientAwareness.autoMode}
                      onCheckedChange={ambientAwareness.toggleAutoMode}
                    />
                  </div>
                  
                  <div className="flex items-center justify-between">
                    <div className="space-y-0.5">
                      <Label htmlFor="ambient-awareness">Ambient Awareness</Label>
                      <p className="text-xs text-muted-foreground">Respond to environment changes</p>
                    </div>
                    <Switch 
                      id="ambient-awareness" 
                      checked={ambientAwareness.isActive}
                      onCheckedChange={ambientAwareness.toggleAmbientAwareness}
                    />
                  </div>
                  
                  <div className="flex items-center justify-between">
                    <div className="space-y-0.5">
                      <Label htmlFor="emotion-detection">Emotion Detection</Label>
                      <p className="text-xs text-muted-foreground">Adapt to your emotional state</p>
                    </div>
                    <Switch 
                      id="emotion-detection" 
                      checked={ambientAwareness.settings.ambientEmotionDetection}
                      onCheckedChange={(checked) => 
                        ambientAwareness.updateSetting('ambientEmotionDetection', checked)
                      }
                    />
                  </div>
                  
                  <div className="flex items-center justify-between">
                    <div className="space-y-0.5">
                      <Label htmlFor="idle-responses">Idle Responses</Label>
                      <p className="text-xs text-muted-foreground">Respond during periods of inactivity</p>
                    </div>
                    <Switch 
                      id="idle-responses" 
                      checked={ambientAwareness.settings.idleResponses}
                      onCheckedChange={(checked) => 
                        ambientAwareness.updateSetting('idleResponses', checked)
                      }
                    />
                  </div>
                </div>
              </CardContent>
            </Card>
          </motion.div>
        )}
      </AnimatePresence>
      
      {/* Chat Messages */}
      <div className="flex-1 overflow-y-auto p-4 space-y-4">
        {chatDialog.messages.map((message) => (
          <div 
            key={message.id}
            className={`flex ${message.role === 'user' ? 'justify-end' : 'justify-start'}`}
          >
            <div 
              className={`max-w-[80%] px-4 py-3 rounded-lg ${
                message.role === 'user' 
                  ? 'bg-primary text-primary-foreground rounded-tr-none' 
                  : 'bg-muted rounded-tl-none'
              }`}
            >
              {message.role === 'assistant' ? (
                <AnimatedResponse
                  content={message.content}
                  isLoading={false}
                  typingSpeed="normal"
                />
              ) : (
                <p>{message.content}</p>
              )}
            </div>
          </div>
        ))}
        
        {/* Typing indicator */}
        {chatDialog.isTyping && (
          <div className="flex justify-start">
            <TypingIndicator isTyping={true} />
          </div>
        )}
        
        {/* Auto-scroll anchor */}
        <div ref={messagesEndRef} />
      </div>
      
      {/* Status Indicators */}
      {ambientAwareness.isActive && (
        <div className="px-4 py-1 bg-background border-t text-xs flex items-center justify-between text-muted-foreground">
          <div className="flex items-center space-x-4">
            {ambientAwareness.detectedEmotion && (
              <div className="flex items-center">
                <span>Emotion: {ambientAwareness.detectedEmotion}</span>
              </div>
            )}
            
            {isListening && (
              <div className="flex items-center">
                <Mic className="w-3 h-3 mr-1 text-green-500" />
                <span>Listening...</span>
              </div>
            )}
          </div>
          
          {ambientAwareness.autoMode && (
            <span>Auto-mode active</span>
          )}
        </div>
      )}
      
      {/* Input Area */}
      <div className="border-t p-4">
        <div className="flex space-x-2">
          <textarea
            className="flex-1 min-h-[60px] p-3 rounded-lg border focus:ring-1 focus:ring-primary focus:border-primary outline-none resize-none"
            placeholder={
              ambientAwareness.autoMode 
                ? "I'm listening automatically. Just speak naturally..." 
                : "Type a message..."
            }
            value={userInput}
            onChange={(e) => setUserInput(e.target.value)}
            onKeyDown={handleKeyPress}
          />
          <Button 
            onClick={handleSubmit}
            disabled={!userInput.trim() || chatDialog.isTyping}
          >
            Send
          </Button>
        </div>
      </div>
    </div>
  );
}