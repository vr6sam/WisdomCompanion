import { useState, useEffect } from 'react';
import { motion } from 'framer-motion';

interface TypingIndicatorProps {
  isTyping: boolean;
  messageComplexity?: 'simple' | 'moderate' | 'complex';
  typingSpeed?: 'slow' | 'normal' | 'fast';
}

export default function TypingIndicator({ 
  isTyping, 
  messageComplexity = 'moderate',
  typingSpeed = 'normal'
}: TypingIndicatorProps) {
  const [dotCount, setDotCount] = useState(0);
  const [thinkingText, setThinkingText] = useState<string | null>(null);
  
  // Calculate typing duration based on complexity and speed
  const getTypingDuration = () => {
    // Base duration in milliseconds
    const baseTime = {
      simple: 1500,
      moderate: 3000,
      complex: 6000
    }[messageComplexity];
    
    // Apply speed modifier
    const speedModifier = {
      slow: 1.5,
      normal: 1,
      fast: 0.7
    }[typingSpeed];
    
    // Add some randomness
    const randomFactor = 0.8 + (Math.random() * 0.4); // Between 0.8 and 1.2
    
    return baseTime * speedModifier * randomFactor;
  };
  
  // Animate the thinking dots
  useEffect(() => {
    if (!isTyping) {
      setDotCount(0);
      setThinkingText(null);
      return;
    }
    
    const interval = setInterval(() => {
      setDotCount((prev) => (prev + 1) % 4);
    }, 400);
    
    return () => clearInterval(interval);
  }, [isTyping]);
  
  // Show different thinking states for longer messages
  useEffect(() => {
    if (!isTyping) {
      setThinkingText(null);
      return;
    }
    
    // For complex messages, show thoughtful "thinking" states
    if (messageComplexity === 'complex') {
      const thinkingStates = [
        "Hmm",
        "Thinking",
        "Let me see",
        "Processing",
        "One moment",
        "Analyzing"
      ];
      
      // Initial thinking text
      setThinkingText(thinkingStates[Math.floor(Math.random() * thinkingStates.length)]);
      
      // Maybe change the thinking text after some time
      const changeThinkingText = setTimeout(() => {
        if (Math.random() > 0.5) { // 50% chance to change the message
          const newThinkingText = thinkingStates[Math.floor(Math.random() * thinkingStates.length)];
          setThinkingText(newThinkingText);
        }
      }, 2000);
      
      return () => clearTimeout(changeThinkingText);
    }
  }, [isTyping, messageComplexity]);
  
  if (!isTyping) return null;
  
  return (
    <div className="flex items-center space-x-2 text-muted-foreground text-sm px-3 py-2 rounded-lg max-w-[80%] bg-accent/30">
      <motion.div 
        initial={{ opacity: 0, scale: 0.8 }}
        animate={{ opacity: 1, scale: 1 }}
        transition={{ duration: 0.3 }}
        className="flex items-center"
      >
        <span className="mr-2 text-xs opacity-80">
          {thinkingText || "Typing"}
        </span>
        <span className="flex space-x-1">
          {[0, 1, 2].map((_, i) => (
            <motion.span
              key={i}
              initial={{ y: 0 }}
              animate={{ 
                y: i < dotCount ? -3 : 0,
                opacity: i < dotCount ? 1 : 0.5
              }}
              transition={{ duration: 0.15 }}
              className="w-1.5 h-1.5 rounded-full bg-primary inline-block"
            />
          ))}
        </span>
      </motion.div>
    </div>
  );
}