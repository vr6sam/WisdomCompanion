import React, { useState, useEffect, useRef } from 'react';
import { useToast } from '@/hooks/use-toast';
import { useCamera } from '@/hooks/use-camera';
import { useChatDialog } from '@/hooks/use-chat-dialog';
import { transcribeAudio } from '@/lib/openai';
import { TypingIndicator } from '@/components/ui/typing-indicator';
import AnimatedResponse from '@/components/AnimatedResponse';
import { Button } from '@/components/ui/button';
import { Mic, MicOff, Camera, CameraOff, Brain, Volume2, VolumeX } from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';

interface HandsFreeAIAssistantProps {
  autoActivate?: boolean;
  initialPrompt?: string;
}

export default function HandsFreeAIAssistant({ 
  autoActivate = true,
  initialPrompt = "Hi there! I'm your AI assistant. How can I help you today?"
}: HandsFreeAIAssistantProps) {
  // State for audio recording
  const [isListening, setIsListening] = useState(false);
  const [audioStream, setAudioStream] = useState<MediaStream | null>(null);
  const [mediaRecorder, setMediaRecorder] = useState<MediaRecorder | null>(null);
  const [isProcessingAudio, setIsProcessingAudio] = useState(false);
  const [audioEnabled, setAudioEnabled] = useState(autoActivate);
  const [speakerEnabled, setSpeakerEnabled] = useState(true);
  
  // State for voice activity detection
  const [volumeLevel, setVolumeLevel] = useState(0);
  const [isSpeaking, setIsSpeaking] = useState(false);
  const [silenceTimer, setSilenceTimer] = useState<number | null>(null);
  
  // Camera for emotion detection
  const { cameraEnabled, cameraStream, toggleCamera } = useCamera();
  const videoRef = useRef<HTMLVideoElement | null>(null);
  
  // Chat state
  const {
    messages,
    isTyping,
    typingComplexity,
    currentEmotion,
    addUserMessage,
  } = useChatDialog({
    typingSpeedFactor: 0.8 // Slightly faster typing for better responsiveness
  });
  
  const { toast } = useToast();
  const audioChunksRef = useRef<Blob[]>([]);
  const speechSynthesisRef = useRef<SpeechSynthesisUtterance | null>(null);
  const lastProcessedTextRef = useRef<string>('');
  const analyserRef = useRef<AnalyserNode | null>(null);
  const animationFrameRef = useRef<number | null>(null);
  
  // Load SpeechSynthesis voices
  const [voices, setVoices] = useState<SpeechSynthesisVoice[]>([]);
  const [selectedVoice, setSelectedVoice] = useState<SpeechSynthesisVoice | null>(null);
  
  // Initial message when component mounts
  useEffect(() => {
    if (initialPrompt) {
      setTimeout(() => {
        addUserMessage("Hello");
      }, 1000);
    }
  }, [initialPrompt, addUserMessage]);
  
  // Set up speech synthesis
  useEffect(() => {
    const loadVoices = () => {
      const availableVoices = window.speechSynthesis.getVoices();
      if (availableVoices.length > 0) {
        setVoices(availableVoices);
        
        // Try to find a natural-sounding female voice
        const preferredVoice = availableVoices.find(voice => 
          (voice.name.includes('Samantha') || 
           voice.name.includes('Female') || 
           voice.name.includes('Google UK English Female'))
        ) || availableVoices[0];
        
        setSelectedVoice(preferredVoice);
      }
    };
    
    // Load voices immediately and also when they change
    loadVoices();
    window.speechSynthesis.onvoiceschanged = loadVoices;
    
    return () => {
      window.speechSynthesis.onvoiceschanged = null;
    };
  }, []);
  
  // Handle camera feed for emotion detection
  useEffect(() => {
    if (videoRef.current && cameraStream) {
      videoRef.current.srcObject = cameraStream;
    }
  }, [cameraStream]);
  
  // Initialize or stop the audio system based on audioEnabled
  useEffect(() => {
    const setupAudio = async () => {
      if (audioEnabled) {
        try {
          const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
          setAudioStream(stream);
          
          // Setup Web Audio API for volume analysis
          const audioContext = new AudioContext();
          const source = audioContext.createMediaStreamSource(stream);
          const analyser = audioContext.createAnalyser();
          analyser.fftSize = 256;
          source.connect(analyser);
          analyserRef.current = analyser;
          
          // Monitor volume levels to detect speech
          const dataArray = new Uint8Array(analyser.frequencyBinCount);
          
          const checkVolume = () => {
            if (!analyserRef.current) return;
            
            analyserRef.current.getByteFrequencyData(dataArray);
            const average = dataArray.reduce((sum, value) => sum + value, 0) / dataArray.length;
            const normalized = Math.min(1, average / 128); // Normalize to 0-1
            setVolumeLevel(normalized);
            
            // Consider speaking if volume is above threshold
            if (normalized > 0.2) {
              setIsSpeaking(true);
              if (silenceTimer) {
                clearTimeout(silenceTimer);
                setSilenceTimer(null);
              }
              
              // Start recording if not already listening
              if (!isListening && !isProcessingAudio) {
                startListening();
              }
            } else if (isSpeaking) {
              // If user was speaking but now is quiet, start a silence timer
              if (!silenceTimer) {
                const timer = window.setTimeout(() => {
                  setIsSpeaking(false);
                  if (isListening) {
                    stopListening();
                  }
                }, 1500); // 1.5 seconds of silence before stopping
                setSilenceTimer(timer);
              }
            }
            
            animationFrameRef.current = requestAnimationFrame(checkVolume);
          };
          
          animationFrameRef.current = requestAnimationFrame(checkVolume);
          
        } catch (error) {
          console.error('Error accessing microphone:', error);
          toast({
            title: "Microphone access denied",
            description: "Please enable microphone access to use voice features.",
            variant: "destructive"
          });
          setAudioEnabled(false);
        }
      } else {
        // Clean up audio resources when disabled
        if (audioStream) {
          audioStream.getTracks().forEach(track => track.stop());
          setAudioStream(null);
        }
        
        if (mediaRecorder && mediaRecorder.state === 'recording') {
          mediaRecorder.stop();
          setMediaRecorder(null);
        }
        
        if (animationFrameRef.current) {
          cancelAnimationFrame(animationFrameRef.current);
          animationFrameRef.current = null;
        }
        
        setIsListening(false);
        audioChunksRef.current = [];
      }
    };
    
    setupAudio();
    
    // Cleanup function
    return () => {
      if (audioStream) {
        audioStream.getTracks().forEach(track => track.stop());
      }
      
      if (silenceTimer) {
        clearTimeout(silenceTimer);
      }
      
      if (animationFrameRef.current) {
        cancelAnimationFrame(animationFrameRef.current);
      }
    };
  }, [audioEnabled, toast]);
  
  // Start listening for voice input
  const startListening = () => {
    if (!audioStream || isProcessingAudio || isListening) return;
    
    try {
      const recorder = new MediaRecorder(audioStream);
      audioChunksRef.current = [];
      
      recorder.ondataavailable = (event) => {
        if (event.data.size > 0) {
          audioChunksRef.current.push(event.data);
        }
      };
      
      recorder.onstop = async () => {
        if (audioChunksRef.current.length === 0) return;
        
        setIsProcessingAudio(true);
        
        try {
          const audioBlob = new Blob(audioChunksRef.current, { type: 'audio/webm' });
          
          // Process the audio data to get text
          const transcribedText = await transcribeAudio(audioBlob);
          
          if (transcribedText && transcribedText.trim().length > 0 && 
              transcribedText !== lastProcessedTextRef.current) {
                
            lastProcessedTextRef.current = transcribedText;
            
            // Add the transcribed message to the chat
            addUserMessage(transcribedText);
          }
        } catch (error) {
          console.error('Error processing audio:', error);
          toast({
            title: "Couldn't process your voice",
            description: "There was a problem understanding what you said. Please try again.",
            variant: "destructive"
          });
        } finally {
          setIsProcessingAudio(false);
          audioChunksRef.current = [];
        }
      };
      
      recorder.start();
      setMediaRecorder(recorder);
      setIsListening(true);
      
    } catch (error) {
      console.error('Error starting voice recording:', error);
      setIsListening(false);
    }
  };
  
  // Stop listening for voice input
  const stopListening = () => {
    if (mediaRecorder && mediaRecorder.state === 'recording') {
      mediaRecorder.stop();
    }
    
    setIsListening(false);
  };
  
  // Toggle audio listening on/off
  const toggleAudio = () => {
    setAudioEnabled(prev => !prev);
  };
  
  // Toggle speaker output on/off
  const toggleSpeaker = () => {
    setSpeakerEnabled(prev => !prev);
    
    if (speakerEnabled && speechSynthesisRef.current) {
      window.speechSynthesis.cancel();
    }
  };
  
  // Speak the assistant's response using text-to-speech
  useEffect(() => {
    if (!speakerEnabled || !selectedVoice) return;
    
    // Get the latest assistant message
    const assistantMessages = messages.filter(m => m.role === 'assistant');
    if (assistantMessages.length === 0) return;
    
    const latestMessage = assistantMessages[assistantMessages.length - 1];
    
    // Don't re-speak the same message
    if (speechSynthesisRef.current?.text === latestMessage.content) return;
    
    // Stop any ongoing speech
    window.speechSynthesis.cancel();
    
    // Create a new speech synthesis utterance
    const utterance = new SpeechSynthesisUtterance(latestMessage.content);
    utterance.voice = selectedVoice;
    utterance.rate = 1.0;
    utterance.pitch = 1.1;
    utterance.volume = 1.0;
    
    // Adjust speech based on detected emotion
    if (currentEmotion) {
      switch (currentEmotion) {
        case 'happy':
          utterance.rate = 1.1;
          utterance.pitch = 1.2;
          break;
        case 'sad':
          utterance.rate = 0.9;
          utterance.pitch = 0.9;
          break;
        case 'angry':
          utterance.rate = 1.1;
          utterance.pitch = 1.0;
          break;
        case 'anxious':
          utterance.rate = 1.2;
          utterance.pitch = 1.1;
          break;
      }
    }
    
    speechSynthesisRef.current = utterance;
    window.speechSynthesis.speak(utterance);
    
  }, [messages, speakerEnabled, selectedVoice, currentEmotion]);
  
  return (
    <div className="flex flex-col h-full p-4 max-w-5xl mx-auto gap-4">
      {/* Status indicators and controls */}
      <div className="flex items-center justify-between bg-background/90 backdrop-blur-sm p-3 rounded-lg shadow-sm border">
        <div className="flex items-center space-x-3">
          <motion.div 
            className="flex items-center space-x-2 px-3 py-1.5 rounded-lg bg-primary/10"
            animate={{ 
              scale: isListening ? [1, 1.05, 1] : 1,
              opacity: isListening ? 1 : 0.7
            }}
            transition={{ repeat: isListening ? Infinity : 0, duration: 1.5 }}
          >
            {isListening ? (
              <Mic className="h-4 w-4 text-primary" />
            ) : (
              <MicOff className="h-4 w-4 text-muted-foreground" />
            )}
            <span className="text-sm font-medium">
              {isListening ? "Listening..." : "Voice inactive"}
            </span>
          </motion.div>
          
          {/* Volume level indicator */}
          {audioEnabled && (
            <div className="bg-secondary/20 rounded-full h-1.5 w-24 overflow-hidden">
              <motion.div 
                className="h-full bg-primary rounded-full"
                animate={{ width: `${volumeLevel * 100}%` }}
                transition={{ duration: 0.1 }}
              />
            </div>
          )}
          
          {/* Emotion status */}
          {currentEmotion && currentEmotion !== 'neutral' && (
            <div className="text-xs px-2 py-0.5 rounded-full bg-accent text-accent-foreground">
              Emotion: {currentEmotion}
            </div>
          )}
        </div>
        
        {/* Control buttons */}
        <div className="flex items-center space-x-2">
          <Button 
            variant="outline" 
            size="sm"
            className={cameraEnabled ? "bg-primary/10 text-primary" : ""}
            onClick={toggleCamera}
          >
            {cameraEnabled ? <Camera className="h-4 w-4" /> : <CameraOff className="h-4 w-4" />}
          </Button>
          
          <Button 
            variant="outline" 
            size="sm"
            className={audioEnabled ? "bg-primary/10 text-primary" : ""}
            onClick={toggleAudio}
          >
            {audioEnabled ? <Mic className="h-4 w-4" /> : <MicOff className="h-4 w-4" />}
          </Button>
          
          <Button 
            variant="outline" 
            size="sm"
            className={speakerEnabled ? "bg-primary/10 text-primary" : ""}
            onClick={toggleSpeaker}
          >
            {speakerEnabled ? <Volume2 className="h-4 w-4" /> : <VolumeX className="h-4 w-4" />}
          </Button>
        </div>
      </div>
      
      {/* Main conversation display */}
      <div className="flex-1 overflow-y-auto space-y-6 pb-4">
        {messages.map((message) => (
          <div 
            key={message.id}
            className={`flex ${message.role === 'user' ? 'justify-end' : 'justify-start'}`}
          >
            <div 
              className={`max-w-[80%] p-4 rounded-xl ${
                message.role === 'user' 
                  ? 'bg-primary text-primary-foreground rounded-tr-none' 
                  : 'bg-muted rounded-tl-none'
              }`}
            >
              {message.role === 'assistant' ? (
                <AnimatedResponse 
                  content={message.content}
                  isLoading={false}
                  typingSpeed="normal"
                />
              ) : (
                <div>{message.content}</div>
              )}
            </div>
          </div>
        ))}
        
        {/* Show typing indicator when the AI is thinking */}
        {isTyping && (
          <div className="flex justify-start">
            <TypingIndicator isTyping={true} />
          </div>
        )}
      </div>
      
      {/* Hidden video for emotion detection */}
      {cameraEnabled && (
        <video 
          ref={videoRef}
          autoPlay
          muted
          playsInline
          className="hidden"
        />
      )}
    </div>
  );
}