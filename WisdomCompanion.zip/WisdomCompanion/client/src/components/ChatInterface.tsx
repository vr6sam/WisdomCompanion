import { useState, useRef, useEffect } from "react";
import { Message } from "@shared/schema";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { TypingIndicator } from "@/components/ui/typing-indicator";
import { useSpeechRecognition } from "@/hooks/use-speech-recognition";
import { extractReminder } from "@/lib/openai";
import { useReminders } from "@/hooks/use-reminders";
import InfoCard from "@/components/cards/InfoCard";
import { getEmotionEmoji } from "@/lib/utils";

interface ChatInterfaceProps {
  messages: Message[];
  sendMessage: (message: string) => Promise<void>;
  isLoading: boolean;
  cameraEnabled: boolean;
  microphoneEnabled: boolean;
  currentEmotion: string;
  onCameraToggle: () => void;
  onMicrophoneToggle: () => void;
}

export default function ChatInterface({
  messages,
  sendMessage,
  isLoading,
  cameraEnabled,
  microphoneEnabled,
  currentEmotion,
  onCameraToggle,
  onMicrophoneToggle
}: ChatInterfaceProps) {
  // Form state
  const [inputMessage, setInputMessage] = useState("");
  const [sentiment, setSentiment] = useState("neutral");
  const messagesEndRef = useRef<HTMLDivElement>(null);
  const { addReminder } = useReminders(1);

  const {
    isListening,
    transcript,
    startListening,
    stopListening,
    hasRecognitionSupport
  } = useSpeechRecognition();

  // Set input message from speech recognition
  useEffect(() => {
    if (transcript) {
      setInputMessage(transcript);
    }
  }, [transcript]);

  // Scroll to bottom when messages change
  useEffect(() => {
    scrollToBottom();
  }, [messages]);

  // Auto-detect sentiment based on input
  useEffect(() => {
    if (inputMessage.length > 10) {
      // Simple sentiment detection (would be more sophisticated in a real app)
      if (inputMessage.match(/love|happy|great|excited|thank|appreciate/i)) {
        setSentiment("positive");
      } else if (inputMessage.match(/sad|upset|angry|frustrat|annoyed|hate|dislike/i)) {
        setSentiment("negative");
      } else {
        setSentiment("neutral");
      }
    } else {
      setSentiment("neutral");
    }
  }, [inputMessage]);

  // Scroll to bottom of messages
  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  };

  // Handle form submit
  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (inputMessage.trim() && !isLoading) {
      const message = inputMessage;
      setInputMessage("");
      await sendMessage(message);
    }
  };

  // Handle voice input
  const handleVoiceInput = () => {
    if (isListening) {
      stopListening();
    } else {
      startListening();
    }
  };

  // Handle copy response
  const handleCopyResponse = (content: string) => {
    navigator.clipboard.writeText(content)
      .then(() => {
        alert("Copied to clipboard!");
      })
      .catch(err => {
        console.error('Failed to copy: ', err);
      });
  };

  // Handle regenerate response
  const handleRegenerateResponse = async () => {
    // Find the last user message and resend it
    const lastUserMessage = [...messages].reverse().find(msg => msg.role === "user");
    if (lastUserMessage) {
      await sendMessage(lastUserMessage.content);
    }
  };

  // Extract and create reminders if mentioned in AI messages
  useEffect(() => {
    if (messages.length > 0) {
      const lastMessage = messages[messages.length - 1];
      if (lastMessage.role === "assistant") {
        const reminder = extractReminder(lastMessage.content);
        if (reminder) {
          addReminder({
            userId: 1,
            title: reminder.title,
            dueDate: reminder.dueDate,
            completed: false
          });
        }
      }
    }
  }, [messages]);

  // Render chat messages
  const renderMessages = () => {
    return messages.map((message, index) => {
      if (message.role === "user") {
        return (
          <div key={index} className="flex items-start space-x-2 flex-row-reverse max-w-3xl ml-auto">
            <div className="w-8 h-8 rounded-full bg-neutral-200 overflow-hidden flex-shrink-0 mt-1">
              <div className="w-full h-full flex items-center justify-center text-neutral-600">
                <i className="ri-user-line"></i>
              </div>
            </div>
            <div className="bg-primary rounded-t-2xl rounded-bl-2xl rounded-br-lg p-4 text-white">
              <p className="leading-relaxed">{message.content}</p>
            </div>
          </div>
        );
      } else {
        return (
          <div key={index} className="flex items-start space-x-2 max-w-3xl">
            <div className="w-8 h-8 rounded-full flex items-center justify-center bg-primary-100 text-primary flex-shrink-0 mt-1">
              <i className="ri-robot-line"></i>
            </div>
            <div className="flex flex-col space-y-2 flex-1">
              <div className="bg-neutral-100 rounded-t-2xl rounded-br-2xl rounded-bl-lg p-4 text-neutral-800">
                <div className="leading-relaxed whitespace-pre-wrap">
                  {renderMessageContent(message.content)}
                </div>
              </div>
              <div className="flex items-center space-x-3">
                <button 
                  className="text-xs text-neutral-500 hover:text-neutral-700"
                  onClick={() => handleRegenerateResponse()}
                >
                  <i className="ri-restart-line mr-1"></i> Regenerate
                </button>
                <button 
                  className="text-xs text-neutral-500 hover:text-neutral-700"
                  onClick={() => handleCopyResponse(message.content)}
                >
                  <i className="ri-file-copy-line mr-1"></i> Copy
                </button>
              </div>
            </div>
          </div>
        );
      }
    });
  };

  // Process message content for special formatting
  const renderMessageContent = (content: string) => {
    // Check for reminder pattern
    const reminderMatch = content.match(/reminder.+?(at|on|for).+?(\d+:\d+|\d+\s*(am|pm))/i);
    
    if (reminderMatch) {
      const parts = content.split(reminderMatch[0]);
      const reminder = extractReminder(content);
      
      return (
        <>
          {parts[0]}
          
          {reminder && (
            <div className="bg-primary-50 border border-primary-200 rounded-lg p-3 my-3 flex items-center">
              <i className="ri-alarm-line text-lg text-primary mr-3"></i>
              <div className="flex-1">
                <p className="text-sm font-medium">{reminder.title}</p>
                <p className="text-xs text-neutral-500">
                  {reminder.dueDate.toLocaleDateString()} at {reminder.dueDate.toLocaleTimeString([], {hour: '2-digit', minute:'2-digit'})}
                </p>
              </div>
              <button className="text-xs text-primary-600 hover:text-primary-800 font-medium">
                Edit
              </button>
            </div>
          )}
          
          {parts[1] || ''}
        </>
      );
    }
    
    // Check for information patterns that could be presented as cards
    if (content.includes("benefits of") || content.includes("advantages of") || content.includes("reasons why")) {
      return <InfoCard content={content} />;
    }
    
    return content;
  };

  return (
    <div className="flex flex-col h-full bg-white">
      {/* Sensing Controls */}
      <div className="bg-white p-3 flex justify-between items-center border-b border-neutral-200">
        <div className="flex items-center space-x-4">
          <button
            type="button"
            className={`flex items-center px-3 py-1.5 rounded-full text-sm border transition-colors ${
              cameraEnabled
                ? "bg-primary text-white border-primary"
                : "border-neutral-300 hover:bg-neutral-50"
            }`}
            aria-label="Enable camera"
            onClick={onCameraToggle}
          >
            <i className="ri-camera-line mr-1.5"></i>
            <span>Camera</span>
          </button>
          <button
            type="button"
            className={`flex items-center px-3 py-1.5 rounded-full text-sm border transition-colors ${
              microphoneEnabled
                ? "bg-primary text-white border-primary"
                : "border-neutral-300 hover:bg-neutral-50"
            }`}
            aria-label="Enable microphone"
            onClick={onMicrophoneToggle}
          >
            <i className="ri-mic-line mr-1.5"></i>
            <span>Microphone</span>
          </button>
        </div>
        <div className="flex items-center space-x-2">
          <span className="text-xs text-neutral-500">Emotion:</span>
          <div className="bg-neutral-100 px-2 py-1 rounded-full text-xs flex items-center">
            <i className={`ri-emotion-${currentEmotion === 'happy' ? 'happy' : currentEmotion === 'sad' ? 'sad' : 'normal'}-line mr-1 ${
              currentEmotion === 'happy' ? 'text-green-500' : 
              currentEmotion === 'sad' ? 'text-blue-500' : 
              'text-neutral-500'
            }`}></i>
            <span>{currentEmotion ? currentEmotion.charAt(0).toUpperCase() + currentEmotion.slice(1) : 'Neutral'}</span>
          </div>
        </div>
      </div>

      {/* Chat Messages */}
      <div className="flex-1 overflow-y-auto p-4 space-y-6">
        {messages.length === 0 ? (
          <div className="flex flex-col items-center justify-center h-full text-center p-4">
            <div className="w-16 h-16 rounded-full bg-primary-50 flex items-center justify-center mb-4">
              <i className="ri-robot-line text-2xl text-primary"></i>
            </div>
            <h3 className="text-lg font-medium mb-2">Welcome to Intuitive AI</h3>
            <p className="text-neutral-600 max-w-md">
              I'm your emotionally intelligent assistant. Ask me anything, set reminders, or just chat about what's on your mind.
            </p>
          </div>
        ) : (
          renderMessages()
        )}
        
        {isLoading && (
          <div className="flex items-start space-x-2 max-w-3xl">
            <div className="w-8 h-8 rounded-full flex items-center justify-center bg-primary-100 text-primary flex-shrink-0 mt-1">
              <i className="ri-robot-line"></i>
            </div>
            <TypingIndicator />
          </div>
        )}
        
        <div ref={messagesEndRef} />
      </div>

      {/* Message Input */}
      <div className="p-3 border-t border-neutral-200 bg-white">
        <form onSubmit={handleSubmit} className="flex flex-col space-y-2">
          <div className="relative">
            <Textarea
              id="userInput"
              value={inputMessage}
              onChange={(e) => setInputMessage(e.target.value)}
              rows={2}
              placeholder="Ask me anything..."
              className="w-full pl-4 pr-12 py-3 border border-neutral-300 rounded-xl resize-none transition-all"
            />
            <Button
              type="submit"
              disabled={isLoading || !inputMessage.trim()}
              className="absolute right-2 bottom-2 p-2 bg-primary text-white rounded-lg hover:bg-primary/90"
              size="icon"
              aria-label="Send message"
            >
              <i className="ri-send-plane-fill"></i>
            </Button>
          </div>
          <div className="flex items-center justify-between text-xs text-neutral-500 px-1">
            <div className="flex space-x-3">
              <button
                type="button"
                className="hover:text-neutral-700"
                onClick={() => {
                  // Handle file attachment (not implemented)
                  alert("File attachment not implemented in this demo");
                }}
              >
                <i className="ri-attachment-2 mr-1"></i> Attach
              </button>
              {hasRecognitionSupport && (
                <button
                  type="button"
                  className={`hover:text-neutral-700 ${isListening ? 'text-primary' : ''}`}
                  onClick={handleVoiceInput}
                >
                  <i className={`ri-mic-line mr-1 ${isListening ? 'animate-pulse' : ''}`}></i> 
                  {isListening ? 'Listening...' : 'Voice'}
                </button>
              )}
            </div>
            <div>
              <span id="sentimentIndicator">
                <i className={`ri-emotion-line mr-1 ${
                  sentiment === 'positive' ? 'text-green-500' : 
                  sentiment === 'negative' ? 'text-red-500' : 
                  'text-neutral-500'
                }`}></i>
                <span>{
                  sentiment === 'positive' ? 'Positive tone' : 
                  sentiment === 'negative' ? 'Negative tone' : 
                  'Neutral tone'
                }</span>
              </span>
            </div>
          </div>
        </form>
      </div>
    </div>
  );
}
