import { useState } from "react";
import { Reminder } from "@shared/schema";
import { formatDateTime, getReminderIconByTitle } from "@/lib/utils";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Progress } from "@/components/ui/progress";
import { Link } from "wouter";

interface KnowledgePanelProps {
  reminders: Reminder[];
  environmentData: any;
  cameraEnabled: boolean;
  microphoneEnabled: boolean;
  currentTopic: string | null;
}

export default function KnowledgePanel({
  reminders,
  environmentData,
  cameraEnabled,
  microphoneEnabled,
  currentTopic
}: KnowledgePanelProps) {
  const [isExpanded, setIsExpanded] = useState(false);

  // Extract a topic from the last message
  const extractTopic = (text: string | null): string => {
    if (!text) return "General Conversation";
    
    // Try to identify common topics
    if (text.match(/exercise|workout|fitness|run|jog|gym/i)) {
      return "Exercise Benefits";
    } else if (text.match(/sleep|rest|nap|insomnia/i)) {
      return "Sleep Health";
    } else if (text.match(/diet|nutrition|food|eat|meal/i)) {
      return "Nutrition & Diet";
    } else if (text.match(/meditation|mindfulness|stress|anxiety|relax/i)) {
      return "Mindfulness & Stress Management";
    } else if (text.match(/work|career|job|profession/i)) {
      return "Career Development";
    } else {
      return "General Information";
    }
  };

  const topic = extractTopic(currentTopic);

  // Generate relevant topic content (simplified version)
  const getTopicContent = (topic: string) => {
    switch (topic) {
      case "Exercise Benefits":
        return {
          title: "Physical Activity Guidelines",
          description: "The CDC recommends at least 150 minutes of moderate-intensity aerobic activity per week, plus muscle-strengthening activities 2+ days per week.",
          image: "https://images.unsplash.com/photo-1571019613454-1cb2f99b2d8b?q=80&w=640&h=360&fit=crop&auto=format",
          stats: [
            { name: "Cardiovascular Benefits", value: 90, rating: "Very High" },
            { name: "Mental Health Benefits", value: 75, rating: "High" }
          ]
        };
      case "Sleep Health":
        return {
          title: "Healthy Sleep Patterns",
          description: "Adults should aim for 7-9 hours of quality sleep per night. Consistent sleep schedules help maintain your body's internal clock.",
          image: "https://images.unsplash.com/photo-1541781774459-bb2af2f05b55?q=80&w=640&h=360&fit=crop&auto=format",
          stats: [
            { name: "Cognitive Function", value: 85, rating: "High" },
            { name: "Physical Recovery", value: 80, rating: "High" }
          ]
        };
      case "Nutrition & Diet":
        return {
          title: "Balanced Diet Principles",
          description: "A balanced diet includes a variety of fruits, vegetables, lean proteins, whole grains, and healthy fats to provide essential nutrients.",
          image: "https://images.unsplash.com/photo-1512621776951-a57141f2eefd?q=80&w=640&h=360&fit=crop&auto=format",
          stats: [
            { name: "Energy Levels", value: 85, rating: "High" },
            { name: "Disease Prevention", value: 90, rating: "Very High" }
          ]
        };
      default:
        return {
          title: "General Wellbeing",
          description: "Overall wellbeing combines physical, mental, and social health factors that contribute to a balanced and fulfilling life.",
          image: "https://images.unsplash.com/photo-1506126613408-eca07ce68773?q=80&w=640&h=360&fit=crop&auto=format",
          stats: [
            { name: "Life Satisfaction", value: 70, rating: "Good" },
            { name: "Stress Management", value: 65, rating: "Moderate" }
          ]
        };
    }
  };

  const topicContent = getTopicContent(topic);

  return (
    <div className="flex flex-col h-full">
      <div className="p-4 border-b border-neutral-200 flex items-center justify-between">
        <h2 className="font-medium">Insights & Resources</h2>
        <button
          type="button"
          className="text-neutral-500 hover:text-neutral-700 p-1"
          onClick={() => setIsExpanded(!isExpanded)}
        >
          <i className={`ri-${isExpanded ? 'fullscreen-exit' : 'fullscreen'}-line`}></i>
        </button>
      </div>

      <div className="flex-1 overflow-y-auto p-4 space-y-4">
        {/* Current Topic */}
        <Card className="overflow-hidden">
          <CardHeader className="p-3 bg-neutral-50 border-b border-neutral-200">
            <CardTitle className="font-medium text-sm">Current Topic: {topic}</CardTitle>
          </CardHeader>
          <CardContent className="p-4">
            <div className="aspect-w-16 aspect-h-9 bg-neutral-200 rounded-lg mb-4 overflow-hidden">
              <img 
                src={topicContent.image} 
                alt={topicContent.title} 
                className="object-cover w-full h-full" 
              />
            </div>

            <h3 className="font-medium mb-2">{topicContent.title}</h3>
            <p className="text-sm text-neutral-600 mb-3">{topicContent.description}</p>

            {topicContent.stats.map((stat, index) => (
              <div key={index} className="space-y-2 mb-3">
                <div className="flex items-center justify-between text-sm">
                  <span className="text-neutral-600">{stat.name}</span>
                  <span className="text-secondary-500 font-medium">{stat.rating}</span>
                </div>
                <Progress value={stat.value} className="h-1.5" />
              </div>
            ))}

            <div className="mt-4">
              <button className="text-sm text-primary-600 hover:text-primary-700 font-medium">
                View detailed research <i className="ri-external-link-line ml-1"></i>
              </button>
            </div>
          </CardContent>
        </Card>

        {/* Reminders Section */}
        <Card className="overflow-hidden">
          <CardHeader className="p-3 bg-neutral-50 border-b border-neutral-200 flex-row justify-between items-center">
            <CardTitle className="font-medium text-sm">Your Reminders</CardTitle>
            <Link to="/reminders" className="text-primary-500 text-xs hover:text-primary-600">
              See all
            </Link>
          </CardHeader>
          <CardContent className="p-2">
            {reminders.length === 0 ? (
              <div className="text-center py-4 text-sm text-neutral-500">
                <i className="ri-calendar-line block text-xl mb-2"></i>
                No reminders set
              </div>
            ) : (
              reminders.slice(0, 3).map((reminder) => (
                <div key={reminder.id} className="p-2 hover:bg-neutral-50 rounded-lg flex items-center space-x-3 cursor-pointer">
                  <div className="bg-primary-100 text-primary-500 rounded-full p-2 flex-shrink-0">
                    <i className={getReminderIconByTitle(reminder.title)}></i>
                  </div>
                  <div className="flex-1">
                    <p className="text-sm font-medium">{reminder.title}</p>
                    <p className="text-xs text-neutral-500">{formatDateTime(reminder.dueDate)}</p>
                  </div>
                  <button className="text-neutral-400 hover:text-neutral-600 p-1">
                    <i className="ri-more-2-fill"></i>
                  </button>
                </div>
              ))
            )}
            <div className="flex justify-center p-2">
              <button className="flex items-center text-xs text-primary-500 hover:text-primary-600 py-1 px-3 rounded-full border border-primary-200 bg-primary-50">
                <i className="ri-add-line mr-1"></i> Add new reminder
              </button>
            </div>
          </CardContent>
        </Card>

        {/* Environmental Context */}
        <Card className="overflow-hidden">
          <CardHeader className="p-3 bg-neutral-50 border-b border-neutral-200">
            <CardTitle className="font-medium text-sm">Environmental Context</CardTitle>
          </CardHeader>
          <CardContent className="p-4 space-y-3 text-sm">
            {!cameraEnabled && !microphoneEnabled ? (
              <div className="text-center text-neutral-500 py-6">
                <i className="ri-eye-off-line text-2xl block mb-2"></i>
                <p>Enable camera and microphone to allow environmental sensing.</p>
                <button className="mt-2 text-xs text-primary-500 hover:text-primary-600 font-medium">
                  Learn how it works
                </button>
              </div>
            ) : (
              <div className="space-y-3">
                {environmentData && (
                  <>
                    <div className="flex items-center justify-between">
                      <span>Lighting</span>
                      <span className="text-secondary-500">{environmentData.lighting || "Unknown"}</span>
                    </div>
                    <div className="flex items-center justify-between">
                      <span>Background noise</span>
                      <span className={environmentData.noiseLevel === "Low" ? "text-secondary-500" : "text-yellow-500"}>
                        {environmentData.noiseLevel || "Unknown"}
                      </span>
                    </div>
                    <div className="flex items-center justify-between">
                      <span>Facial expression</span>
                      <span className="text-secondary-500">{environmentData.expression || "Unknown"}</span>
                    </div>
                  </>
                )}
                <div className="mt-3 text-xs text-neutral-500 text-center">
                  Environmental analysis active
                </div>
              </div>
            )}
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
