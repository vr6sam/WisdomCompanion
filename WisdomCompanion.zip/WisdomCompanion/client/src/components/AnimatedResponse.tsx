import React, { useState, useEffect, useRef } from 'react';

interface AnimatedResponseProps {
  content: string;
  isLoading: boolean;
  typingSpeed?: 'slow' | 'normal' | 'fast';
}

const AnimatedResponse: React.FC<AnimatedResponseProps> = ({
  content,
  isLoading,
  typingSpeed = 'normal'
}) => {
  const [displayedContent, setDisplayedContent] = useState('');
  const [isTyping, setIsTyping] = useState(false);
  const fullContentRef = useRef<string>('');
  const typeTimeoutRef = useRef<NodeJS.Timeout | null>(null);

  // Set typing speed in milliseconds
  const getTypingDelay = () => {
    switch (typingSpeed) {
      case 'slow': return 80;
      case 'fast': return 20;
      case 'normal':
      default: return 35;
    }
  };

  // Start/update typing animation when content changes
  useEffect(() => {
    if (content !== fullContentRef.current) {
      fullContentRef.current = content;
      setIsTyping(true);
      setDisplayedContent('');
      typeText();
    }

    return () => {
      if (typeTimeoutRef.current) {
        clearTimeout(typeTimeoutRef.current);
      }
    };
  }, [content]);

  const typeText = () => {
    const fullText = fullContentRef.current;
    const delay = getTypingDelay();

    let i = 0;
    const type = () => {
      if (i < fullText.length) {
        setDisplayedContent(fullText.slice(0, i + 1));
        i++;
        typeTimeoutRef.current = setTimeout(type, delay);
      } else {
        setIsTyping(false);
      }
    };

    type();
  };

  // Render the component
  return (
    <div>
      {displayedContent}
      {isTyping && <span className="animate-pulse">▋</span>}
    </div>
  );
};

export default AnimatedResponse;