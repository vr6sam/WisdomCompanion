import { useState, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from '@/components/ui/card';
import { Textarea } from '@/components/ui/textarea';
import { useToast } from '@/hooks/use-toast';
import { Badge } from '@/components/ui/badge';

interface AIAssistantProps {
  onMessageSend: (message: string) => Promise<string>;
  isListening?: boolean;
  onStartListening?: () => void;
  onStopListening?: () => void;
}

// Intent types and colors
const intentColors = {
  want: 'bg-blue-100 text-blue-800',
  need: 'bg-purple-100 text-purple-800',
  help: 'bg-green-100 text-green-800',
  problem: 'bg-red-100 text-red-800'
};

export function AIAssistant({ 
  onMessageSend, 
  isListening,
  onStartListening,
  onStopListening 
}: AIAssistantProps) {
  const [userInput, setUserInput] = useState('');
  const [aiResponse, setAIResponse] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [detectedIntents, setDetectedIntents] = useState<{
    type: 'want' | 'need' | 'help' | 'problem';
    description: string;
    urgency: 'low' | 'medium' | 'high';
  }[]>([]);
  
  const { toast } = useToast();

  // Function to detect intents client-side
  // This is for demo purposes - real detection happens on the server
  const detectIntents = (message: string) => {
    const intents = [];
    const messageLC = message.toLowerCase();
    
    // Want patterns
    if (messageLC.includes('i want') || messageLC.includes('i would like')) {
      intents.push({
        type: 'want' as const,
        description: 'Express desire',
        urgency: 'medium' as const
      });
    }
    
    // Need patterns
    if (messageLC.includes('i need') || messageLC.includes('need to')) {
      intents.push({
        type: 'need' as const,
        description: 'Express necessity',
        urgency: messageLC.includes('urgent') ? 'high' as const : 'medium' as const
      });
    }
    
    // Help patterns
    if (messageLC.includes('help') || messageLC.includes('assist')) {
      intents.push({
        type: 'help' as const,
        description: 'Request assistance',
        urgency: messageLC.includes('right now') ? 'high' as const : 'medium' as const
      });
    }
    
    // Problem patterns
    if (
      messageLC.includes('problem') || 
      messageLC.includes('issue') || 
      messageLC.includes('trouble') ||
      messageLC.includes("can't") ||
      messageLC.includes('difficult')
    ) {
      intents.push({
        type: 'problem' as const,
        description: 'Facing difficulties',
        urgency: messageLC.includes('emergency') ? 'high' as const : 'medium' as const
      });
    }
    
    return intents;
  };

  const handleSubmit = async () => {
    if (!userInput.trim()) return;
    
    try {
      setIsLoading(true);
      
      // Detect intents client-side for visualization
      const intents = detectIntents(userInput);
      setDetectedIntents(intents);
      
      // Send to server/AI
      const response = await onMessageSend(userInput);
      setAIResponse(response);
      
      // Logging for demo
      if (intents.length > 0) {
        console.log('Detected intents:', intents);
      }
      
      setUserInput('');
    } catch (error) {
      toast({
        title: 'Error',
        description: 'Failed to communicate with AI assistant',
        variant: 'destructive'
      });
      console.error(error);
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <Card className="w-full max-w-2xl mx-auto">
      <CardHeader>
        <CardTitle>AI Life Coach Assistant</CardTitle>
        <CardDescription>
          I'm here to help with your needs and solve your problems. Try phrases like "I need help with...", "I want to...", or describe a problem you're facing.
        </CardDescription>
      </CardHeader>
      
      <CardContent className="space-y-4">
        <div className="space-y-2">
          <label className="text-sm font-medium">Your Message</label>
          <Textarea
            placeholder="Type your message here..."
            className="min-h-[100px]"
            value={userInput}
            onChange={(e) => setUserInput(e.target.value)}
            disabled={isLoading}
          />
          
          {detectedIntents.length > 0 && (
            <div className="flex flex-wrap gap-2 mt-2">
              {detectedIntents.map((intent, idx) => (
                <Badge key={idx} variant="outline" className={intentColors[intent.type]}>
                  {intent.type.toUpperCase()} ({intent.urgency})
                </Badge>
              ))}
            </div>
          )}
        </div>
        
        {aiResponse && (
          <div className="space-y-2 p-4 bg-muted rounded-md">
            <h3 className="font-semibold">AI Response:</h3>
            <p className="whitespace-pre-wrap">{aiResponse}</p>
          </div>
        )}
      </CardContent>
      
      <CardFooter className="flex justify-between">
        <div className="flex gap-2">
          {onStartListening && onStopListening && (
            <Button
              variant="outline"
              onClick={isListening ? onStopListening : onStartListening}
            >
              {isListening ? 'Stop Listening' : 'Voice Input'}
            </Button>
          )}
        </div>
        
        <Button 
          onClick={handleSubmit} 
          disabled={isLoading || !userInput.trim()}
        >
          {isLoading ? 'Processing...' : 'Send Message'}
        </Button>
      </CardFooter>
    </Card>
  );
}