import React, { useState } from 'react';
import { 
  Card, 
  CardContent,
  CardDescription, 
  CardHeader, 
  CardTitle 
} from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Skeleton } from '@/components/ui/skeleton';
import { Badge } from '@/components/ui/badge';
import { AlertTriangle, CheckCircle, RefreshCw } from 'lucide-react';
import { useToast } from '@/hooks/use-toast';
import { useQuery } from '@tanstack/react-query';
import APIKeyConfigModal from './APIKeyConfigModal';

interface AIStatus {
  success: boolean;
  providers: {
    openai: boolean;
    anthropic: boolean;
  };
  hasWorkingProvider: boolean;
}

export function AIProviderStatus() {
  const [showAPIKeyModal, setShowAPIKeyModal] = useState(false);
  const { toast } = useToast();
  
  const { 
    data: status, 
    isLoading, 
    isError,
    refetch,
    isFetching
  } = useQuery({
    queryKey: ['ai-status'],
    queryFn: async () => {
      const response = await fetch('/api/ai-status');
      if (!response.ok) {
        throw new Error('Failed to fetch AI status');
      }
      return response.json() as Promise<AIStatus>;
    },
    refetchInterval: 1000 * 60 * 5, // Refetch every 5 minutes
  });

  const handleAddAPIKey = () => {
    setShowAPIKeyModal(true);
  };

  return (
    <React.Fragment>
      <Card>
        <CardHeader className="pb-3">
          <CardTitle className="text-sm font-medium">AI Provider Status</CardTitle>
          <CardDescription>
            Check status of connected AI services
          </CardDescription>
        </CardHeader>
        <CardContent>
          {isLoading ? (
            <div className="space-y-2">
              <Skeleton className="h-4 w-full" />
              <Skeleton className="h-4 w-full" />
            </div>
          ) : isError ? (
            <div className="text-center py-2">
              <AlertTriangle className="h-5 w-5 text-amber-500 mx-auto mb-2" />
              <p className="text-sm text-muted-foreground">Failed to load status</p>
              <Button 
                variant="ghost" 
                size="sm" 
                className="mt-2"
                onClick={() => refetch()}
                disabled={isFetching}
              >
                <RefreshCw className={`h-4 w-4 mr-2 ${isFetching ? 'animate-spin' : ''}`} />
                Retry
              </Button>
            </div>
          ) : (
            <div className="space-y-3">
              <div className="flex items-center justify-between">
                <div className="flex items-center space-x-2">
                  <span className="text-sm font-medium">OpenAI</span>
                  {status?.providers.openai ? (
                    <Badge variant="outline" className="bg-green-50 text-green-700 border-green-200">
                      <CheckCircle className="h-3 w-3 mr-1" /> Connected
                    </Badge>
                  ) : (
                    <Badge variant="outline" className="bg-red-50 text-red-700 border-red-200">
                      <AlertTriangle className="h-3 w-3 mr-1" /> Disconnected
                    </Badge>
                  )}
                </div>
                {!status?.providers.openai && (
                  <Button 
                    variant="ghost" 
                    size="sm"
                    onClick={handleAddAPIKey}
                  >
                    Add API Key
                  </Button>
                )}
              </div>

              <div className="flex items-center justify-between">
                <div className="flex items-center space-x-2">
                  <span className="text-sm font-medium">Anthropic</span>
                  {status?.providers.anthropic ? (
                    <Badge variant="outline" className="bg-green-50 text-green-700 border-green-200">
                      <CheckCircle className="h-3 w-3 mr-1" /> Connected
                    </Badge>
                  ) : (
                    <Badge variant="outline" className="bg-red-50 text-red-700 border-red-200">
                      <AlertTriangle className="h-3 w-3 mr-1" /> Disconnected
                    </Badge>
                  )}
                </div>
                {!status?.providers.anthropic && (
                  <Button 
                    variant="ghost" 
                    size="sm"
                    onClick={handleAddAPIKey}
                  >
                    Add API Key
                  </Button>
                )}
              </div>

              <div className="pt-2 text-xs text-muted-foreground">
                <p className="flex items-center">
                  <RefreshCw className={`h-3 w-3 mr-1 ${isFetching ? 'animate-spin' : ''}`} />
                  Status updated {isFetching ? 'now' : 'recently'}
                  <Button 
                    variant="ghost" 
                    size="sm" 
                    className="h-6 ml-auto"
                    onClick={() => refetch()}
                    disabled={isFetching}
                  >
                    Refresh
                  </Button>
                </p>
              </div>
            </div>
          )}
        </CardContent>
      </Card>
      
      <APIKeyConfigModal
        isOpen={showAPIKeyModal}
        onClose={() => setShowAPIKeyModal(false)}
      />
    </React.Fragment>
  );
}