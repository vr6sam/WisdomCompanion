import React, { useState, useEffect, useRef } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { 
  Mic, MicOff, MessageCircle, Brain, Settings, 
  RefreshCw, Info, AlertCircle, ThumbsUp, ThumbsDown 
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Switch } from '@/components/ui/switch';
import { Label } from '@/components/ui/label';
import { Card, CardHeader, CardTitle, CardDescription, CardContent, CardFooter } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Popover, PopoverContent, PopoverTrigger } from '@/components/ui/popover';
import { useEnhancedConversation } from '@/hooks/use-enhanced-conversation';
import { useCamera } from '@/hooks/use-camera';
import { useMicrophone } from '@/hooks/use-microphone';
import { useSpeechRecognition } from '@/hooks/use-speech-recognition';
import { useEmotionDetection } from '@/hooks/use-emotion-detection';
import AnimatedResponse from '@/components/AnimatedResponse';
import { TypingIndicator } from '@/components/ui/typing-indicator';
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from '@/components/ui/tooltip';

export default function EnhancedConversationAssistant() {
  const [userInput, setUserInput] = useState('');
  const [autoMode, setAutoMode] = useState(false);
  const [showCamera, setShowCamera] = useState(false);
  const [cameraEnabled, setCameraEnabled] = useState(false);
  const [microphoneEnabled, setMicrophoneEnabled] = useState(false);
  const [feedbackVisible, setFeedbackVisible] = useState(false);
  const [conversationContext, setConversationContext] = useState<string | null>(null);
  
  const messagesEndRef = useRef<HTMLDivElement>(null);
  
  // Initialize core hooks
  const chatDialog = useEnhancedConversation();
  const camera = useCamera();
  const microphone = useMicrophone();
  const emotionDetection = useEmotionDetection();
  
  // Handle speech recognition for hands-free interaction
  const { 
    transcript, 
    isListening, 
    startListening, 
    stopListening, 
    resetTranscript 
  } = useSpeechRecognition({
    continuous: true,
    onResult: (result: string) => {
      console.log('Processing transcript:', result);
      if (autoMode && result.trim()) {
        // Process speech input automatically when in auto mode
        processTextInput(result);
        resetTranscript();
      }
    }
  });
  
  // Process text input (from either typing or speech)
  const processTextInput = (text: string) => {
    if (!text.trim()) return;
    
    console.log('Processing text input:', text);
    chatDialog.addUserMessage(text);
    setUserInput('');
    
    // Reset any active feedback UI
    setFeedbackVisible(false);
  };
  
  // Handle form submission
  const handleSubmit = (e?: React.FormEvent) => {
    if (e) e.preventDefault();
    processTextInput(userInput);
  };
  
  // Handle Enter key press
  const handleKeyPress = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      handleSubmit();
    }
  };
  
  // Toggle microphone for voice input
  const toggleMicrophone = () => {
    if (isListening) {
      stopListening();
      setMicrophoneEnabled(false);
    } else {
      startListening();
      setMicrophoneEnabled(true);
    }
  };
  
  // Toggle camera for facial emotion detection
  const toggleCamera = () => {
    if (cameraEnabled) {
      camera.stopCamera();
      setCameraEnabled(false);
      setShowCamera(false);
    } else {
      // Ask for confirmation before starting camera
      if (window.confirm("Allow the assistant to access your camera for emotion detection?")) {
        camera.startCamera();
        setCameraEnabled(true);
        setShowCamera(true);
      }
    }
  };
  
  // Toggle automatic mode (hands-free)
  const toggleAutoMode = () => {
    const newMode = !autoMode;
    setAutoMode(newMode);
    
    if (newMode) {
      // Start microphone when entering auto mode
      if (!isListening) {
        startListening();
        setMicrophoneEnabled(true);
      }
    }
  };
  
  // Scroll to bottom when new messages are added
  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [chatDialog.messages, chatDialog.isTyping]);
  
  // Detect emotions using camera if enabled
  useEffect(() => {
    if (cameraEnabled && camera.imageData) {
      const detectEmotion = async () => {
        try {
          // Remove the data:image/jpeg;base64, prefix
          const base64Data = camera.imageData?.split(',')[1];
          if (base64Data && emotionDetection.modelsLoaded) {
            await emotionDetection.detectEmotion(base64Data);
          }
        } catch (error) {
          console.error('Error detecting emotion from camera:', error);
        }
      };
      
      // Run emotion detection every 3 seconds
      const interval = setInterval(detectEmotion, 3000);
      return () => clearInterval(interval);
    }
  }, [cameraEnabled, camera.imageData, emotionDetection]);
  
  // Show context information
  const showContext = () => {
    if (chatDialog.memoryContext) {
      const contextStr = `
        Topics: ${chatDialog.memoryContext.topInterests}
        Recent Emotions: ${chatDialog.memoryContext.recentEmotions}
        Upcoming Events: ${chatDialog.memoryContext.upcomingEvents}
        Stage: ${chatDialog.conversationStage}
      `;
      setConversationContext(contextStr);
    }
  };
  
  // Hide context information
  const hideContext = () => {
    setConversationContext(null);
  };
  
  // Render the component
  return (
    <div className="flex flex-col h-full bg-background rounded-lg border shadow-sm overflow-hidden">
      {/* Header Area */}
      <div className="border-b p-4">
        <div className="flex items-center justify-between">
          <div className="flex items-center space-x-2">
            <Brain className="h-6 w-6 text-primary" />
            <div>
              <h2 className="text-lg font-semibold">Enhanced AI Assistant</h2>
              <p className="text-sm text-muted-foreground">
                {chatDialog.inMaintenanceMode 
                  ? "Limited Mode - Some features unavailable" 
                  : "Emotional Intelligence Enabled"}
              </p>
            </div>
          </div>
          
          <div className="flex items-center space-x-2">
            <TooltipProvider>
              <Tooltip>
                <TooltipTrigger asChild>
                  <Button 
                    variant="outline" 
                    size="icon"
                    onClick={toggleMicrophone}
                    className={isListening ? "bg-green-100 text-green-700 border-green-300" : ""}
                  >
                    {isListening ? <Mic className="h-4 w-4" /> : <MicOff className="h-4 w-4" />}
                  </Button>
                </TooltipTrigger>
                <TooltipContent>
                  {isListening ? "Microphone active - Click to turn off" : "Turn on microphone"}
                </TooltipContent>
              </Tooltip>
            </TooltipProvider>
            
            <TooltipProvider>
              <Tooltip>
                <TooltipTrigger asChild>
                  <Button 
                    variant="outline" 
                    size="icon"
                    onClick={toggleCamera}
                    className={cameraEnabled ? "bg-blue-100 text-blue-700 border-blue-300" : ""}
                  >
                    {cameraEnabled ? 
                      <svg className="h-4 w-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 10l4.553-2.276A1 1 0 0121 8.618v6.764a1 1 0 01-1.447.894L15 14v-4z" />
                        <rect x="3" y="6" width="12" height="12" rx="2" ry="2" />
                      </svg> 
                      : 
                      <svg className="h-4 w-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 10l4.553-2.276A1 1 0 0121 8.618v6.764a1 1 0 01-1.447.894L15 14v-4z" />
                        <rect x="3" y="6" width="12" height="12" rx="2" ry="2" />
                        <line x1="3" y1="3" x2="21" y2="21" />
                      </svg>
                    }
                  </Button>
                </TooltipTrigger>
                <TooltipContent>
                  {cameraEnabled ? "Camera active - Click to turn off" : "Turn on camera for emotion detection"}
                </TooltipContent>
              </Tooltip>
            </TooltipProvider>
            
            <TooltipProvider>
              <Tooltip>
                <TooltipTrigger asChild>
                  <div className="flex items-center gap-1.5">
                    <Switch
                      checked={autoMode}
                      onCheckedChange={toggleAutoMode}
                      id="auto-mode"
                    />
                    <Label htmlFor="auto-mode" className="text-xs">Auto</Label>
                  </div>
                </TooltipTrigger>
                <TooltipContent>
                  {autoMode ? "Auto mode on - I'll respond to voice automatically" : "Turn on auto mode for hands-free conversation"}
                </TooltipContent>
              </Tooltip>
            </TooltipProvider>
          </div>
        </div>
      </div>
      
      {/* Camera View (if enabled) */}
      <AnimatePresence>
        {showCamera && (
          <motion.div
            initial={{ height: 0, opacity: 0 }}
            animate={{ height: 180, opacity: 1 }}
            exit={{ height: 0, opacity: 0 }}
            transition={{ duration: 0.3 }}
            className="overflow-hidden"
          >
            <Card className="m-4 overflow-hidden">
              <CardContent className="p-2">
                <div className="relative">
                  {camera.videoRef && (
                    <video
                      ref={camera.videoRef}
                      autoPlay
                      muted
                      className="w-full h-[160px] object-cover rounded-md"
                    />
                  )}
                  
                  <div className="absolute bottom-2 left-2">
                    {emotionDetection.currentEmotion && (
                      <Badge variant="secondary" className="bg-background/70 backdrop-blur-sm">
                        Emotion: {emotionDetection.currentEmotion}
                      </Badge>
                    )}
                  </div>
                </div>
              </CardContent>
            </Card>
          </motion.div>
        )}
      </AnimatePresence>
      
      {/* Chat Messages */}
      <div className="flex-1 overflow-y-auto p-4 space-y-4">
        {chatDialog.messages.map((message) => (
          <div 
            key={message.id}
            className={`flex ${message.role === 'user' ? 'justify-end' : 'justify-start'}`}
          >
            <div 
              className={`max-w-[80%] px-4 py-3 rounded-lg ${
                message.role === 'user' 
                  ? 'bg-primary text-primary-foreground rounded-tr-none' 
                  : 'bg-muted rounded-tl-none'
              } relative group`}
            >
              {message.role === 'assistant' ? (
                <>
                  <AnimatedResponse
                    content={message.content}
                    isLoading={false}
                    typingSpeed="normal"
                  />
                  
                  {/* Feedback buttons for assistant messages */}
                  <div className="absolute -bottom-8 right-0 opacity-0 group-hover:opacity-100 transition-opacity flex space-x-1">
                    <Button 
                      variant="ghost" 
                      size="icon" 
                      className="h-6 w-6 bg-background/90 shadow-sm hover:bg-background"
                      onClick={() => setFeedbackVisible(true)}
                    >
                      <ThumbsUp className="h-3 w-3" />
                    </Button>
                    <Button 
                      variant="ghost" 
                      size="icon" 
                      className="h-6 w-6 bg-background/90 shadow-sm hover:bg-background"
                      onClick={() => setFeedbackVisible(true)}
                    >
                      <ThumbsDown className="h-3 w-3" />
                    </Button>
                  </div>
                </>
              ) : (
                <p>{message.content}</p>
              )}
            </div>
          </div>
        ))}
        
        {/* Typing indicator */}
        {chatDialog.isTyping && (
          <div className="flex justify-start">
            <div className="bg-muted rounded-lg rounded-tl-none px-4 py-3">
              <TypingIndicator isTyping={true} />
            </div>
          </div>
        )}
        
        {/* Feedback panel if visible */}
        {feedbackVisible && (
          <div className="mx-auto max-w-md bg-card p-4 rounded-lg border shadow-md">
            <h4 className="font-medium mb-2">How was this response?</h4>
            <div className="flex space-x-2 mb-3">
              <Button 
                variant="outline" 
                size="sm"
                onClick={() => setFeedbackVisible(false)}
                className="bg-green-50 border-green-200 hover:bg-green-100 text-green-700"
              >
                <ThumbsUp className="h-3.5 w-3.5 mr-1" />
                Helpful
              </Button>
              <Button 
                variant="outline" 
                size="sm"
                onClick={() => setFeedbackVisible(false)}
                className="bg-red-50 border-red-200 hover:bg-red-100 text-red-700"
              >
                <ThumbsDown className="h-3.5 w-3.5 mr-1" />
                Not helpful
              </Button>
              <Button 
                variant="ghost" 
                size="sm"
                onClick={() => setFeedbackVisible(false)}
              >
                Dismiss
              </Button>
            </div>
          </div>
        )}
        
        {/* Context information if visible */}
        {conversationContext && (
          <div className="mx-auto max-w-md bg-card p-4 rounded-lg border shadow-md">
            <h4 className="font-medium mb-2 flex items-center">
              <Info className="h-4 w-4 mr-1" />
              Conversation Context
            </h4>
            <pre className="text-xs whitespace-pre-wrap">{conversationContext}</pre>
            <Button 
              variant="ghost" 
              size="sm"
              onClick={hideContext}
              className="mt-2"
            >
              Close
            </Button>
          </div>
        )}
        
        {/* Conversation stage badge */}
        <div className="flex justify-center">
          <Badge variant="outline" className="text-xs bg-background/80 backdrop-blur-sm">
            {chatDialog.conversationStage === 'greeting' && 'Starting conversation'}
            {chatDialog.conversationStage === 'discussion' && 'Active discussion'}
            {chatDialog.conversationStage === 'clarification' && 'Answering question'}
            {chatDialog.conversationStage === 'conclusion' && 'Wrapping up'}
            {chatDialog.conversationStage === 'idle' && 'Waiting for input'}
          </Badge>
        </div>
        
        {/* Auto-scroll anchor */}
        <div ref={messagesEndRef} />
      </div>
      
      {/* Status Bar */}
      <div className="px-4 py-1 bg-background border-t text-xs flex items-center justify-between text-muted-foreground">
        <div className="flex items-center space-x-4">
          {emotionDetection.currentEmotion && (
            <div className="flex items-center">
              <span>Emotion: {emotionDetection.currentEmotion}</span>
            </div>
          )}
          
          {isListening && (
            <div className="flex items-center">
              <Mic className="w-3 h-3 mr-1 text-green-500" />
              <span>Listening...</span>
            </div>
          )}
          
          {chatDialog.inMaintenanceMode && (
            <div className="flex items-center">
              <AlertCircle className="w-3 h-3 mr-1 text-amber-500" />
              <span>Limited Mode</span>
            </div>
          )}
        </div>
        
        <div>
          <Button 
            variant="ghost" 
            size="icon" 
            className="h-6 w-6" 
            onClick={showContext}
          >
            <Info className="h-3 w-3" />
          </Button>
        </div>
      </div>
      
      {/* Input Area */}
      <div className="border-t p-4">
        <form onSubmit={handleSubmit} className="flex space-x-2">
          <textarea
            className="flex-1 min-h-[60px] p-3 rounded-lg border focus:ring-1 focus:ring-primary focus:border-primary outline-none resize-none"
            placeholder={
              autoMode 
                ? "I'm listening automatically. Just speak naturally..." 
                : "Type a message..."
            }
            value={userInput}
            onChange={(e) => setUserInput(e.target.value)}
            onKeyDown={handleKeyPress}
            disabled={autoMode}
          />
          <Button 
            type="submit"
            disabled={(!userInput.trim() && !autoMode) || chatDialog.isTyping}
          >
            <MessageCircle className="h-4 w-4 mr-1" />
            Send
          </Button>
        </form>
        
        {/* Transcript preview when listening */}
        {isListening && transcript && (
          <div className="mt-2 p-2 bg-muted rounded text-sm text-muted-foreground">
            <p className="italic">
              {transcript.length > 100 ? transcript.substring(0, 100) + '...' : transcript}
            </p>
          </div>
        )}
      </div>
    </div>
  );
}