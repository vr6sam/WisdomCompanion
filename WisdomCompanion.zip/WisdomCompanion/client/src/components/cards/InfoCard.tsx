import { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";

interface InfoCardProps {
  content: string;
}

export default function InfoCard({ content }: InfoCardProps) {
  const [isCollapsed, setIsCollapsed] = useState(false);

  // Extract a title from the content
  const extractTitle = (text: string): string => {
    // Look for phrases like "benefits of X" or "advantages of X"
    const benefitsMatch = text.match(/benefits of ([^.,:]+)/i);
    const advantagesMatch = text.match(/advantages of ([^.,:]+)/i);
    const reasonsMatch = text.match(/reasons (?:why|to) ([^.,:]+)/i);
    
    if (benefitsMatch) {
      return `Benefits of ${benefitsMatch[1]}`;
    } else if (advantagesMatch) {
      return `Advantages of ${advantagesMatch[1]}`;
    } else if (reasonsMatch) {
      return `Reasons to ${reasonsMatch[1]}`;
    } else {
      // Fallback to first sentence
      const firstSentence = text.split(/[.!?]/).shift() || "";
      return firstSentence.length > 50 ? firstSentence.substring(0, 50) + "..." : firstSentence;
    }
  };

  // Extract bullet points from the content
  const extractBulletPoints = (text: string): string[] => {
    // Look for numbered points or bullet patterns
    const bulletPattern = /(?:^|\n)[-•*]\s+([^\n]+)/g;
    const numberedPattern = /(?:^|\n)\d+\.\s+([^\n]+)/g;
    
    const bulletPoints: string[] = [];
    let match;
    
    // Extract bullet points
    while ((match = bulletPattern.exec(text)) !== null) {
      bulletPoints.push(match[1].trim());
    }
    
    // Extract numbered points
    while ((match = numberedPattern.exec(text)) !== null) {
      bulletPoints.push(match[1].trim());
    }
    
    // If no bullet points found, try to extract sentences
    if (bulletPoints.length === 0) {
      const sentences = text.split(/[.!?]/).filter(s => s.trim().length > 0);
      // Take up to 5 sentences
      return sentences.slice(0, 5).map(s => s.trim());
    }
    
    return bulletPoints;
  };

  const title = extractTitle(content);
  const bulletPoints = extractBulletPoints(content);

  // Add appropriate icons based on the bullet point content
  const getIconForBulletPoint = (text: string): string => {
    const lowerText = text.toLowerCase();
    
    if (lowerText.includes("heart") || lowerText.includes("cardio") || lowerText.includes("blood")) {
      return "ri-heart-pulse-line";
    } else if (lowerText.includes("mental") || lowerText.includes("depression") || lowerText.includes("anxiety") || lowerText.includes("mood")) {
      return "ri-mental-health-line";
    } else if (lowerText.includes("sleep") || lowerText.includes("rest")) {
      return "ri-rest-time-line";
    } else if (lowerText.includes("weight") || lowerText.includes("fat") || lowerText.includes("body")) {
      return "ri-body-scan-line";
    } else if (lowerText.includes("brain") || lowerText.includes("cognitive") || lowerText.includes("memory")) {
      return "ri-brain-line";
    } else if (lowerText.includes("stress") || lowerText.includes("relax")) {
      return "ri-emotion-happy-line";
    } else if (lowerText.includes("immune") || lowerText.includes("disease")) {
      return "ri-virus-line";
    } else if (lowerText.includes("energy") || lowerText.includes("strength")) {
      return "ri-battery-charge-line";
    } else {
      return "ri-check-line";
    }
  };

  return (
    <Card className="border border-neutral-200 rounded-xl overflow-hidden shadow-sm mb-4">
      <CardHeader className="p-4 border-b border-neutral-200 bg-neutral-50 flex justify-between items-center flex-row">
        <CardTitle className="font-medium text-base">{title}</CardTitle>
        <button 
          className="text-neutral-400 hover:text-neutral-600"
          onClick={() => setIsCollapsed(!isCollapsed)}
        >
          <i className={`ri-arrow-${isCollapsed ? 'down' : 'up'}-s-line`}></i>
        </button>
      </CardHeader>
      
      {!isCollapsed && (
        <CardContent className="p-4">
          <ul className="space-y-2">
            {bulletPoints.map((point, index) => (
              <li key={index} className="flex items-start">
                <i className={`${getIconForBulletPoint(point)} text-secondary mt-0.5 mr-2`}></i>
                <span>{point}</span>
              </li>
            ))}
          </ul>
        </CardContent>
      )}
    </Card>
  );
}
