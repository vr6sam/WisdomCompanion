import { useState, useEffect, useRef } from 'react';
import { useCameraEnhanced } from '@/hooks/use-camera-enhanced';
import { useObjectRecognition } from '@/hooks/use-object-recognition';
import { useEnvironmentAnalysis, type EnvironmentContext } from '@/hooks/use-environment-analysis';
import { useUserAnalysis, type UserAnalysisResult } from '@/hooks/use-user-analysis';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Separator } from '@/components/ui/separator';
import { Progress } from '@/components/ui/progress';
import { 
  Camera, 
  CameraOff, 
  Eye, 
  EyeOff, 
  Lightbulb, 
  Home, 
  Smile, 
  Users, 
  AlertTriangle,
  Zap
} from 'lucide-react';

export interface VisualAwarenessProps {
  autoActivate?: boolean;
  onEnvironmentDetected?: (environment: EnvironmentContext) => void;
  onUserAnalyzed?: (userState: UserAnalysisResult) => void;
  onObjectsDetected?: (objects: string[]) => void;
}

export default function VisualAwareness({
  autoActivate = false,
  onEnvironmentDetected,
  onUserAnalyzed,
  onObjectsDetected
}: VisualAwarenessProps) {
  // Camera controls
  const { 
    videoRef, 
    cameraState, 
    toggleCamera, 
    captureFrame,
    setFrameProcessor,
    clearFrameProcessor
  } = useCameraEnhanced({
    autoStart: autoActivate,
    captureInterval: 5000 // Capture every 5 seconds for automatic analysis
  });
  
  // Analysis hooks
  const { 
    objects, 
    sceneDescription, 
    recognizeObjects 
  } = useObjectRecognition();
  
  const { 
    environmentContext, 
    analyzeFromImage 
  } = useEnvironmentAnalysis();
  
  const { 
    currentEmotion, 
    attentionLevel, 
    posture,
    analyzeUser
  } = useUserAnalysis();
  
  // Component state
  const [isAnalyzing, setIsAnalyzing] = useState(false);
  const [analyzeInterval, setAnalyzeInterval] = useState<NodeJS.Timeout | null>(null);
  const [automaticAnalysis, setAutomaticAnalysis] = useState(autoActivate);
  const lastAnalysisTime = useRef<Date | null>(null);
  
  // Calculate time since last analysis
  const timeSinceLastAnalysis = lastAnalysisTime.current 
    ? Math.floor((new Date().getTime() - lastAnalysisTime.current.getTime()) / 1000)
    : null;
  
  // Perform a full analysis of everything
  const performFullAnalysis = async () => {
    if (!cameraState.isActive || isAnalyzing) return;
    
    setIsAnalyzing(true);
    
    try {
      // Capture frame
      const imageBase64 = captureFrame();
      if (!imageBase64) return;
      
      // Run all analyses in parallel
      const [objectsResult, environmentResult, userResult] = await Promise.all([
        recognizeObjects(imageBase64),
        analyzeFromImage(imageBase64),
        analyzeUser(imageBase64)
      ]);
      
      // Update last analysis time
      lastAnalysisTime.current = new Date();
      
      // Call callbacks with results
      if (onEnvironmentDetected) onEnvironmentDetected(environmentResult);
      if (onUserAnalyzed) onUserAnalyzed(userResult);
      if (onObjectsDetected) onObjectsDetected(objectsResult.objects.map(obj => obj.name));
    } catch (error) {
      console.error('Error performing full analysis:', error);
    } finally {
      setIsAnalyzing(false);
    }
  };
  
  // Toggle automatic analysis
  const toggleAutomaticAnalysis = () => {
    if (automaticAnalysis) {
      // Stop automatic analysis
      if (analyzeInterval) {
        clearInterval(analyzeInterval);
        setAnalyzeInterval(null);
      }
      clearFrameProcessor();
    } else {
      // Start automatic analysis
      const interval = setInterval(performFullAnalysis, 10000); // Every 10 seconds
      setAnalyzeInterval(interval);
      
      // Also set up frame processor for continuous processing
      setFrameProcessor((imageBase64) => {
        // This will be called on every frame capture
        // For efficiency, we'll just analyze the user state since it's lightweight
        analyzeUser(imageBase64);
      });
    }
    
    setAutomaticAnalysis(!automaticAnalysis);
  };
  
  // Clean up on unmount
  useEffect(() => {
    return () => {
      if (analyzeInterval) {
        clearInterval(analyzeInterval);
      }
      clearFrameProcessor();
    };
  }, [analyzeInterval, clearFrameProcessor]);
  
  // Start automatic analysis if autoActivate is true
  useEffect(() => {
    if (autoActivate && cameraState.isActive) {
      toggleAutomaticAnalysis();
    }
  }, [autoActivate, cameraState.isActive]);
  
  return (
    <div className="flex flex-col space-y-4">
      {/* Camera view */}
      <div className="relative overflow-hidden rounded-xl bg-black">
        <video 
          ref={videoRef} 
          className={`w-full h-64 object-cover ${!cameraState.isActive ? 'opacity-50' : ''}`}
          muted
          playsInline
        />
        
        {!cameraState.isActive && (
          <div className="absolute inset-0 flex items-center justify-center">
            <p className="text-white text-lg font-medium">Camera Off</p>
          </div>
        )}
        
        <div className="absolute bottom-2 right-2 flex space-x-2">
          <Button 
            variant="outline" 
            size="icon" 
            className="bg-black/50 text-white hover:bg-black/70"
            onClick={toggleCamera}
          >
            {cameraState.isActive ? <CameraOff size={18} /> : <Camera size={18} />}
          </Button>
          
          {cameraState.isActive && (
            <Button 
              variant="outline" 
              size="icon" 
              className={`bg-black/50 text-white hover:bg-black/70 ${automaticAnalysis ? 'bg-primary/70' : ''}`}
              onClick={toggleAutomaticAnalysis}
            >
              {automaticAnalysis ? <EyeOff size={18} /> : <Eye size={18} />}
            </Button>
          )}
          
          {cameraState.isActive && !automaticAnalysis && (
            <Button 
              variant="outline" 
              size="sm" 
              className="bg-black/50 text-white hover:bg-black/70"
              onClick={performFullAnalysis}
              disabled={isAnalyzing}
            >
              {isAnalyzing ? 'Analyzing...' : 'Analyze Now'}
            </Button>
          )}
        </div>
      </div>
      
      {/* Analysis results */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {/* Environment */}
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="flex items-center space-x-2">
              <Home size={18} />
              <span>Environment</span>
            </CardTitle>
            <CardDescription>Analysis of your surroundings</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-2">
              <div className="flex items-center justify-between">
                <span className="flex items-center space-x-2">
                  <Lightbulb size={14} />
                  <span>Lighting:</span>
                </span>
                <Badge variant="outline">{environmentContext.lighting}</Badge>
              </div>
              
              <div>
                <div className="flex items-center space-x-2">
                  <Home size={14} />
                  <span>Scene:</span>
                </div>
                <p className="text-sm text-muted-foreground">{environmentContext.scene}</p>
              </div>
              
              <div className="flex flex-wrap gap-1 mt-2">
                {environmentContext.objects.slice(0, 8).map((object, index) => (
                  <Badge key={index} variant="secondary">{object}</Badge>
                ))}
              </div>
              
              {environmentContext.hazards.length > 0 && (
                <div className="mt-2">
                  <div className="flex items-center space-x-2 text-amber-500">
                    <AlertTriangle size={14} />
                    <span>Hazards:</span>
                  </div>
                  <ul className="text-sm text-amber-500 ml-5 list-disc">
                    {environmentContext.hazards.map((hazard, index) => (
                      <li key={index}>{hazard}</li>
                    ))}
                  </ul>
                </div>
              )}
            </div>
          </CardContent>
        </Card>
        
        {/* User state */}
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="flex items-center space-x-2">
              <Users size={18} />
              <span>User State</span>
            </CardTitle>
            <CardDescription>Analysis of your current state</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-3">
              <div className="flex items-center justify-between">
                <span className="flex items-center space-x-2">
                  <Smile size={14} />
                  <span>Emotion:</span>
                </span>
                <Badge variant="outline">{currentEmotion}</Badge>
              </div>
              
              <div>
                <div className="flex items-center justify-between mb-1">
                  <span className="text-sm">Attention Level</span>
                  <span className="text-sm text-muted-foreground">
                    {Math.round(attentionLevel * 100)}%
                  </span>
                </div>
                <Progress value={attentionLevel * 100} className="h-2" />
              </div>
              
              <div className="flex items-center justify-between">
                <span>Posture:</span>
                <Badge variant={posture === 'good' ? 'secondary' : (posture === 'slouching' ? 'destructive' : 'outline')}>
                  {posture}
                </Badge>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
      
      {/* Analysis status */}
      <div className="flex items-center justify-between text-sm text-muted-foreground mt-2">
        <div>
          {automaticAnalysis ? (
            <span className="flex items-center space-x-1">
              <Zap size={14} className="text-amber-500" />
              <span>Automatic analysis active</span>
            </span>
          ) : (
            <span>Automatic analysis disabled</span>
          )}
        </div>
        
        {timeSinceLastAnalysis !== null && (
          <div>Last analyzed: {timeSinceLastAnalysis}s ago</div>
        )}
      </div>
    </div>
  );
}