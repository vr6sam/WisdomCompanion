import React, { useState, useEffect } from 'react';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogFooter,
} from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Label } from "@/components/ui/label";
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert";
import { AlertCircle, CheckCircle2, KeyRound } from "lucide-react";
import { useToast } from '@/hooks/use-toast';

interface APIKeyConfigModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export default function APIKeyConfigModal({ isOpen, onClose }: APIKeyConfigModalProps) {
  const [openaiKey, setOpenaiKey] = useState<string>('');
  const [anthropicKey, setAnthropicKey] = useState<string>('');
  const [isTestingOpenAI, setIsTestingOpenAI] = useState<boolean>(false);
  const [isTestingAnthropic, setIsTestingAnthropic] = useState<boolean>(false);
  const [openaiStatus, setOpenaiStatus] = useState<'untested' | 'valid' | 'invalid'>('untested');
  const [anthropicStatus, setAnthropicStatus] = useState<'untested' | 'valid' | 'invalid'>('untested');
  
  const { toast } = useToast();
  
  // Load existing keys from localStorage if available
  useEffect(() => {
    const savedOpenAIKey = localStorage.getItem('openai_api_key');
    const savedAnthropicKey = localStorage.getItem('anthropic_api_key');
    
    if (savedOpenAIKey) setOpenaiKey(savedOpenAIKey);
    if (savedAnthropicKey) setAnthropicKey(savedAnthropicKey);
  }, []);
  
  // Test OpenAI API key
  const testOpenAIKey = async () => {
    if (!openaiKey.trim()) {
      toast({
        title: "Error",
        description: "Please enter an OpenAI API key",
        variant: "destructive"
      });
      return;
    }
    
    setIsTestingOpenAI(true);
    
    try {
      const response = await fetch('/api/openai/test', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json'
        },
        body: JSON.stringify({ api_key: openaiKey })
      });
      
      const data = await response.json();
      
      if (data.success) {
        setOpenaiStatus('valid');
        localStorage.setItem('openai_api_key', openaiKey);
        toast({
          title: "Success",
          description: "OpenAI API key is valid",
          variant: "default"
        });
      } else {
        setOpenaiStatus('invalid');
        toast({
          title: "Error",
          description: data.error || "Invalid OpenAI API key",
          variant: "destructive"
        });
      }
    } catch (error) {
      console.error('Error testing OpenAI key:', error);
      setOpenaiStatus('invalid');
      toast({
        title: "Error",
        description: "Failed to test OpenAI API key",
        variant: "destructive"
      });
    } finally {
      setIsTestingOpenAI(false);
    }
  };
  
  // Test Anthropic API key
  const testAnthropicKey = async () => {
    if (!anthropicKey.trim()) {
      toast({
        title: "Error",
        description: "Please enter an Anthropic API key",
        variant: "destructive"
      });
      return;
    }
    
    setIsTestingAnthropic(true);
    
    try {
      const response = await fetch('/api/anthropic/test', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json'
        },
        body: JSON.stringify({ api_key: anthropicKey })
      });
      
      const data = await response.json();
      
      if (data.success) {
        setAnthropicStatus('valid');
        localStorage.setItem('anthropic_api_key', anthropicKey);
        toast({
          title: "Success",
          description: "Anthropic API key is valid",
          variant: "default"
        });
      } else {
        setAnthropicStatus('invalid');
        toast({
          title: "Error",
          description: data.message || "Invalid Anthropic API key",
          variant: "destructive"
        });
      }
    } catch (error) {
      console.error('Error testing Anthropic key:', error);
      setAnthropicStatus('invalid');
      toast({
        title: "Error",
        description: "Failed to test Anthropic API key",
        variant: "destructive"
      });
    } finally {
      setIsTestingAnthropic(false);
    }
  };
  
  // Save all keys and close
  const saveAndClose = () => {
    if (openaiKey) {
      localStorage.setItem('openai_api_key', openaiKey);
    }
    
    if (anthropicKey) {
      localStorage.setItem('anthropic_api_key', anthropicKey);
    }
    
    // Notify the server to reload the API keys
    fetch('/api/reload-keys', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json'
      },
      body: JSON.stringify({
        openai_api_key: openaiKey,
        anthropic_api_key: anthropicKey
      })
    }).catch(err => {
      console.error('Error reloading API keys:', err);
    });
    
    toast({
      title: "Success",
      description: "API keys saved successfully",
      variant: "default"
    });
    
    onClose();
  };
  
  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="sm:max-w-[425px]">
        <DialogHeader>
          <DialogTitle>Configure AI API Keys</DialogTitle>
          <DialogDescription>
            Enter your API keys for OpenAI and Anthropic Claude to use enhanced AI features.
          </DialogDescription>
        </DialogHeader>

        <Alert variant="destructive" className="my-2">
          <AlertCircle className="h-4 w-4" />
          <AlertTitle>API Keys Required</AlertTitle>
          <AlertDescription>
            The AI assistant needs valid API keys to function properly. 
            Please provide your own OpenAI and/or Anthropic API keys.
          </AlertDescription>
        </Alert>
        
        <div className="grid gap-4 py-4">
          <div className="grid grid-cols-4 items-center gap-4">
            <Label htmlFor="openai-key" className="col-span-4">
              OpenAI API Key
              {openaiStatus === 'valid' && (
                <CheckCircle2 className="inline-block ml-2 h-4 w-4 text-green-500" />
              )}
              {openaiStatus === 'invalid' && (
                <AlertCircle className="inline-block ml-2 h-4 w-4 text-red-500" />
              )}
            </Label>
            <Input
              id="openai-key"
              value={openaiKey}
              onChange={(e) => setOpenaiKey(e.target.value)}
              className="col-span-3"
              type="password"
              placeholder="sk-..."
            />
            <Button 
              onClick={testOpenAIKey} 
              className="col-span-1"
              disabled={isTestingOpenAI || !openaiKey.trim()}
            >
              {isTestingOpenAI ? "Testing..." : "Test"}
            </Button>
          </div>
          
          <div className="grid grid-cols-4 items-center gap-4">
            <Label htmlFor="anthropic-key" className="col-span-4">
              Anthropic API Key
              {anthropicStatus === 'valid' && (
                <CheckCircle2 className="inline-block ml-2 h-4 w-4 text-green-500" />
              )}
              {anthropicStatus === 'invalid' && (
                <AlertCircle className="inline-block ml-2 h-4 w-4 text-red-500" />
              )}
            </Label>
            <Input
              id="anthropic-key"
              value={anthropicKey}
              onChange={(e) => setAnthropicKey(e.target.value)}
              className="col-span-3"
              type="password"
              placeholder="sk-ant-..."
            />
            <Button 
              onClick={testAnthropicKey} 
              className="col-span-1"
              disabled={isTestingAnthropic || !anthropicKey.trim()}
            >
              {isTestingAnthropic ? "Testing..." : "Test"}
            </Button>
          </div>
        </div>
        
        <DialogFooter>
          <Button onClick={onClose} variant="outline">
            Cancel
          </Button>
          <Button onClick={saveAndClose}>
            Save Changes
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}