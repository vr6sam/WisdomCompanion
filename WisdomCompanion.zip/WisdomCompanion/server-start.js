// Custom server launcher script
// This uses Node.js child_process to run the server directly with node and esbuild
import { spawn } from 'child_process';
import { dirname, join } from 'path';
import { fileURLToPath } from 'url';
import fs from 'fs';
import { createServer } from 'vite';

const __dirname = dirname(fileURLToPath(import.meta.url));

// Set environment variables
process.env.NODE_ENV = 'development';

console.log('Starting Vite server for client development...');

// Set up Vite for the frontend
const vite = await createServer({
  configFile: join(__dirname, 'vite.config.ts'),
  server: {
    port: 3000
  }
});

await vite.listen();
console.log('Vite server running on port 3000');

// Create a temp file with the server code for Node.js to execute
const tempDir = join(__dirname, 'temp');
if (!fs.existsSync(tempDir)) {
  fs.mkdirSync(tempDir);
}

// Start Express server
console.log('Starting Express server...');
const nodeProcess = spawn('node', [
  '--require=ts-node/register',
  join(__dirname, 'server/index.ts')
], {
  stdio: 'inherit',
  env: {
    ...process.env,
    TS_NODE_TRANSPILE_ONLY: 'true'
  }
});

nodeProcess.on('error', (error) => {
  console.error('Failed to start server:', error);
  vite.close();
  process.exit(1);
});

nodeProcess.on('exit', (code) => {
  console.log(`Server process exited with code ${code}`);
  vite.close();
  process.exit(code || 0);
});

// Handle termination signals
process.on('SIGINT', () => {
  console.log('Received SIGINT, shutting down...');
  vite.close();
  nodeProcess.kill('SIGINT');
});

process.on('SIGTERM', () => {
  console.log('Received SIGTERM, shutting down...');
  vite.close();
  nodeProcess.kill('SIGTERM');
});